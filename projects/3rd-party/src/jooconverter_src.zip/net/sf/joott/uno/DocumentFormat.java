//
// Copyright (C) 2004 Mirko Nasato
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// Lesser General Public License http://www.gnu.org/licenses/lgpl.txt
// for more details.
//
package net.sf.joott.uno;

import java.util.Collections;
import java.util.Map;

/**
 * Document format.
 */
public class DocumentFormat {
	private String mimeType;
	private String fileExtension;
	private Map filterProperties;

	// Writer
	public static final DocumentFormat XML_WRITER = new DocumentFormat("application/vnd.sun.xml.writer", "sxw", "StarOffice XML (Writer)");	
	public static final DocumentFormat PDF_WRITER = new DocumentFormat("application/pdf", "pdf", "writer_pdf_Export");	
	public static final DocumentFormat MS_WORD_97 = new DocumentFormat("application/msword", "doc", "MS Word 97");
	public static final DocumentFormat RTF = new DocumentFormat("application/rtf", "rtf", "Rich Text Format");
	public static final DocumentFormat HTML_WRITER = new DocumentFormat("text/html", "html", "HTML (StarWriter)");
	public static final DocumentFormat TEXT = new DocumentFormat("text/plain", "txt", "Text");
	
	// Writer/Web
	public static final DocumentFormat XML_WRITER_WEB = new DocumentFormat("application/vnd.sun.xml.writer", "sxw", "writer_web_StarOffice_XML_Writer");
	public static final DocumentFormat PDF_WRITER_WEB = new DocumentFormat("application/pdf", "pdf", "writer_web_pdf_Export");

	// Calc
	public static final DocumentFormat XML_CALC = new DocumentFormat("application/vnd.sun.xml.calc", "sxc", "StarOffice XML (Calc)");
	public static final DocumentFormat PDF_CALC = new DocumentFormat("application/pdf", "pdf", "calc_pdf_Export");
	public static final DocumentFormat MS_EXCEL_97 = new DocumentFormat("application/vnd.ms-excel", "xls", "MS Excel 97");
	public static final DocumentFormat HTML_CALC = new DocumentFormat("text/html", "html", "HTML (StarCalc)");
	public static final DocumentFormat TEXT_CALC = new DocumentFormat("text/plain", "txt", "Text - txt - csv (StarCalc)");

	// Impress
	public static final DocumentFormat XML_IMPRESS = new DocumentFormat("application/vnd.sun.xml.impress", "sxc", "StarOffice XML (Impress)");
	public static final DocumentFormat PDF_IMPRESS = new DocumentFormat("application/pdf", "pdf", "impress_pdf_Export");
	public static final DocumentFormat FLASH_IMPRESS = new DocumentFormat("application/x-shockwave-flas", "swf", "impress_flash_Export");
	public static final DocumentFormat MS_POWERPOINT_97 = new DocumentFormat("application/vnd.ms-powerpoin", "ppt", "MS PowerPoint 97");

	// disabled because it saves images and other html files in the current directory
	//public static final DocumentFormat HTML_IMPRESS = new DocumentFormat("text/html", "html", "impress_html_Export");

	public DocumentFormat(String mimeType, String fileExtension, String filterName) {
		this(mimeType, fileExtension, Collections.singletonMap("FilterName", filterName));
	}

	public DocumentFormat(String mimeType, String fileExtension, Map filterProperties) {
		this.mimeType = mimeType;
		this.fileExtension = fileExtension;
		this.filterProperties = filterProperties;
	}

	public String getMimeType() {
		return mimeType;
	}

	public String getFileExtension() {
		return fileExtension;
	}

	public Map getFilterProperties() {
		return filterProperties;
	}

}
