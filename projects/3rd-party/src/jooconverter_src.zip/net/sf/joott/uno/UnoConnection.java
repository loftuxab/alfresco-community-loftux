//
// Copyright (C) 2004 Mirko Nasato
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// Lesser General Public License http://www.gnu.org/licenses/lgpl.txt
// for more details.
//
package net.sf.joott.uno;

import java.net.ConnectException;
import java.util.logging.Logger;

import com.sun.star.beans.XPropertySet;
import com.sun.star.bridge.XBridge;
import com.sun.star.bridge.XBridgeFactory;
import com.sun.star.comp.helper.Bootstrap;
import com.sun.star.connection.NoConnectException;
import com.sun.star.connection.XConnection;
import com.sun.star.connection.XConnector;
import com.sun.star.frame.XComponentLoader;
import com.sun.star.lang.DisposedException;
import com.sun.star.lang.EventObject;
import com.sun.star.lang.XComponent;
import com.sun.star.lang.XEventListener;
import com.sun.star.lang.XMultiComponentFactory;
import com.sun.star.uno.UnoRuntime;
import com.sun.star.uno.XComponentContext;

/**
 * Establishes and maintains a UNO Interprocess Connection with <i>OpenOffice.org</i>.
 * 
 * It is recommended to run the <i>OpenOffice.org</i> instance on the same machine
 * (otherwise extra attention must be paid to file paths).
 * 
 * By default tries to autoreconnect if the existing connection goes down.
 */
public class UnoConnection implements XEventListener {
	private static final Logger logger = Logger.getLogger(UnoConnection.class.getName());

	public static final String DEFAULT_CONNECTION_STRING = "socket,host=localhost,port=8100,tcpNoDelay=1";	
	//public static final String DEFAULT_CONNECTION_STRING = "pipe,name=jooconverter_office";

	private String connectionString = DEFAULT_CONNECTION_STRING;
	private boolean autoReconnecting = true;

	private XBridge bridge;
	private XComponentContext context;
	private XMultiComponentFactory serviceManager;
	private boolean closingExpected = false;

	/**
	 * Creates a new connection using the default connection parameters. 
	 *
	 * @see UnoConnection#DEFAULT_CONNECTION_STRING
	 */
	public UnoConnection() { }

	/**
	 * Creates a new connection using the specified connection parameters.
	 * <p>
	 * Examples:
	 * 
	 * TCP local connection on port 8100
	 * <pre>
	 * connection = new UnoConnection("socket,host=localhost,port=8100,tcpNoDelay=1");
	 * </pre>
	 * 
	 * named pipe (requires a native library, $OPENOFFICE_INSTALL_DIR/program must be in the java library path)
	 * <pre>
	 * connection = new UnoConnection("pipe,name=jooconverter_office");
	 * </pre>
	 * 
	 * See the
	 * <a href="http://api.openoffice.org/docs/DevelopersGuide/ProfUNO/ProfUNO.htm#1+3+1+4+Opening+a+Connection">OpenOffice.org Developer's Guide</a>
	 * for more information on connections and parameters.
	 *
	 * @param connectionString the connection string
	 */
	public UnoConnection(String connectionString) {
		this.connectionString = connectionString;
	}

	/**
	 * Should we try to reestablish the connection if it goes down?
	 * 
	 * @param autoReconnecting
	 */
	public void setAutoReconnecting(boolean autoReconnecting) {
		this.autoReconnecting = autoReconnecting;
	}

	public boolean getAutoReconnecting() {
		return autoReconnecting;
	}

	public void connect() throws ConnectException {
		logger.info("connecting using \""+ connectionString +"\"...");
		try {
			XComponentContext localContext = Bootstrap.createInitialComponentContext(null);
			XMultiComponentFactory localServiceManager = localContext.getServiceManager();			
			XConnector connector = (XConnector)UnoRuntime.queryInterface(XConnector.class, localServiceManager.createInstanceWithContext("com.sun.star.connection.Connector", localContext));
			XConnection connection = connector.connect(connectionString);
			XBridgeFactory bridgeFactory = (XBridgeFactory)UnoRuntime.queryInterface(XBridgeFactory.class, localServiceManager.createInstanceWithContext("com.sun.star.bridge.BridgeFactory", localContext));
			bridge = bridgeFactory.createBridge("", "urp", connection, null);
			((XComponent)UnoRuntime.queryInterface(XComponent.class, bridge)).addEventListener(this);
			serviceManager = (XMultiComponentFactory)UnoRuntime.queryInterface(XMultiComponentFactory.class, bridge.getInstance("StarOffice.ServiceManager"));
			XPropertySet set = (XPropertySet)UnoRuntime.queryInterface(XPropertySet.class, serviceManager);
			context = (XComponentContext)UnoRuntime.queryInterface(XComponentContext.class, set.getPropertyValue("DefaultContext"));
		} catch (Exception e) {
			logger.severe("connection failed: "+ e);
			if (e instanceof NoConnectException) throw new ConnectException("connection failed; "+ e.getMessage());
			throw new UnoException(e);
		}
		logger.info("connected");
	}

	public void close() {
		closingExpected = true;
		((XComponent)UnoRuntime.queryInterface(XComponent.class, bridge)).dispose();
		closingExpected = false;
	}

	/**
	 * Obtains a UNO service.
	 * 
	 * @param service the UNO service name (e.g. "com.sun.star.frame.Desktop")
	 * @return
	 * @throws ConnectException if the underlying connection went down
	 */
	protected Object getService(String service) throws ConnectException {
		if (serviceManager == null && !autoReconnecting) {
			throw new IllegalStateException("not connected");
		}
		try {
			try {
				return serviceManager.createInstanceWithContext(service, context);
			} catch (DisposedException e) {
				logger.warning("connection was closed");
				if (autoReconnecting) {
					connect();
					return serviceManager.createInstanceWithContext(service, context);
				} else {
					throw new ConnectException("connection broken; "+ e.getMessage());
				}
			}
		} catch (Exception e) {
			if (e instanceof ConnectException) throw (ConnectException)e;
			throw new UnoException(e);
		}
	}

	/**
	 * Obtains the com.sun.star.frame.Desktop service.
	 * 
	 * @return
	 * @throws ConnectException
	 */
	public XComponentLoader getDesktop() throws ConnectException {
		return (XComponentLoader)UnoRuntime.queryInterface(XComponentLoader.class, getService("com.sun.star.frame.Desktop"));
	}

	public void disposing(EventObject event) {
		if (closingExpected) {
			logger.info("closing");
		} else {
			logger.warning("closing unexpectedly");
		}
	}

}
