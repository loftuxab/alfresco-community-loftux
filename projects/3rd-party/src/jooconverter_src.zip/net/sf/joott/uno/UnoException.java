//
// Copyright (C) 2004 Mirko Nasato
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// Lesser General Public License http://www.gnu.org/licenses/lgpl.txt
// for more details.
//
package net.sf.joott.uno;

/**
 * Generic unchecked exception for problems with the UNO interprocess bridge.
 */
public class UnoException extends RuntimeException {

	public UnoException(Throwable cause) {
		super(cause);
	}
	
	public UnoException(String message) {
		super(message);
	}

	public UnoException(String message, Throwable cause) {
		super(message, cause);
	}

}
