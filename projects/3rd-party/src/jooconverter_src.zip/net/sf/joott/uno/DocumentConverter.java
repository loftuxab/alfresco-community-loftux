//
// Copyright (C) 2004 Mirko Nasato
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// Lesser General Public License http://www.gnu.org/licenses/lgpl.txt
// for more details.
//
package net.sf.joott.uno;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.ConnectException;
import java.util.Iterator;
import java.util.Map;
import java.util.logging.Logger;

import com.sun.star.beans.PropertyValue;
import com.sun.star.frame.XComponentLoader;
import com.sun.star.frame.XStorable;
import com.sun.star.lang.XComponent;
import com.sun.star.ucb.XFileIdentifierConverter;
import com.sun.star.uno.UnoRuntime;
import com.sun.star.util.XURLTransformer;

/**
 * Performs conversion between supported document formtats.
 */
public class DocumentConverter {
	private static Logger logger = Logger.getLogger(DocumentConverter.class.getName());
	
	private UnoConnection connection;
	private XURLTransformer urlTransformer;

	public DocumentConverter() { }

	public DocumentConverter(UnoConnection connection) throws ConnectException {
		this.connection = connection;
	}

	public void setConnection(UnoConnection connection) {
		this.connection = connection;
	}

	public String toUrl(File file) throws ConnectException {
		Object fcp = connection.getService("com.sun.star.ucb.FileContentProvider");
		XFileIdentifierConverter fic = (XFileIdentifierConverter)UnoRuntime.queryInterface(XFileIdentifierConverter.class, fcp);
		return fic.getFileURLFromSystemPath("", file.getAbsolutePath());
	}

	/**
	 * Converts a document into a different format.
	 * 
	 * Example: converts a Writer document to PDF
	 * <pre>
	 * File sxw = new File("test.sxw");
	 * File pdf = new File("/tmp/test.pdf");
	 * DocumentConverter converter = DocumentConverterFactory.getConverter();
	 * converter.convert(sxw, pdf, DocumentFormat.PDF_WRITER);
	 * </pre>
	 * 
	 * @param source the input document
	 * @param destination the output document
	 * @param outputFormat the output format
	 * @throws FileNotFoundException if the input document is not found
	 * @throws IOException if the output document is not writable (or the filter name is wrong) 
	 */
	public void convert(File source, File destination, DocumentFormat outputFormat) throws IOException {
		if (source == null || !source.canRead()) {
			throw new FileNotFoundException("invalid source file: "+ source);
		}
		convert(toUrl(source), toUrl(destination), outputFormat);
	}

	public void convert(String sourceUrl, String destinationUrl, DocumentFormat outputFormat) throws IOException {
		Map filterProperties = outputFormat.getFilterProperties();
		try {
			// UNO Interprocess Bridge *should* be thread-safe, but...
			synchronized (connection) {
				XComponentLoader desktop = connection.getDesktop();
				XComponent document = desktop.loadComponentFromURL(sourceUrl, "_blank", 0, new PropertyValue[] { property("Hidden", Boolean.TRUE) });				
				if (document == null) {
					throw new FileNotFoundException("could not open source document: "+ sourceUrl);
				}
				try {
					XStorable storable = (XStorable)UnoRuntime.queryInterface(XStorable.class, document);
					storable.storeToURL(destinationUrl, toUnoProperties(filterProperties));
				} finally {
					document.dispose();
				}
			}
		} catch (FileNotFoundException fnfe) {
			logger.severe("conversion failed; source = \""+ sourceUrl +"\"; destination = \""+ destinationUrl +"\"; filterProperties = \""+ filterProperties +"\""+ fnfe);
			throw fnfe;
		} catch (com.sun.star.io.IOException ioe) {
			logger.severe("conversion failed; source = \""+ sourceUrl +"\"; destination = \""+ destinationUrl +"\"; filterProperties = \""+ filterProperties +"\""+ ioe);
			throw new IOException(ioe.getMessage());
		} catch (Exception e) {
			logger.severe("conversion failed; source = \""+ sourceUrl +"\"; destination = \""+ destinationUrl +"\"; filterProperties = \""+ filterProperties +"\""+ e);
			throw new UnoException("conversion failed", e);
		}
	}

	private static PropertyValue property(String name, Object value) {
		PropertyValue property = new PropertyValue();
		property.Name = name;
		property.Value = value;
		return property;
	}

	private static PropertyValue[] toUnoProperties(Map properties) {
		PropertyValue[] values = new PropertyValue[properties.size()];
		Iterator entries = properties.entrySet().iterator();
		int i = 0;
		while (entries.hasNext()) {
			Map.Entry entry = (Map.Entry)entries.next();
			values[i++] = property((String)entry.getKey(), entry.getValue());
		}
		return values;
	}

}
