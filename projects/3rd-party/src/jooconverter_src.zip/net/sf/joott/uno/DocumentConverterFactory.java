//
// Copyright (C) 2004 Mirko Nasato
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// Lesser General Public License http://www.gnu.org/licenses/lgpl.txt
// for more details.
//
package net.sf.joott.uno;

import java.net.ConnectException;

/**
 * Very simple factory.
 * 
 * Assumes a UNO interprocess connection running according to
 * UnoConnection default parameters.
 */
public class DocumentConverterFactory {
	private static UnoConnection unoConnection;
	private static DocumentConverter documentConverter;

	public static synchronized UnoConnection getConnection() throws ConnectException {
		if (unoConnection == null) {
			unoConnection = new UnoConnection();
			unoConnection.connect();
		}
		return unoConnection;
	}

	public static synchronized DocumentConverter getConverter() throws ConnectException {
		if (documentConverter == null) {
			documentConverter = new DocumentConverter(getConnection());
		}
		return documentConverter;
	}

}
