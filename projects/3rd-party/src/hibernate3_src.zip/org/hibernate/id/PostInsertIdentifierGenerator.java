//$Id: PostInsertIdentifierGenerator.java,v 1.2 2005/02/03 07:37:49 oneovthafew Exp $
package org.hibernate.id;

import java.io.Serializable;

import org.hibernate.HibernateException;
import org.hibernate.engine.SessionImplementor;

/**
 * @author Gavin King
 */
public interface PostInsertIdentifierGenerator extends IdentifierGenerator {
	public Serializable getGenerated(SessionImplementor session, Object object, PostInsertIdentityPersister persister) 
	throws HibernateException;
}
