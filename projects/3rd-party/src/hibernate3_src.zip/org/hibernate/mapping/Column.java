//$Id: Column.java,v 1.12 2005/02/02 09:56:15 oneovthafew Exp $
package org.hibernate.mapping;

import java.io.Serializable;

import org.hibernate.HibernateException;
import org.hibernate.MappingException;
import org.hibernate.dialect.Dialect;
import org.hibernate.engine.Mapping;
import org.hibernate.util.StringHelper;

/**
 * A column of a relational database table
 * @author Gavin King
 */
public class Column implements Selectable, Serializable {

	public static final int DEFAULT_LENGTH = 255;
	public static final int DEFAULT_SCALE = 19;
	
	private int length=DEFAULT_LENGTH;
	private int precision=DEFAULT_SCALE;
	private Value value;
	private int typeIndex = 0;
	private String name;
	private boolean nullable=true;
	private boolean unique=false;
	private String sqlType;
	private Integer sqlTypeCode; 
	private boolean quoted=false;
	int uniqueInteger;
	private String checkConstraint;

	public Column() { };
	
	public Column(String columnName) {
		setName(columnName);
	}
	
	public int getLength() {
		return length;
	}
	public void setLength(int length) {
		this.length = length;
	}
	public Value getValue() {
		return value;
	}
	public void setValue(Value value) {
		this.value= value;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		if (
			name.charAt(0)=='`' |
			Dialect.QUOTE.indexOf( name.charAt(0) ) > -1 //TODO: deprecated, remove eventually
		) {
			quoted=true;
			this.name=name.substring( 1, name.length()-1 );
		}
		else {
			this.name = name;
		}
	}
	public String getQuotedName(Dialect d) {
		return quoted ?
			d.openQuote() + name + d.closeQuote() :
			name;
	}
	
	/**
	 * For any column name, generate an alias that is unique
	 * to that column name, and also 10 characters or less
	 * in length.
	 */
	public String getAlias() {
		String alias = name;
		String unique = Integer.toString(uniqueInteger) + '_';
		int lastLetter = StringHelper.lastIndexOfLetter(name);
		if ( lastLetter == -1 ) {
			alias = "column";
		}
		else if ( lastLetter < name.length()-1 ) {
			alias = name.substring(0, lastLetter+1);
		}
		if ( alias.length() > 10 ) {
			alias = alias.substring( 0, 10 - unique.length() );
		}
		if ( name.equals(alias) ) {
			return alias;
		}
		else {
			return alias + unique;
		}
	}
	
	/**
	 * Generate a column alias that is unique across multiple tables
	 */
	public String getAlias(Table table) {
		return getAlias() + table.getUniqueInteger() + '_';
	}

	public boolean isNullable() {
		return nullable;
	}

	public void setNullable(boolean nullable) {
		this.nullable=nullable;
	}

	public int getTypeIndex() {
		return typeIndex;
	}
	public void setTypeIndex(int typeIndex) {
		this.typeIndex = typeIndex;
	}

	public int getSqlTypeCode(Mapping mapping) throws MappingException {
		org.hibernate.type.Type type = getValue().getType();
		try {
			int sqlTypeCode = type.sqlTypes(mapping)[ getTypeIndex() ];
			if(getSqlTypeCode()!=null && getSqlTypeCode().intValue()!=sqlTypeCode) {
				throw new MappingException("SQLType code's does not match. mapped as " + sqlTypeCode + " but is " + getSqlTypeCode() );
			}
			return sqlTypeCode;
		}
		catch (Exception e) {
			throw new MappingException(
				"Could not determine type for column " +
				name +
				" of type " +
				type.getClass().getName() +
				": " +
				e.getClass().getName(),
				e
			);
		}
	}

	/**
	 * Returns the underlying columns sqltypecode.
	 * If null, it is because the sqltype code is unknown.
	 * 
	 * Use #getSqlTypeCode(Mapping) to retreive the sqltypecode used
	 * for the columns associated Value/Type.
	 * 
	 * @return sqltypecode if it is set, otherwise null.
	 */
	public Integer getSqlTypeCode() {
		return sqlTypeCode;
	}
	
	public void setSqlTypeCode(Integer typecode) {
		sqlTypeCode=typecode;
	}
	
	public boolean isUnique() {
		return unique;
	}


	public String getSqlType(Dialect dialect, Mapping mapping) throws HibernateException {
		return sqlType==null ?
			dialect.getTypeName( getSqlTypeCode(mapping), getLength(), getPrecision() ) :
			sqlType;
	}

	public boolean equals(Object object) {
		return object instanceof Column && equals( (Column) object );
	}

	public boolean equals(Column column) {
		if (null == column) return false;
		if (this == column) return true;

		return isQuoted() ? 
			name.equals(column.name) :
			name.equalsIgnoreCase(column.name);
	}

	//used also for generation of FK names!
	public int hashCode() {
		return isQuoted() ? 
			name.hashCode() : 
			name.toLowerCase().hashCode();
	}

	public String getSqlType() {
		return sqlType;
	}

	public void setSqlType(String sqlType) {
		this.sqlType = sqlType;
	}

	public void setUnique(boolean unique) {
		this.unique = unique;
	}

	public boolean isQuoted() {
		return quoted;
	}

	public String toString() {
		return getClass().getName() + '(' + getName() + ')';
	}

	public String getCheckConstraint() {
		return checkConstraint;
	}

	public void setCheckConstraint(String checkConstraint) {
		this.checkConstraint = checkConstraint;
	}

	public boolean hasCheckConstraint() {
		return checkConstraint!=null;
	}

	public String getTemplate(Dialect dialect) {
		return getQuotedName(dialect);
	}

	public boolean isFormula() {
		return false;
	}

	public String getText(Dialect d) {
		return getQuotedName(d);
	}
	public String getText() {
		return getName();
	}
	
	public int getPrecision() {
		return precision;
	}
	public void setPrecision(int scale) {
		this.precision = scale;
	}
}
