//$Id: AbstractEntityLoader.java,v 1.35 2005/05/19 07:28:58 steveebersole Exp $
package org.hibernate.loader;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.hibernate.FetchMode;
import org.hibernate.LockMode;
import org.hibernate.MappingException;
import org.hibernate.engine.SessionFactoryImplementor;
import org.hibernate.persister.entity.Loadable;
import org.hibernate.persister.entity.OuterJoinLoadable;
import org.hibernate.sql.JoinFragment;
import org.hibernate.sql.Select;
import org.hibernate.type.AssociationType;
import org.hibernate.util.CollectionHelper;

/**
 * Abstract superclass for entity loaders that use outer joins
 *
 * @see org.hibernate.loader.criteria.CriteriaLoader
 * @see org.hibernate.loader.entity.EntityLoader
 * @author Gavin King
 */
public abstract class AbstractEntityLoader extends OuterJoinLoader {

	private final OuterJoinLoadable persister;
	private String alias;
	
	public AbstractEntityLoader(OuterJoinLoadable persister, SessionFactoryImplementor factory, Map enabledFilters) {
		super(factory, enabledFilters);
		this.persister = persister;
		alias = generateRootAlias( persister.getEntityName() );
	}

	protected final void initAll(
		final String whereString,
		final String orderByString,
		final LockMode lockMode)
	throws MappingException {
		
		List associations = walkEntityTree( persister, getAlias() );
		
		List allAssociations = new ArrayList();
		allAssociations.addAll(associations);
		allAssociations.add( new OuterJoinableAssociation( 
				persister.getEntityType(),
				null, 
				null, 
				alias, 
				JoinFragment.LEFT_OUTER_JOIN, 
				getFactory(),
				CollectionHelper.EMPTY_MAP
			) );
		
		initPersisters(allAssociations, lockMode);
		initStatementString(associations, whereString, orderByString, lockMode);
	}
	
	protected final void initProjection(
		final String projectionString,
		final String whereString,
		final String orderByString,
		final String groupByString,
		final LockMode lockMode)
	throws MappingException {
		final List associations = walkEntityTree( persister, getAlias() );
		persisters = new Loadable[0];
		initStatementString(associations, projectionString, whereString, orderByString, groupByString, lockMode);
	}

	private void initStatementString(
		final List associations,
		final String condition,
		final String orderBy,
		final LockMode lockMode)
	throws MappingException {
		initStatementString(associations, null, condition, orderBy, "", lockMode);
	}
	
	private void initStatementString(
			final List associations,
			final String projection,
			final String condition,
			final String orderBy,
			final String groupBy,
			final LockMode lockMode)
		throws MappingException {

		final int joins = countEntityPersisters( associations );
		suffixes = generateSuffixes( joins+1 );

		JoinFragment ojf = mergeOuterJoins( associations );
		
		Select select = new Select( getDialect() )
			.setLockMode(lockMode)
			.setSelectClause(
					projection==null ? 
							persister.selectFragment( alias, suffixes[joins] ) + selectString(associations) : 
							projection
			)
			.setFromClause(
				persister.fromTableFragment(alias) +
				persister.fromJoinFragment(alias, true, true)
			)
			.setWhereClause(condition)
			.setOuterJoins(
				ojf.toFromFragmentString(),
				ojf.toWhereFragmentString() + getWhereFragment()
			)
			.setOrderByClause( orderBy( associations, orderBy ) )
			.setGroupByClause(groupBy);

		if ( getFactory().getSettings().isCommentsEnabled() ) {
			select.setComment( getComment() );
		}
		sql = select.toStatementString();
	}

	/**
	 * Don't bother with the discriminator, unless overridded by subclass
	 */
	protected String getWhereFragment() throws MappingException {
		return persister.whereJoinFragment(alias, true, true);
	}

	protected final Loadable getPersister() {
		return persister;
	}

	protected final String getAlias() {
		return alias;
	}

	/**
	 * The superclass deliberately excludes collections
	 */
	protected boolean isJoinedFetchEnabled(AssociationType type, FetchMode config) {
		return isJoinedFetchEnabledInMapping(config, type);
	}

	public String toString() {
		return getClass().getName() + '(' + getPersister().getEntityName() + ')';
	}

	public abstract String getComment();
}
