//$Id: SubqueryOneToManyLoader.java,v 1.2 2004/09/27 07:47:08 oneovthafew Exp $
package org.hibernate.loader;

import java.io.Serializable;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;

import org.hibernate.HibernateException;
import org.hibernate.MappingException;
import org.hibernate.collection.QueryableCollection;
import org.hibernate.engine.EntityKey;
import org.hibernate.engine.QueryParameters;
import org.hibernate.engine.SessionFactoryImplementor;
import org.hibernate.engine.SessionImplementor;
import org.hibernate.util.StringHelper;

/**
 * @author Gavin King
 */
public class SubqueryOneToManyLoader extends OneToManyLoader {
	
	private final Serializable[] keys;
	private final QueryParameters queryParameters;

	public SubqueryOneToManyLoader(
			QueryableCollection persister, 
			String subquery,
			Collection entityKeys,
			QueryParameters queryParameters,
			SessionFactoryImplementor factory, 
			Map enabledFilters)
	throws MappingException {
		
		super(persister, 1, subquery, factory, enabledFilters);

		keys = new Serializable[ entityKeys.size() ];
		Iterator iter = entityKeys.iterator();
		int i=0;
		while ( iter.hasNext() ) {
			keys[i++] = ( (EntityKey) iter.next() ).getIdentifier();
		}
		
		this.queryParameters = queryParameters;
		
	}

	public void initialize(Serializable id, SessionImplementor session)
	throws HibernateException {
		loadCollectionSubselect( 
				session, 
				keys, 
				queryParameters.getPositionalParameterValues(),
				queryParameters.getPositionalParameterTypes(),
				queryParameters.getNamedParameters(),
				getKeyType() 
		);
	}

	protected StringBuffer whereString(String alias, String[] columnNames, int batchSize, String subquery) {
		return new StringBuffer()//.append('(')
			.append( StringHelper.join(", ", StringHelper.qualify(alias, columnNames) ) )
			//.append(')')
			.append(" in ")
			.append('(')
			.append(subquery) 
			.append(')');
	}
}
