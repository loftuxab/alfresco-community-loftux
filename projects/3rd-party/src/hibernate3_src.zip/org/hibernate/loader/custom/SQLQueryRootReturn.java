// $Id: SQLQueryRootReturn.java,v 1.5 2005/05/17 17:11:09 maxcsaucdk Exp $
package org.hibernate.loader.custom;

import java.util.Map;

import org.hibernate.LockMode;

/**
 * Represents a return defined as part of a native sql query which
 * names a "root" entity.  A root entity means it is explicitly a
 * "column" in the result, as opposed to a fetched relationship or role.
 *
 * @author Steve
 */
public class SQLQueryRootReturn extends SQLQueryReturn {
	private String returnEntityName;
	public SQLQueryRootReturn(String alias, String returnEntityName, LockMode lockMode) {
		this(alias, returnEntityName, null, true, lockMode);
	}

	public SQLQueryRootReturn(String alias, String entityName, Map propertyResults, boolean useGeneratedAliases, LockMode lockMode) {
		super(alias, propertyResults, useGeneratedAliases, lockMode);
		this.returnEntityName = entityName;
		
	}

	public String getReturnEntityName() {
		return returnEntityName;
	}
	
}
