//$Id: UniqueEntityLoader.java,v 1.4 2004/09/27 07:47:08 oneovthafew Exp $
package org.hibernate.loader;

import java.io.Serializable;

import org.hibernate.HibernateException;
import org.hibernate.engine.SessionImplementor;

/**
 * Loads entities for a <tt>EntityPersister</tt>
 * @author Gavin King
 */
public interface UniqueEntityLoader {
	/**
	 * Load an entity instance. If <tt>optionalObject</tt> is supplied,
	 * load the entity state into the given (uninitialized) object.
	 */
	public Object load(Serializable id, Object optionalObject, SessionImplementor session) throws HibernateException;
}






