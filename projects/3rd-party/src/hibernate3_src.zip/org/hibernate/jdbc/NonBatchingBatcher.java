//$Id: NonBatchingBatcher.java,v 1.2 2005/01/10 21:25:17 oneovthafew Exp $
package org.hibernate.jdbc;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.hibernate.HibernateException;
import org.hibernate.StaleStateException;
import org.hibernate.engine.SessionImplementor;

/**
 * An implementation of the <tt>Batcher</tt> interface that does no batching
 *
 * @author Gavin King
 */
public class NonBatchingBatcher extends AbstractBatcher {

	public NonBatchingBatcher(SessionImplementor session) {
		super(session);
	}

	public void addToBatch(int expectedRowCount) throws SQLException, HibernateException {
		final int rowCount = getStatement().executeUpdate();
		//negative expected row count means we don't know how many rows to expect
		if ( expectedRowCount>0 ) {
			if ( expectedRowCount<rowCount ) {
				throw new StaleStateException(
						"Unexpected row count: " + rowCount + 
						" expected: " + expectedRowCount
				);
			}
			if ( expectedRowCount>rowCount ) {
				throw new HibernateException(
						"Unexpected row count: " + rowCount + 
						" expected: " + expectedRowCount
				);
			}		
		}
	}

	protected void doExecuteBatch(PreparedStatement ps) throws SQLException, HibernateException {
	}

}






