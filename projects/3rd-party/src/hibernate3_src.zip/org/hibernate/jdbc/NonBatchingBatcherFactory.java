//$Id: NonBatchingBatcherFactory.java,v 1.1 2004/08/10 22:16:48 oneovthafew Exp $
package org.hibernate.jdbc;

import org.hibernate.engine.SessionImplementor;

/**
 * @author Gavin King
 */
public class NonBatchingBatcherFactory implements BatcherFactory {

	public Batcher createBatcher(SessionImplementor session) {
		return new NonBatchingBatcher(session);
	}

}
