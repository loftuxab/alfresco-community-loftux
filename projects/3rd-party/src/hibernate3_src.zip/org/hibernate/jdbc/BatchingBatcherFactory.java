//$Id: BatchingBatcherFactory.java,v 1.1 2004/08/10 22:16:48 oneovthafew Exp $
package org.hibernate.jdbc;

import org.hibernate.engine.SessionImplementor;

/**
 * @author Gavin King
 */
public class BatchingBatcherFactory implements BatcherFactory {

	public Batcher createBatcher(SessionImplementor session) {
		return new BatchingBatcher(session);
	}

}
