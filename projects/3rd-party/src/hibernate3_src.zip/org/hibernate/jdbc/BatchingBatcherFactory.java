//$Id: BatchingBatcherFactory.java,v 1.5 2005/05/09 22:12:48 steveebersole Exp $
package org.hibernate.jdbc;


/**
 * A BatcherFactory implementation which constructs Batcher instances
 * capable of actually performing batch operations.
 * 
 * @author Gavin King
 */
public class BatchingBatcherFactory implements BatcherFactory {

	public Batcher createBatcher(ConnectionManager connectionManager) {
		return new BatchingBatcher( connectionManager );
	}

}
