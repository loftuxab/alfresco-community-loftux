//$Id: BatcherFactory.java,v 1.1 2004/08/10 22:16:48 oneovthafew Exp $
package org.hibernate.jdbc;

import org.hibernate.engine.SessionImplementor;

/**
 * Factory for <tt>Batcher</tt> instances.
 * @author Gavin King
 */
public interface BatcherFactory {
	public Batcher createBatcher(SessionImplementor session);
}
