//$Id: QueryableCollection.java,v 1.4 2005/02/08 08:56:14 oneovthafew Exp $
package org.hibernate.collection;

import org.hibernate.FetchMode;
import org.hibernate.persister.EntityPersister;
import org.hibernate.persister.Joinable;
import org.hibernate.persister.PropertyMapping;

/**
 * A collection role that may be queried or loaded by outer join.
 * @author Gavin King
 */
public interface QueryableCollection extends PropertyMapping, Joinable, CollectionPersister {
	/**
	 * Generate a list of collection index and element columns
	 */
	public abstract String selectFragment(String alias);
	/**
	 * Get the names of the collection index columnsm if
	 * this is an indexed collection (optional operation)
	 */
	public abstract String[] getIndexColumnNames();
	/**
	 * Get the names of the collection element columns (or the primary
	 * key columns in the case of a one-to-many association),
	 * aliased by the given table alias
	 */
	public abstract String[] getElementColumnNames(String alias);
	/**
	 * Get the names of the collection element columns (or the primary
	 * key columns in the case of a one-to-many association)
	 */
	public abstract String[] getElementColumnNames();
	/**
	 * Get the order by SQL
	 */
	public abstract String getSQLOrderByString(String alias);
	/**
	 * Does this collection role have a where clause filter?
	 */
	public abstract boolean hasWhere();
	/**
	 * Get the persister of the element class, if this is a
	 * collection of entities (optional operation).  Note that
	 * for a one-to-many association, the returned persister
	 * must be <tt>OuterJoinLoadable</tt>.
	 */
	public abstract EntityPersister getElementPersister();
	/**
	 * Should we load this collection role by outerjoining?
	 */
	public abstract FetchMode getFetchMode();

}
