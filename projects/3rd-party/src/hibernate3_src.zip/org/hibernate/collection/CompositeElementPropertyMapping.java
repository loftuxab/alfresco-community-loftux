//$Id: CompositeElementPropertyMapping.java,v 1.3 2005/01/26 06:21:41 oneovthafew Exp $
package org.hibernate.collection;

import org.hibernate.MappingException;
import org.hibernate.engine.Mapping;
import org.hibernate.persister.AbstractPropertyMapping;
import org.hibernate.type.AbstractComponentType;
import org.hibernate.type.Type;

/**
 * @author Gavin King
 */
public class CompositeElementPropertyMapping extends AbstractPropertyMapping {

	private final AbstractComponentType compositeType;
	
	public CompositeElementPropertyMapping(String[] elementColumns, AbstractComponentType compositeType, Mapping factory)
	throws MappingException {

		this.compositeType = compositeType;

		initComponentPropertyPaths(null, compositeType, elementColumns, factory);

	}

	public Type getType() {
		return compositeType;
	}

	protected String getEntityName() {
		return compositeType.getName();
	}

}