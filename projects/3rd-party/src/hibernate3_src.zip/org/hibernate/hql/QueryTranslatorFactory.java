//$Id: QueryTranslatorFactory.java,v 1.5 2004/12/06 14:17:22 pgmjsd Exp $
package org.hibernate.hql;

import org.hibernate.engine.SessionFactoryImplementor;

import java.util.Map;

/**
 * @author Gavin King
 */
public interface QueryTranslatorFactory {
	public QueryTranslator createQueryTranslator(String queryString, Map filters, SessionFactoryImplementor factory);

	public FilterTranslator createFilterTranslator(String queryString, Map filters, SessionFactoryImplementor factory);
}
