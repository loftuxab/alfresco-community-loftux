// $Id: QueryNode.java,v 1.14 2004/12/19 02:11:19 pgmjsd Exp $

package org.hibernate.hql.ast;

import antlr.collections.AST;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.hql.antlr.SqlTokenTypes;

import java.util.Iterator;

/**
 * Cusom root node for the main query.
 * User: josh
 * Date: Jan 4, 2004
 * Time: 9:15:47 AM
 */
class QueryNode extends SqlNode implements InitializeableNode, DisplayableNode {
	/**
	 * A logger for this class. *
	 */
	private static final Log log = LogFactory.getLog( QueryNode.class );


	private HqlSqlWalker walker;

	/**
	 * The where clause, lazily found or created.
	 */
	private AST where = null;

	/**
	 * The FROM clause, lazily found.
	 */
	private FromClause fromClause = null;

	/**
	 * Initializes the node with the parameter.
	 *
	 * @param param the initialization parameter.
	 */
	public void initialize(Object param) {
		walker = ( HqlSqlWalker ) param;
	}

	HqlSqlWalker getWalker() {
		return walker;
	}

	/**
	 * Returns additional display text for the AST node.
	 *
	 * @return String - The additional display text.
	 */
	public String getDisplayText() {
		StringBuffer buf = new StringBuffer();
		if ( walker.getQuerySpaces().size() > 0 ) {
			buf.append( " querySpaces (" );
			for ( Iterator iterator = walker.getQuerySpaces().iterator(); iterator.hasNext(); ) {
				buf.append( iterator.next() );
				if ( iterator.hasNext() ) {
					buf.append( "," );
				}
			}
			buf.append( ")" );
		}
		return buf.toString();
	}

	public AST getWhereClause() {
		if ( where == null ) {
			where = ASTUtil.findTypeInChildren( this, SqlTokenTypes.WHERE );
			// If there is no WHERE node, make one.
			if ( where == null ) {
				if ( log.isDebugEnabled() ) {
					log.debug( "getWhereClause() : Creating a new WHERE clause..." );
				}
				where = ASTUtil.create( walker.getASTFactory(), SqlTokenTypes.WHERE, "WHERE" );
				// Find the FROM node and insert the WHERE.
				AST from = ASTUtil.findTypeInChildren( this, SqlTokenTypes.FROM );
				where.setNextSibling( from.getNextSibling() );
				from.setNextSibling( where );
			}
		}
		return where;
	}

	public FromClause getFromClause() {
		if ( fromClause == null ) {
			fromClause = ( FromClause ) ASTUtil.findTypeInChildren( this, SqlTokenTypes.FROM );
		}
		return fromClause;
	}
}
