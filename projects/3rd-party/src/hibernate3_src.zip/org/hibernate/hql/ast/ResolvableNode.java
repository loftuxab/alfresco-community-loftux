// $Id: ResolvableNode.java,v 1.6 2004/12/12 14:09:16 pgmjsd Exp $
package org.hibernate.hql.ast;

import antlr.SemanticException;
import antlr.collections.AST;

/**
 * The contract for expression sub-trees that can resolve themselves.
 *
 * @author josh Sep 25, 2004 11:27:36 AM
 */
public interface ResolvableNode {
	/**
	 * Does the work of resolving an identifier, an index [], or a dot.
	 */
	void resolve(boolean generateJoin, boolean implicitJoin, String classAlias, AST parent) throws SemanticException;

	/**
	 * Does the work of resolving an identifier, an index [], or a dot, but without a parent node.
	 */
	void resolve(boolean generateJoin, boolean implicitJoin, String classAlias) throws SemanticException;
}
