// $Id: ErrorCounter.java,v 1.3 2004/12/11 16:31:17 pgmjsd Exp $
package org.hibernate.hql.ast;

import antlr.Parser;
import antlr.RecognitionException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.QueryException;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * An error handler that counts parsing errors and warnings.
 */
public class ErrorCounter implements ParseErrorHandler {
	private Log log = LogFactory.getLog( "hql.parser" );

	private Parser parser = null;
	private List errorList = new ArrayList();
	private List warningList = new ArrayList();
	private List recognitionExceptions = new ArrayList();

	public ErrorCounter(Parser parser) {
		this.parser = parser;
	}

	public void reportError(RecognitionException e) {
		reportError( e.toString() );
		recognitionExceptions.add( e );
		if ( log.isDebugEnabled() ) {
			log.debug( e, e );
		}
	}

	public void reportError(String s) {
		String message = ( getFilename() == null ) ? "*** ERROR: " + s : getFilename() + ": *** ERROR: " + s;
		log.error( message );
		errorList.add( message );
	}

	public int getErrorCount() {
		return errorList.size();
	}

	public void reportWarning(String s) {
		String message = ( getFilename() == null ) ? "*** WARNING: " + s : getFilename() + ": *** WARNING: " + s;
		log.warn( message );
		warningList.add( message );
	}

	public int getWarningCount() {
		return warningList.size();
	}

	private String getErrorString() {
		StringBuffer buf = new StringBuffer();
		for ( Iterator iterator = errorList.iterator(); iterator.hasNext(); ) {
			buf.append( ( String ) iterator.next() );
			if ( iterator.hasNext() ) buf.append( "\n" );

		}
		return buf.toString();
	}

	public void throwQueryException() throws QueryException {
		if ( getErrorCount() > 0 ) {
			if ( recognitionExceptions.size() > 0 ) {
				throw new QuerySyntaxError( ( RecognitionException ) recognitionExceptions.get( 0 ) );
			}
			else {
				throw new QueryException( getErrorString() );
			}
		}
		else {
			// all clear
			if ( log.isDebugEnabled() ) {
				log.debug( "throwQueryException() : no errors" );
			}
		}
	}

	private String getFilename() {
		return ( parser == null ) ? null : parser.getFilename();
	}

}
