// $Id: FromClause.java,v 1.23 2005/02/05 07:19:17 pgmjsd Exp $
package org.hibernate.hql.ast;

import antlr.SemanticException;
import antlr.collections.AST;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.hql.antlr.HqlSqlTokenTypes;

import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Represents the 'FROM' part of a query or subquery, containing all mapped class references.
 *
 * @author josh
 */
class FromClause extends HqlSqlWalkerNode implements HqlSqlTokenTypes, DisplayableNode {
	private static Log log = LogFactory.getLog( FromClause.class );

	private Set fromElements = new HashSet();
	private Map fromElementByClassAlias = new HashMap();
	private Map fromElementByTableAlias = new HashMap();
	private Map fromElementByClassName = new HashMap();

	/**
	 * All of the explicitly stated FROM xxx JOIN yyy elements.
	 */
	private Map explicitJoinFromElementsByPath = new HashMap();
	/**
	 * All of implicit FROM xxx JOIN yyy elements by their path.  These are created from collection
	 * property references.
	 */
	private Map implicitJoinFromElementsByPath = new HashMap();
	/**
	 * All of the implicit FROM xxx JOIN yyy elements that are the destination of a collection.  These are created from
	 * index operators on collection property references.
	 */
	private Map collectionJoinFromElementsByPath = new HashMap();

	/**
	 * Pointer to the parent FROM clause, if there is one.
	 */
	private FromClause parentFromClause;

	/**
	 * Counts the from elements as they are added.
	 */
	private int fromElementCounter = 0;
	/**
	 * Implied FROM elements to add onto the end of the FROM clause.
	 */
	private List impliedElements = new LinkedList();

	/**
	 * Adds a new from element to the from node.
	 *
	 * @param path  The reference to the class.
	 * @param alias The alias AST.
	 * @return FromElement - The new FROM element.
	 */
	FromElement addFromElement(String path, AST alias) throws SemanticException {
		// The path may be a reference to an alias defined in the parent query.
		String classAlias = ( alias == null ) ? null : alias.getText();
		checkForDuplicateClassAlias( classAlias );
		FromElementFactory factory = new FromElementFactory( this, null, path, classAlias, null, false );
		return factory.addFromElement();
	}

	void registerFromElement(FromElement element) {
		fromElements.add( element );
		String classAlias = element.getClassAlias();
		if ( classAlias != null ) {
			// The HQL class alias refers to the class name.
			fromElementByClassAlias.put( classAlias, element );
		}
		String className = element.getClassName();
		if ( className != null ) {
			// The class name is also an class alias for itself. :)
			fromElementByClassAlias.put( className, element );
			// Also add this to the 'unique' map.
			fromElementByClassName.put( className, element );
		}
		// Associate the table alias with the element.
		String tableAlias = element.getTableAlias();
		if ( tableAlias != null ) {
			fromElementByTableAlias.put( tableAlias, element );
		}
	}

	private void checkForDuplicateClassAlias(String classAlias) throws SemanticException {
		if ( classAlias != null && fromElementByClassAlias.containsKey( classAlias ) ) {
			throw new SemanticException( "Duplicate definition of alias '"
					+ classAlias + "'" );
		}
	}

	public FromElement getFromElement(String aliasOrClassName) {
		FromElement fromElement = ( FromElement ) fromElementByClassAlias.get( aliasOrClassName );
		if ( fromElement == null && parentFromClause != null ) {
			fromElement = parentFromClause.getFromElement( aliasOrClassName );
		}
		return fromElement;
	}

	/**
	 * Returns the list of from elements in order.
	 *
	 * @return the list of from elements (instances of FromElement).
	 */
	public List getFromElements() {
		return ASTUtil.collectChildren( this, FROM_ELEMENT_PREDICATE );
	}

	/**
	 * Returns the list of from elements that will be part of the result set.
	 *
	 * @return the list of from elements that will be part of the result set.
	 */
	public List getProjectionList() {
		return ASTUtil.collectChildren( this, PROJECTION_LIST_PREDICATE );
	}

	private static ASTUtil.FilterPredicate FROM_ELEMENT_PREDICATE = new ASTUtil.IncludePredicate() {
		public boolean include(AST node) {
			FromElement fromElement = ( FromElement ) node;
			return fromElement.isFromOrJoinFragment();
		}
	};

	private static ASTUtil.FilterPredicate PROJECTION_LIST_PREDICATE = new ASTUtil.IncludePredicate() {
		public boolean include(AST node) {
			FromElement fromElement = ( FromElement ) node;
			return fromElement.inProjectionList();
		}
	};

	FromElement findCollectionJoin(String path) {
		return ( FromElement ) collectionJoinFromElementsByPath.get( path );
	}

	FromElement findJoinByPath(boolean implicit, String path) {
		Map joinsByPath = getJoinsByPathMap( implicit );
		FromElement elem = ( FromElement ) joinsByPath.get( path );
		return elem;
	}

	private Map getJoinsByPathMap(boolean implicit) {
		return ( implicit ) ? implicitJoinFromElementsByPath : explicitJoinFromElementsByPath;
	}


	/**
	 * Returns true if the from node contains the class alias name.
	 *
	 * @param alias The HQL class alias name.
	 * @return true if the from node contains the class alias name.
	 */
	public boolean containsClassAlias(String alias) {
		return fromElementByClassAlias.keySet().contains( alias );
	}

	/**
	 * Returns true if the from node contains the table alias name.
	 *
	 * @param alias The SQL table alias name.
	 * @return true if the from node contains the table alias name.
	 */
	public boolean containsTableAlias(String alias) {
		return fromElementByTableAlias.keySet().contains( alias );
	}

	public String getDisplayText() {
		return "FromClause{" + super.toString() + "}";
	}

	public void setParentFromClause(FromClause parentFromClause) {
		this.parentFromClause = parentFromClause;
	}

	public boolean isSubQuery() {
		return parentFromClause != null;
	}

	void addJoinByPathMap(boolean implicit, String path, FromElement destination) {
		Map map = getJoinsByPathMap( implicit );
		if ( log.isDebugEnabled() ) {
			log.debug( "addJoinByPathMap() : " + path + " " + ( implicit ? "(implied)" : "(explicit)" ) + " -> " + destination );
		}
		map.put( path, destination );
	}

	void addCollectionJoinFromElementByPath(String path, FromElement destination) {
		if ( log.isDebugEnabled() ) {
			log.debug( "addCollectionJoinFromElementByPath() : " + path + " -> " + destination );
		}
		collectionJoinFromElementsByPath.put( path, destination );	// Add the new node to the map so that we don't create it twice.
	}

	public FromClause getParentFromClause() {
		return parentFromClause;
	}

	public int nextFromElementCounter() {
		return fromElementCounter++;
	}

	void resolve() {
/*
		ASTAppender appender = new ASTAppender(getASTFactory(),this);
		for ( Iterator iterator = impliedElements.iterator(); iterator.hasNext(); ) {
			FromElement child = ( FromElement ) iterator.next();
			if ( log.isDebugEnabled() )
				log.debug( "resolve() : Adding " + child );
			appender.append(child);
		}
*/
/*

		// Make sure that all from elements registered with this FROM clause are actually in the AST.
		ASTIterator iter = new ASTIterator( this );
		Set childrenInTree = new HashSet();
		while (iter.hasNext()) {
			childrenInTree.add( iter.next());
		}
		for ( Iterator iterator = fromElements.iterator(); iterator.hasNext(); ) {
			FromElement fromElement = ( FromElement ) iterator.next();
			if (!childrenInTree.contains( fromElement )) {
				throw new IllegalStateException("Element not in AST: " + fromElement);
			}
		}
*/
	}

	public void addImpliedFromElement(FromElement element) {
		impliedElements.add( element );
	}
}
