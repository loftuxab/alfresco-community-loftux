// $Id: DotNode.java,v 1.72 2005/02/09 14:29:41 oneovthafew Exp $
package org.hibernate.hql.ast;

import antlr.SemanticException;
import antlr.collections.AST;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.QueryException;
import org.hibernate.collection.QueryableCollection;
import org.hibernate.engine.JoinSequence;
import org.hibernate.hql.antlr.SqlTokenTypes;
import org.hibernate.persister.EntityPersister;
import org.hibernate.sql.JoinFragment;
import org.hibernate.type.CollectionType;
import org.hibernate.type.EntityType;
import org.hibernate.type.Type;
import org.hibernate.util.StringHelper;

/**
 * Represents a reference to a property or alias expression.  This should duplicate the relevant behaviors in
 * PathExpressionParser.
 * <hr>
 * User: josh<br>
 * Date: Dec 16, 2003<br>
 * Time: 8:03:09 AM
 */
class DotNode extends FromReferenceNode implements DisplayableNode, SelectExpression {

	/**
	 * A logger for this class.
	 */
	private static final Log log = LogFactory.getLog( DotNode.class );

	public static final int DEREF_UNKNOWN = 0;
	public static final int DEREF_ENTITY = 1;
	public static final int DEREF_COMPONENT = 2;
	public static final int DEREF_COLLECTION = 3;
	public static final int DEREF_PRIMITIVE = 4;
	public static final int DEREF_SHORTCUT = 5;
	public static final int DEREF_JAVA_CONSTANT = 6;

	/**
	 * The identifier that is the name of the property.
	 */
	private String propertyName;
	/**
	 * The full path, to the root alias of this dot node.
	 */
	private String path;
	/**
	 * The unresolved property path relative to this dot node.
	 */
	private String propertyPath;

	/**
	 * The column names that this resolves to.
	 */
	private String[] columns;

	/**
	 * The type of join to create.   Default is an inner join.
	 */
	private int joinType = JoinFragment.INNER_JOIN;

	/**
	 * Fetch join or not.
	 */
	private boolean fetch = false;

	/**
	 * The type of dereference that hapened (DEREF_xxx).
	 */
	private int dereferenceType = DEREF_UNKNOWN;

	private FromElement impliedJoin;

	/**
	 * Sets the join type for the '.' node (JoinFragment.XXX).
	 *
	 * @param joinType
	 * @see JoinFragment
	 */
	public void setJoinType(int joinType) {
		this.joinType = joinType;
	}

	private String[] getColumns() throws QueryException {
		if ( columns == null ) {
			// Use the table fromElement and the property name to get the array of column names.
			String tableAlias = getLhs().getFromElement().getTableAlias();
			columns = getFromElement().toColumns( tableAlias, propertyPath, false );
		}
		return columns;
	}

	public String getDisplayText() {
		StringBuffer buf = new StringBuffer();
		FromElement fromElement = getFromElement();
		buf.append( "{propertyName=" ).append( propertyName );
		buf.append( ",dereferenceType=" ).append( ASTPrinter.getConstantName( getClass(), dereferenceType ) );
		buf.append( ",propertyPath=" ).append( propertyPath );
		buf.append( ",path=" ).append( getPath() );
		if ( fromElement != null ) {
			buf.append( ",tableAlias=" ).append( fromElement.getTableAlias() );
			buf.append( ",className=" ).append( fromElement.getClassName() );
			buf.append( ",classAlias=" ).append( fromElement.getClassAlias() );
		}
		else {
			buf.append( ",no from element" );
		}
		buf.append( '}' );
		return buf.toString();
	}

	/**
	 * Resolves the left hand side of the DOT.
	 *
	 * @throws SemanticException
	 */
	public void resolveFirstChild() throws SemanticException {
		FromReferenceNode lhs = ( FromReferenceNode ) getFirstChild();
		SqlNode property = ( SqlNode ) lhs.getNextSibling();
		switch ( property.getType() ) {
			case SqlTokenTypes.ELEMENTS:
			case SqlTokenTypes.INDICES:
				throw new IllegalStateException( getPath() + " should have been transformed into " + property.getText() + "(" + lhs.getPath() + ")" );
			default:
				break;
		}

		// Set the attributes of the property reference expression.
		String propName = property.getText();
		propertyName = propName;
		// If the uresolved property path isn't set yet, just use the property name.
		if ( propertyPath == null ) {
			propertyPath = propName;
		}
		// Resolve the LHS fully, generate implicit joins.  Pass in the property name so that the resolver can
		// discover foreign key (id) properties.
		lhs.resolve( true, true, null, this );
		setFromElement( lhs.getFromElement() );			// The 'from element' that the property is in.
	}

	public void resolve(boolean generateJoin, boolean implicitJoin, String classAlias, AST parent) throws SemanticException {
		// If this dot has already been resolved, stop now.
		if ( isResolved() ) {
			return;
		}
		Type propertyType = prepareLhs();			// Prepare the left hand side and get the data type.
/*
		if ( log.isDebugEnabled() ) {
			log.debug( "resolve() : propertyName = " + propertyName + " implicitJoin = " + implicitJoin + " generateJoin = " + generateJoin + " parent = " + parent + " propertyType = " + propertyType );
		}
*/
		// If there is no data type for this node, and we're at the end of the path (top most dot node), then
		// this might be a Java constant.
		if ( propertyType == null ) {
			if ( parent == null ) {
				getWalker().getLiteralProcessor().lookupConstant( this );
			}
			// If the propertyType is null and there isn't a parent, just stop now... there was a problem resolving the node anyway.
			return;
		}
		// The property is a component...
		if ( propertyType.isComponentType() ) {
			dereferenceComponent( parent );
		}
		// The property is another class..
		else if ( propertyType.isEntityType() ) {
			dereferenceEntity( ( EntityType ) propertyType, implicitJoin, classAlias, generateJoin, parent );
		}
		// The property is a collection...
		else if ( propertyType.isPersistentCollectionType() ) {
			dereferenceCollection( ( CollectionType ) propertyType, implicitJoin, classAlias );
		}
		else {	// Otherwise, this is a primitive type.
			dereferenceType = DEREF_PRIMITIVE;
			setText( getColumns()[0] );
		}
		setResolved();
	}

	private Type prepareLhs() throws SemanticException {
		FromReferenceNode lhs = getLhs();
		lhs.prepareForDot( propertyName );
		Type propertyType = getDataType();
		return propertyType;
	}

	private void dereferenceCollection(CollectionType collectionType, boolean implicitJoin, String classAlias) throws SemanticException {
		dereferenceType = DEREF_COLLECTION;
		String role = collectionType.getRole();
/*
		if ( log.isDebugEnabled() ) {
			log.debug( "dereferenceCollection() : role = " + role + " classAlias = " + classAlias + " implicitJoin = " + implicitJoin );
			checkForCorrelatedSubquery( "dereferenceCollection" );
		}
*/
		// Create a new table alias that will represent the elements of the collection.
		QueryableCollection queryableCollection = getSessionFactoryHelper().requireQueryableCollection( role );
		FromClause fromClause;
		if ( getWalker().isSubQuery() ) {		// If this is a sub-query, use the current from clause.
			fromClause = getWalker().getCurrentFromClause();
		}
		else {									// Otherwise, use the referenced from clause.
			fromClause = getFromClause();
		}
		String propName = getPath();
		FromElement elem = fromClause.findJoinByPath( implicitJoin, propName );
		if ( elem == null ) {
			FromElementFactory factory = new FromElementFactory( fromClause, getLhs().getFromElement(), propName,
					classAlias, getColumns(), implicitJoin );
			elem = factory.createCollection( queryableCollection, role, joinType, fetch );
			if ( log.isDebugEnabled() ) {
				log.debug( "dereferenceCollection() : Created new FROM element for " + propName + " : " + elem );
			}
		}

		FromElement element = elem;
		setFromElement( element );	// This 'dot' expression now refers to the resulting from element.
		if ( !implicitJoin ) {
			EntityPersister entityPersister = element.getEntityPersister();
			if ( entityPersister != null ) {
				getWalker().addQuerySpaces( entityPersister.getQuerySpaces() );
			}
			getWalker().addQuerySpaces( queryableCollection.getCollectionSpaces() );
		}
	}

	private void dereferenceEntity(EntityType entityType, boolean implicitJoin, String classAlias, boolean generateJoin, AST parent) throws SemanticException {
		checkForCorrelatedSubquery( "dereferenceEntity" );
		// If this is an entity inside a component reference, then generate the join.
		if ( unresolvedComponent( generateJoin ) ) {
			if ( log.isDebugEnabled() ) {
				log.debug( "dereferenceEntity() : resolving unresolved component '" + propertyPath + "' ... " );
			}
			dereferenceEntityJoin( classAlias, entityType, implicitJoin, parent );
			return;
		}

		//NOTE: we avoid joining to the next table if the named property is just the foreign key value
		String property = propertyName;
		DotNode dotParent = null;

		// Use the parent property name, if a parent was specified to look ahead.
		if ( isDotNode( parent ) ) {
			dotParent = ( DotNode ) parent;
			property = dotParent.propertyName;
		}

		boolean joinIsNotNeeded =
				isPrimaryKeyReference( property, entityType ) ||
				isNamedIdPropertyShortcut( entityType, property ) ||
				!generateJoin;

		if ( joinIsNotNeeded ) {
			dereferenceShortcut( property, dotParent );
		}
		else {
			dereferenceEntityJoin( classAlias, entityType, implicitJoin, parent );
		}
	}

	private boolean unresolvedComponent(boolean generateJoin) {
		AST c = getFirstChild();
		if ( generateJoin && isDotNode( c ) ) {
			DotNode dot = ( DotNode ) c;
			if ( dot.dereferenceType == DEREF_COMPONENT || dot.dereferenceType == DEREF_SHORTCUT ) {
				if ( StringHelper.isNotEmpty( propertyPath ) ) {
					return true;
				}
			}
		}
		return false;
	}

	private boolean isDotNode(AST n) {
		return n != null && n.getType() == SqlTokenTypes.DOT;
	}

	private void dereferenceEntityJoin(String classAlias, EntityType propertyType, boolean impliedJoin, AST parent) throws SemanticException {
		dereferenceType = DEREF_ENTITY;
		if ( log.isDebugEnabled() ) {
			log.debug( "dereferenceEntityJoin() : generating join for " + propertyName + " in "
					+ getFromElement().getClassName() + " "
					+ ( ( classAlias == null ) ? "{no alias}" : "(" + classAlias + ")" )
					+ " parent = " + ASTUtil.getDebugString( parent ) );
		}
		// Create a new FROM node for the referenced class.
		String associatedEntityName = propertyType.getAssociatedEntityName();
		String tableAlias = getAliasGenerator().createName( associatedEntityName );
		FromClause fromClause = getFromClause();
		String joinPath = getPath();
		// Use a different map of from elements, depending on whether this is implicit or explicit.  This is because
		// the implicit (implied) joins do not include subclasses, etc.
		FromElement elem = fromClause.findJoinByPath( impliedJoin, joinPath );
		if ( elem == null ) {
			String[] joinColumns = getColumns();

			// If this is an implied join in a from element, then use the impled join type which is part of the
			// tree parser's state (set by the gramamar actions).
			if ( impliedJoin && getWalker().isInFrom() ) {
				int impliedJoinType = getWalker().getImpliedJoinType();
				joinType = impliedJoinType;
			}
			JoinSequence joinSequence = getSessionFactoryHelper().createJoinSequence( impliedJoin, propertyType, tableAlias,
					joinType, joinColumns );
			FromElementFactory factory = new FromElementFactory( fromClause, getLhs().getFromElement(), joinPath,
					classAlias, joinColumns, impliedJoin );
			elem = factory.createEntityJoin( associatedEntityName, tableAlias, joinSequence, fetch, getWalker().isInFrom(), propertyType );
			// If the parent is null, and we're in the FROM clause, the implied from element needs to be added
			// as a child of the origin FROM element.
			if ( parent != null && parent.getType() == SqlTokenTypes.DOT ) {
				DotNode parentDotNode = ( DotNode ) parent;
				parentDotNode.setImpliedJoin( elem );
			}
		}
		getWalker().addQuerySpaces( elem.getEntityPersister().getQuerySpaces() );
		setFromElement( elem );	// This 'dot' expression now refers to the resulting from element.
/*
		if ( log.isDebugEnabled() ) {
			log.debug( "dereferenceEntityJoin() : fromElement is now " + getFromElement() );
		}
*/
	}

	private void setImpliedJoin(FromElement elem) {
		impliedJoin = elem;
	}

	FromElement getImpliedJoin() {
		return impliedJoin;
	}

	private boolean isPrimaryKeyReference(String property, EntityType propertyType) {
		boolean isIdShortcut = EntityPersister.ENTITY_ID.equals( property ) &&
				propertyType.isReferenceToPrimaryKey();
		return isIdShortcut;
	}

	private boolean isNamedIdPropertyShortcut(EntityType propertyType, String property) {
		final String idPropertyName = getSessionFactoryHelper().getIdentifierOrUniqueKeyPropertyName( propertyType );
		boolean isNamedIdPropertyShortcut = idPropertyName != null && idPropertyName.equals( property );
		return isNamedIdPropertyShortcut;
	}

	private void checkForCorrelatedSubquery(String methodName) {
		if ( isCorrelatedSubselect() ) {
			if ( log.isDebugEnabled() ) {
				log.debug( methodName + "() : correlated subquery" );
			}
		}
	}

	private boolean isCorrelatedSubselect() {
		return getWalker().isSubQuery() && getFromClause() != getWalker().getCurrentFromClause();
	}

	private void dereferenceComponent(AST parent) {
		dereferenceType = DEREF_COMPONENT;
		setPropertyNameAndPath( parent );
	}

	private void dereferenceShortcut(String propertyName, DotNode dotParent) {
		// special shortcut for id properties, skip the join!
		// this must only occur at the _end_ of a path expression
		if ( log.isDebugEnabled() ) {
			log.debug( "dereferenceShortcut() : property " + propertyName + " in " + getFromElement().getClassName() + " does not require a join." );
		}
		String text = getColumns()[0]; 				// Get the columns for the current property.
		setText( text );
		setPropertyNameAndPath( dotParent );		// Set the unresolved path in this node and the parent.
		// Set the text for the parent.
		if ( dotParent != null ) {
			dotParent.dereferenceType = DEREF_SHORTCUT;
			dotParent.setText( text );
			dotParent.columns = new String[]{text};	// Use the text as the 'columns' for the parent dot node.
		}
	}

	private void setPropertyNameAndPath(AST parent) {
		if ( isDotNode( parent ) ) {
			DotNode dotNode = ( DotNode ) parent;
			AST lhs = dotNode.getFirstChild();
			AST rhs = lhs.getNextSibling();
			propertyName = rhs.getText();
			propertyPath = propertyPath + "." + propertyName; // Append the new property name onto the unresolved path.
			dotNode.propertyPath = propertyPath;
			if ( log.isDebugEnabled() ) {
				log.debug( "Unresolved property path is now '" + dotNode.propertyPath + "'" );
			}
		}
		else {
			// Handle "select foo.component from Foo foo", or even "where foo.component = bar.component"
			AST lhs = getFirstChild();
			AST rhs = lhs.getNextSibling();
			propertyPath = rhs.getText();
		}
	}

	public Type getDataType() {
		if ( super.getDataType() == null ) {
			FromElement fromElement = getLhs().getFromElement();
			if ( fromElement == null ) {
				return null;
			}
			// If the lhs is a collection, use CollectionPropertyMapping
			Type propertyType = fromElement.getPropertyType( propertyName, propertyPath );
			if ( log.isDebugEnabled() ) {
				log.debug( "getDataType() : " + propertyPath + " -> " + propertyType );
			}
			super.setDataType( propertyType );
		}
		return super.getDataType();
	}

	FromReferenceNode getLhs() {
		FromReferenceNode lhs = ( ( FromReferenceNode ) getFirstChild() );
		if ( lhs == null ) {
			throw new IllegalStateException( "DOT node with no left-hand-side!" );
		}
		return lhs;
	}

	/**
	 * Returns the full path of the node.
	 *
	 * @return the full path of the node.
	 */
	public String getPath() {
		if ( path == null ) {
			FromReferenceNode lhs = getLhs();
			if ( lhs == null ) {
				path = getText();
			}
			else {
				SqlNode rhs = ( SqlNode ) lhs.getNextSibling();
				path = lhs.getPath() + "." + rhs.getOriginalText();
			}
		}
		return path;
	}

	public void setFetch(boolean fetch) {
		this.fetch = fetch;
	}

	public void setScalarColumnText(int i) throws SemanticException {
		String[] sqlColumns = getColumns();
		ColumnHelper.generateScalarColumns( this, sqlColumns, i );
	}

	/**
	 * Special method to resolve expressions in the SELECT list.
	 *
	 * @param useThetaStyleImplicitJoins True for classic-style theta joins.
	 * @throws SemanticException if this cannot be resolved.
	 */
	public void resolveSelectExpression(boolean useThetaStyleImplicitJoins) throws SemanticException {
		if ( getWalker().isShallowQuery() ) {
			resolve( false, true, null );
		}
		else {
			resolve( true, false, null );
			Type type = getDataType();
			if ( type.isEntityType() ) {
				FromElement fromElement = getFromElement();
				fromElement.setIncludeSubclasses( true ); // Tell the destination fromElement to 'includeSubclasses'.
				if ( useThetaStyleImplicitJoins ) {
					fromElement.getJoinSequence().setUseThetaStyle( true );	// Use theta style (for regression)
					// Move the node up, after the origin node.
					FromElement origin = fromElement.getOrigin();
					if ( origin != null ) {
						ASTUtil.makeSiblingOfParent( origin, fromElement );
					}
				}
			}
		}
	}

	public void setResolvedConstant(String text) {
		path = text;
		dereferenceType = DEREF_JAVA_CONSTANT;
		setResolved();			// Don't resolve the node again.
	}
}
