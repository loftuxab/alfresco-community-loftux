// $Id: LiteralNode.java,v 1.1 2005/01/12 13:02:15 pgmjsd Exp $
package org.hibernate.hql.ast;

import antlr.SemanticException;

/**
 * Represents a literal.
 *
 * @author josh Jan 8, 2005 10:09:53 AM
 */
public class LiteralNode extends AbstractSelectExpression {
	public void setScalarColumnText(int i) throws SemanticException {
		// TODO: Implement this method.
	}
}
