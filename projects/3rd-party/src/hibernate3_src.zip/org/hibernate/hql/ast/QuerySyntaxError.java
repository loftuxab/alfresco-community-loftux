// $Id: QuerySyntaxError.java,v 1.4 2005/01/12 13:02:15 pgmjsd Exp $
package org.hibernate.hql.ast;

import antlr.RecognitionException;
import org.hibernate.QueryException;

/**
 * Exception thrown when there is a syntax error in the HQL.
 *
 * @author josh Dec 5, 2004 7:22:54 PM
 */
public class QuerySyntaxError extends QueryException {
	public QuerySyntaxError(RecognitionException e) {
		super( e.getMessage() + (
				( e.getLine() > 0 && e.getColumn() > 0 ) ?
				( " near line " + e.getLine() + ", column " + e.getColumn() ) : ""
				), e );
	}

	public QuerySyntaxError(RecognitionException e, String hql) {
		super( e.getMessage() + (
				( e.getLine() > 0 && e.getColumn() > 0 ) ?
				( " near line " + e.getLine() + ", column " + e.getColumn() ) : ""
				), e );
		setQueryString( hql );
	}
}
