// $Id: FromElementFactory.java,v 1.32 2005/02/09 14:36:44 oneovthafew Exp $
package org.hibernate.hql.ast;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.collection.QueryableCollection;
import org.hibernate.engine.JoinSequence;
import org.hibernate.hql.antlr.SqlTokenTypes;
import org.hibernate.persister.EntityPersister;
import org.hibernate.persister.Joinable;
import org.hibernate.persister.Queryable;
import org.hibernate.sql.JoinFragment;
import org.hibernate.type.AssociationType;
import org.hibernate.type.CollectionType;
import org.hibernate.type.EntityType;
import org.hibernate.type.Type;

import antlr.ASTFactory;
import antlr.SemanticException;
import antlr.collections.AST;

/**
 * Encapsulates the creation of FromElements and JoinSequences.
 *
 * @author josh Oct 12, 2004 4:54:25 AM
 */
class FromElementFactory implements SqlTokenTypes {

	/**
	 * A logger for this class. *
	 */
	private static final Log log = LogFactory.getLog( FromElementFactory.class );

	private FromClause fromClause;
	private FromElement origin;
	private String path;

	private String classAlias;
	private String[] columns;
	private boolean implied;
	private boolean collection;
	private QueryableCollection queryableCollection;
	private CollectionType collectionType;

	/**
	 * Creates entity from elements.
	 */
	public FromElementFactory(FromClause fromClause, FromElement origin, String path) {
		this.fromClause = fromClause;
		this.origin = origin;
		this.path = path;
		collection = false;
	}

	/**
	 * Creates collection from elements.
	 */
	public FromElementFactory(FromClause fromClause, FromElement origin, String path, String classAlias, String[] columns, boolean impliedJoin) {
		this( fromClause, origin, path );
		this.classAlias = classAlias;
		this.columns = columns;
		this.implied = impliedJoin;
		collection = true;
	}

	FromElement addFromElement() throws SemanticException {
		FromClause parentFromClause = fromClause.getParentFromClause();
		if ( parentFromClause != null ) {
			// Look up class name using the first identifier in the path.
			String pathAlias = PathHelper.getAlias( path );
			FromElement parentFromElement = parentFromClause.getFromElement( pathAlias );
			if ( parentFromElement != null ) {
				return createFromElementInSubselect( path, pathAlias, parentFromElement, classAlias );
			} // if (parentFromElement != null)
		} // if (parentFromClause != null)

		EntityPersister entityPersister = fromClause.getSessionFactoryHelper().requireClassPersister( path );

		FromElement elem = createAndAddFromElement( path,
				classAlias,
				entityPersister,
				(EntityType) ( (Queryable) entityPersister ).getType(),
				null );

		// Add to the query spaces.
		fromClause.getWalker().addQuerySpaces( entityPersister.getQuerySpaces() );

		return elem;
	}

	private FromElement createFromElementInSubselect(String path, String pathAlias, FromElement parentFromElement, String classAlias) throws SemanticException {
		// Create an DotNode AST for the path and resolve it.
		FromElement fromElement = evaluateFromElementPath( path );
		EntityPersister entityPersister = fromElement.getEntityPersister();
		// If the first identifier in the path referrs to the class alias (not the class name), then this
		// is a correlated subselect.
		String tableAlias = null;
		boolean correlatedSubselect = pathAlias.equals( parentFromElement.getClassAlias() );
		if ( correlatedSubselect ) {
			tableAlias = fromElement.getTableAlias();
/*
			if ( log.isDebugEnabled() ) {
				log.debug( "createFromElementInSubselect() : correllated sub-select, using table alias " + tableAlias + " for path " + path );
			}
*/
		}
		else {
/*
			if ( log.isDebugEnabled() ) {
				log.debug( "createFromElementInSubselect() : uncorrellated sub-select, a new table alias will be generated for path " + path );
			}
*/
			tableAlias = null;
		}
		if ( fromElement.getFromClause() != fromClause ) {
/*
			if ( log.isDebugEnabled() ) {
				log.debug( "createFromElementInSubselect() : Creating new FromElement..." );
			}
*/
			fromElement = createFromElement( entityPersister );
		}
		initializeAndAddFromElement( 
				fromElement, 
				path, 
				classAlias, 
				entityPersister, 
				(EntityType) ( (Queryable) entityPersister ).getType(),
				tableAlias );
		return fromElement;
	}

	private FromElement evaluateFromElementPath(String path) throws SemanticException {
		ASTFactory factory = fromClause.getASTFactory();
		FromReferenceNode pathNode = ( FromReferenceNode ) PathHelper.parsePath( path, factory );
		pathNode.recursiveResolve();
		FromElement fromElement = pathNode.getFromElement();
		fromElement.setImplied( false );	// Paths in the FROM clause are 'explicit'.
		return fromElement;
	}

	FromElement createCollectionElementsJoin(QueryableCollection queryableCollection, String collectionName) throws SemanticException {
		JoinSequence collectionJoinSequence = fromClause.getSessionFactoryHelper().createCollectionJoinSequence( queryableCollection, collectionName );
		this.queryableCollection = queryableCollection;
		return createCollectionJoin( collectionJoinSequence, null );
	}

	FromElement createCollection(QueryableCollection queryableCollection, String role, int joinType, boolean fetchFlag) throws SemanticException {
		if ( !collection ) {
			throw new IllegalStateException( "FromElementFactory not initialized for collections!" );
		}
		FromElement elem;
		this.queryableCollection = queryableCollection;
		collectionType = queryableCollection.getCollectionType();
		String roleAlias = fromClause.getAliasGenerator().createName( role );

		if ( fromClause.isSubQuery() ) {
/*
			if ( log.isDebugEnabled() ) {
				log.debug( "createCollection() : in sub-query, using implied (theta-style) join." );
			}
*/
			implied = true;
		}

		Type elementType = queryableCollection.getElementType();
		if ( elementType.isEntityType() ) { 			// A collection of entities...
			elem = createEntityAssociation( role, roleAlias, joinType );
		}
		else if ( elementType.isComponentType() ) {		// A collection of components...
			JoinSequence joinSequence = createJoinSequence( roleAlias, joinType );
			elem = createCollectionJoin( joinSequence, roleAlias );
		}
		else {											// A collection of scalar elements...
			JoinSequence joinSequence = createJoinSequence( roleAlias, joinType );
			elem = createCollectionJoin( joinSequence, roleAlias );
		}

		elem.setRole( role );
		elem.setQueryableCollection( queryableCollection );
		// Don't include sub-classes for implied collection joins.
		if ( implied ) {
			elem.setIncludeSubclasses( false );
		}
		if ( fetchFlag ) {
			elem.setSelectFragment( queryableCollection.selectFragment( roleAlias ) );
			elem.setFetch( true );
		}
		return elem;
	}

	FromElement createEntityJoin(
			String entityClass, 
			String tableAlias, 
			JoinSequence joinSequence, 
			boolean fetchFlag, 
			boolean inFrom,
			EntityType type) 
	throws SemanticException {
		FromElement elem = createJoin( entityClass, tableAlias, joinSequence, type );
		elem.setFetch( fetchFlag );
		EntityPersister entityPersister = elem.getEntityPersister();
		int numberOfTables = entityPersister.getQuerySpaces().length;
		if ( numberOfTables > 1 && implied && !elem.useFromFragment() ) {
			if ( log.isDebugEnabled() ) {
				log.debug( "createEntityJoin() : Implied multi-table entity join" );
			}
			elem.setUseFromFragment( true );
		}

		// If this is an implied join in a FROM clause, then use ANSI-style joining, and set the
		// flag on the FromElement that indicates that it was implied in the FROM clause itself.
		if ( implied && inFrom ) {
			joinSequence.setUseThetaStyle( false );
			elem.setUseFromFragment( true );
			elem.setImpliedInFromClause( true );
		}
		return elem;
	}

	FromElement createElementJoin(QueryableCollection queryableCollection) throws SemanticException {
		FromElement elem;

		implied = true;
		Type elementType = queryableCollection.getElementType();
		if ( !elementType.isEntityType() ) {
			throw new IllegalArgumentException( "Cannot create element join for a collection of non-entities!" );
		}
		this.queryableCollection = queryableCollection;
		SessionFactoryHelper sfh = fromClause.getSessionFactoryHelper();
		FromElement destination = null;
		String tableAlias = null;
		EntityPersister entityPersister = queryableCollection.getElementPersister();
		tableAlias = fromClause.getAliasGenerator().createName( entityPersister.getEntityName() );
		String associatedEntityName = entityPersister.getEntityName();
		EntityPersister targetEntityPersister = sfh.requireClassPersister( associatedEntityName );
		// Create the FROM element for the target (the elements of the collection).
		destination = createAndAddFromElement( 
				associatedEntityName, 
				classAlias, 
				targetEntityPersister, 
				(EntityType) queryableCollection.getElementType(),
				tableAlias );
		// If the join is implied, then don't include sub-classes on the element.
		if ( implied ) {
			destination.setIncludeSubclasses( false );
		}
		fromClause.addCollectionJoinFromElementByPath( path, destination );
		addFromElement( true, destination, origin );
		// Add the query spaces.
		fromClause.getWalker().addQuerySpaces( entityPersister.getQuerySpaces() );

		CollectionType collectionType = queryableCollection.getCollectionType();
		String role = collectionType.getRole();
		String roleAlias = origin.getTableAlias();

		String[] targetColumns = sfh.getCollectionElementColumns( role, roleAlias );
		AssociationType elementAssociationType = sfh.getElementAssociationType( collectionType );

		// Create the join element under the from element.
		int joinType = JoinFragment.INNER_JOIN;
		JoinSequence joinSequence = sfh.createJoinSequence( implied, elementAssociationType, tableAlias, joinType, targetColumns );
		elem = initializeJoin( implied, path, destination, joinSequence, targetColumns, origin );
		elem.setUseFromFragment( true );	// The associated entity is implied, but it must be included in the FROM.
		elem.setCollectionTableAlias( roleAlias );	// The collection alias is the role.
		return elem;
	}

	private FromElement createCollectionJoin(JoinSequence collectionJoinSequence, String tableAlias) throws SemanticException {
		AST ast = ASTUtil.create( fromClause.getASTFactory(), FROM_FRAGMENT, queryableCollection.getTableName() );
		FromElement destination = ( FromElement ) ast;
		Type elementType = queryableCollection.getElementType();
		if ( elementType.isPersistentCollectionType() ) {
			throw new SemanticException( "Collections of collections are not supported!" );
		}
		destination.initializeCollection( fromClause, classAlias, tableAlias );
		destination.setType( JOIN_FRAGMENT );		// Tag this node as a JOIN.
		destination.setIncludeSubclasses( false );	// Don't include subclasses in the join.
		destination.setCollectionJoin( true );		// This is a clollection join.
		destination.setJoinSequence( collectionJoinSequence );
		destination.setOrigin( origin );
		origin.addChild( destination );				// Add collection join nodes as a child of the FROM element.
		origin.setType( FROM_FRAGMENT );			// Set the parent node type so that the AST is properly formed.
		origin.setText( "" );						// The destination node will have all the FROM text.
		origin.setCollectionJoin( true );			// The parent node is a collection join too (voodoo - see JoinProcessor)
		fromClause.addCollectionJoinFromElementByPath( path, destination );
		fromClause.getWalker().addQuerySpaces( queryableCollection.getCollectionSpaces() );
		return destination;
	}

	private FromElement createEntityAssociation(String role,
												String roleAlias,
												int joinType) throws SemanticException {
		FromElement elem;
		Queryable entityPersister = ( Queryable ) queryableCollection.getElementPersister();
		String associatedEntityName = entityPersister.getEntityName();
		// Get the class name of the associated entity.
		if ( queryableCollection.isOneToMany() ) {
			if ( log.isDebugEnabled() ) {
				log.debug( "createEntityAssociation() : One to many - path = " + path + " role = " + role + " associatedEntityName = " + associatedEntityName );
			}
			JoinSequence joinSequence = createJoinSequence( roleAlias, joinType );

			elem = createJoin( associatedEntityName, roleAlias, joinSequence, (EntityType) queryableCollection.getElementType() );
		}
		else {
			elem = createManyToMany( role, associatedEntityName,
					roleAlias, entityPersister, (EntityType) queryableCollection.getElementType(), joinType );
			fromClause.getWalker().addQuerySpaces( queryableCollection.getCollectionSpaces() );
		}
		return elem;
	}

	private FromElement createManyToMany(String role, 
										 String associatedEntityName,
										 String roleAlias,
										 Queryable entityPersister,
										 EntityType type,
										 int joinType) throws SemanticException {
		if ( log.isDebugEnabled() ) {
			log.debug( "createManyToMany() : path = " + path + " role = " + role + " associatedEntityName = " + associatedEntityName );
		}
		FromElement elem;
		SessionFactoryHelper sfh = fromClause.getSessionFactoryHelper();
		if ( implied ) {
			// For implied many-to-many, just add the end join.
			JoinSequence joinSequence = createJoinSequence( roleAlias, joinType );
			elem = createJoin( associatedEntityName, roleAlias, joinSequence, type);
		}
		else {
			// For an explicit Many-to-many relationship, add a second join from the intermediate (many-to-many) table to the
			// destination table.  Also, make sure that the from element's idea of the destination is the destination
			// table.
			String tableAlias = fromClause.getAliasGenerator().createName( entityPersister.getEntityName() );
			String[] secondJoinColumns = sfh.getCollectionElementColumns( role, roleAlias );
			// Add the second join, the one that ends in the destination table.
			JoinSequence joinSequence = createJoinSequence( roleAlias, joinType );
			joinSequence.addJoin( sfh.getElementAssociationType( collectionType ), tableAlias, joinType, secondJoinColumns );
			elem = createJoin( associatedEntityName, tableAlias, joinSequence, type );
		}
		return elem;
	}

	private JoinSequence createJoinSequence(String roleAlias, int joinType) {
		SessionFactoryHelper sessionFactoryHelper = fromClause.getSessionFactoryHelper();
		String[] joinColumns = getColumns();
		if ( collectionType == null ) {
			throw new IllegalStateException( "collectionType is null!" );
		}
		return sessionFactoryHelper.createJoinSequence( implied, collectionType, roleAlias, joinType, joinColumns );
	}

	private FromElement createAndAddFromElement(String className,
												String classAlias,
												EntityPersister entityPersister, 
												EntityType type,
												String tableAlias) {
		if ( !( entityPersister instanceof Joinable ) ) {
			throw new IllegalArgumentException( "EntityPersister " + entityPersister + " does not implement Joinable!" );
		}

		FromElement element = createFromElement( entityPersister );

		initializeAndAddFromElement( element, className, classAlias, entityPersister, type, tableAlias );

		return element;
	}

	private void initializeAndAddFromElement(
			FromElement element, 
			String className, 
			String classAlias, 
			EntityPersister entityPersister, 
			EntityType type, 
			String tableAlias) {
		if ( tableAlias == null ) {
			AliasGenerator aliasGenerator = fromClause.getAliasGenerator();
			tableAlias = aliasGenerator.createName( entityPersister.getEntityName() );
		}
		element.initializeEntity( fromClause, className, entityPersister, type, classAlias, tableAlias );
	}

	private FromElement createFromElement(EntityPersister entityPersister) {
		Joinable joinable = ( Joinable ) entityPersister;
		AST ast = ASTUtil.create( fromClause.getASTFactory(), FROM_FRAGMENT, joinable.getTableName() );
		FromElement element = ( FromElement ) ast;
		return element;
	}

	private FromElement createJoin(String entityClass, String tableAlias, JoinSequence joinSequence, EntityType type) 
	throws SemanticException {
		//  origin, path, implied, columns, classAlias,
		EntityPersister entityPersister = fromClause.getSessionFactoryHelper().requireClassPersister( entityClass );
		FromElement destination = createAndAddFromElement( 
				entityClass, 
				classAlias, 
				entityPersister, 
				type,
				tableAlias );
		addFromElement( implied, destination, origin );
		return initializeJoin( implied, path, destination, joinSequence, getColumns(), origin );
	}

	private void addFromElement(boolean implicit, FromElement destination, FromElement origin) {
		if ( implicit ) {
			fromClause.addChild( destination );		// Add implied join nodes as a child of the FROM clause itself.
		}
		else {
			origin.addChild( destination );			// Add explicit join nodes as a child of the FROM element.
		}
	}

	private FromElement initializeJoin(boolean implicit, String path, FromElement destination, JoinSequence joinSequence, String[] columns, FromElement origin) {
		destination.setType( JOIN_FRAGMENT );
		destination.setImplied( implicit );
		destination.setJoinSequence( joinSequence );
		destination.setColumns( columns );
		destination.setOrigin( origin );
		fromClause.addJoinByPathMap( implicit, path, destination );
		return destination;
	}

	private String[] getColumns() {
		if ( columns == null ) {
			throw new IllegalStateException( "No foriegn key columns were supplied!" );
		}
		return columns;
	}
}
