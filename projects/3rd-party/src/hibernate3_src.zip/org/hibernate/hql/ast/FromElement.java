// $Id: FromElement.java,v 1.57 2005/02/09 14:29:41 oneovthafew Exp $
package org.hibernate.hql.ast;

import java.util.Arrays;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.MappingException;
import org.hibernate.QueryException;
import org.hibernate.collection.CollectionPropertyMapping;
import org.hibernate.collection.QueryableCollection;
import org.hibernate.engine.JoinSequence;
import org.hibernate.hql.CollectionProperties;
import org.hibernate.hql.CollectionSubqueryFactory;
import org.hibernate.hql.NameGenerator;
import org.hibernate.hql.QueryTranslator;
import org.hibernate.hql.antlr.SqlTokenTypes;
import org.hibernate.persister.EntityPersister;
import org.hibernate.persister.Joinable;
import org.hibernate.persister.PropertyMapping;
import org.hibernate.persister.Queryable;
import org.hibernate.type.EntityType;
import org.hibernate.type.Type;

/**
 * Represents a single mapped class mentioned in an HQL FROM clause.  Each
 * class reference will have the following symbols:
 * <ul>
 * <li>A class name - This is the name of the Java class that is mapped by Hibernate.</li>
 * <li>[optional] an HQL alias for the mapped class.</li>
 * <li>A table name - The name of the table that is mapped to the Java class.</li>
 * <li>A table alias - The alias for the table that will be used in the resulting SQL.</li>
 * </ul>
 * <br>
 * User: josh<br>
 * Date: Dec 6, 2003<br>
 * Time: 10:28:17 AM<br>
 */
public class FromElement extends HqlSqlWalkerNode implements DisplayableNode {
	private static final Log log = LogFactory.getLog( FromElement.class );

	/**
	 * The HQL class name (as it exists in the HQL). *
	 */
	private String className;
	/**
	 * The HQL class alias. *
	 */
	private String classAlias;
	/**
	 * The SQL table alias.
	 */
	private String tableAlias;

	/**
	 * The alias of the collection table.
	 */
	private String collectionTableAlias;
	/**
	 * The FROM statement that this element belongs to. *
	 */
	private FromClause fromClause;

	/**
	 * The select SQL fragment that is part of a 'fetch' join. *
	 */
	private String selectFragment;

	/**
	 * True if this this element should generate sub-class joins.
	 */
	private boolean includeSubclasses = true;
	/**
	 * True if this element is a collection join.
	 */
	private boolean collectionJoin = false;

	/**
	 * The origin from element, if this is a join.  Null otherwise.
	 */
	private FromElement origin;
	
	private EntityType entityType;
	private EntityPersister persister;
	private QueryableCollection queryableCollection;
	private CollectionPropertyMapping collectionPropertyMapping;
	private JoinSequence joinSequence;
	private String role;
	private String[] columns;
	/**
	 * True if this is a FETCH join.
	 */
	private boolean fetch;
	/**
	 * True if this from element is due to filter compilation. *
	 */
	private boolean filter = false;

	/**
	 * The sequence of the from element in the from clause. *
	 */
	private int sequence = -1;

	/**
	 * True if this from element was implied from a path.
	 * False if this from element is explicitly declared in the FROM clause.
	 */
	private boolean implied = false;

	/**
	 * True if this from element was implied from a path in the FROM clause, but not
	 * explicitly declard in the from clause.
	 */
	private boolean impliedInFromClause = false;

	/**
	 * True if this is a many to many join with an implied target entity.
	 */
	private boolean useFromFragment = false;

	/**
	 * Keeps track of initialization status, because it's inconvenient to use
	 * constructor initialization with an ANTLR node factory.
	 */
	private boolean initialized = false;

	public FromElement() {
	}

	void initializeCollection(FromClause fromClause, String classAlias, String tableAlias) {
		doInitialize( fromClause, tableAlias, null, classAlias, null, null );
		initialized = true;
	}

	private void doInitialize(FromClause fromClause, String tableAlias, String className, String classAlias,
							  EntityPersister persister, EntityType type) {
		this.fromClause = fromClause;
		this.tableAlias = tableAlias;
		this.className = className;
		this.classAlias = classAlias;
		this.entityType = type;
		this.persister = persister;
		if ( persister != null ) {
			setText( ( ( Queryable ) persister ).getTableName() + " " + getTableAlias() );
		}
		// Register the FromElement with the FROM clause, now that we have the names and aliases.
		fromClause.registerFromElement( this );
		if ( log.isDebugEnabled() ) {
			log.debug( className + " ("
					+ ( classAlias == null ? "no alias" : classAlias ) + ") -> " + tableAlias );
		}
	}

	void initializeEntity(FromClause fromClause,
						  String className,
						  EntityPersister persister,
						  EntityType type,
						  String classAlias,
						  String tableAlias) {
		doInitialize( fromClause, tableAlias, className, classAlias, persister, type );
		this.sequence = fromClause.nextFromElementCounter();
		//setDataType( TypeFactory.manyToOne( persister.getEntityName() ) ); //TODO: is this safe?????
		initialized = true;
	}

	public EntityPersister getEntityPersister() {
		return persister;
	}

	public Type getDataType() {
		if ( persister == null ) {
			if ( queryableCollection == null ) {
				return null;
			}
			return queryableCollection.getType();
		}
		else {
			return entityType;
		}
	}
	
	public Type getSelectType() {
		if ( persister == null ) {
			if ( queryableCollection == null ) {
				return null;
			}
			return queryableCollection.getType();
		}
		else {
			return ( ( Queryable ) persister ).getType();
		}
	}

	/**
	 * Returns the Hibernate queryable implementation for the HQL class.
	 *
	 * @return the Hibernate queryable implementation for the HQL class.
	 */
	public Queryable getQueryable() {
		return ( persister instanceof Queryable ) ? ( Queryable ) persister : null;
	}

	/**
	 * Returns the name of the HQL mapped class (in the FROM clause).
	 *
	 * @return the name of the HQL mapped class (in the FROM clause).
	 */
	public String getClassName() {
		return className;
	}

	/**
	 * Returns the alias name for the HQL class (in the FROM clause).
	 *
	 * @return the alias name for the HQL class (in the FROM clause).
	 */
	public String getClassAlias() {
		return classAlias == null ? className : classAlias;
	}

	private String getTableName() {
		Queryable queryable = getQueryable();
		return ( queryable != null ) ? queryable.getTableName() : "{none}";
	}

	/**
	 * Returns the SQL alias for the table that the class is mapped to.
	 *
	 * @return the SQL alias for the table that the class is mapped to.
	 */
	public String getTableAlias() {
		return tableAlias;
	}

	/**
	 * Render the identifier select, but in a 'scalar' context (i.e. generate the column alias).
	 *
	 * @param i the sequence of the returned type
	 * @return the identifier select with the column alias.
	 */
	String renderScalarIdentifierSelect(int i) {
		checkInitialized();
		String[] cols = getPropertyMapping( EntityPersister.ENTITY_ID ).toColumns( getTableAlias(), EntityPersister.ENTITY_ID );
		StringBuffer buf = new StringBuffer();
		// For property references generate <tablealias>.<columnname> as <projectionalias>
		for ( int j = 0; j < cols.length; j++ ) {
			String column = cols[j];
			if ( j > 0 ) {
				buf.append( ", " );
			}
			buf.append( column ).append( " as " ).append( NameGenerator.scalarName( i, j ) );
		}
		return buf.toString();
	}

	private void checkInitialized() {
		if ( !initialized ) {
			throw new IllegalStateException( "FromElement has not been initialized!" );
		}
	}

	/**
	 * Returns the identifier select SQL fragment.
	 *
	 * @param size The total number of returned types.
	 * @param k    The sequence of the current returned type.
	 * @return the identifier select SQL fragment.
	 */
	String renderIdentifierSelect(int size, int k) {
		checkInitialized();
		// Render the identifier select fragment using the table alias.
		if ( fromClause.isSubQuery() ) {
			// TODO: Replace this with a more elegant solution.
			String[] idColumnNames = ( persister != null ) ?
					( ( Queryable ) persister ).getIdentifierColumnNames() : new String[0];
			StringBuffer buf = new StringBuffer();
			for ( int i = 0; i < idColumnNames.length; i++ ) {
				buf.append( getTableAlias() ).append( '.' ).append( idColumnNames[i] );
				if ( i != idColumnNames.length - 1 ) buf.append( ", " );
			}
			return buf.toString();
		}
		else {
			String fragment = ( persister != null ) ?
					( ( Queryable ) persister ).identifierSelectFragment( getTableAlias(), getSuffix( size, k ) ) : "";
			return trimLeadingCommaAndSpaces( fragment );
		}
	}

	/**
	 * Returns the property select SQL fragment.
	 *
	 * @param size The total number of returned types.
	 * @param k    The sequence of the current returned type.
	 * @return the property select SQL fragment.
	 */
	String renderPropertySelect(int size, int k) {
		checkInitialized();
		String fragment = ( persister != null ) ?
				( ( Queryable ) persister ).propertySelectFragment( getTableAlias(), getSuffix( size, k ) ) : "";
		return trimLeadingCommaAndSpaces( fragment );
	}

	/**
	 * This accounts for a quirk in Queryable, where it sometimes generates ',  ' in front of the
	 * SQL fragment.  :-P
	 *
	 * @param fragment An SQL fragment.
	 * @return The fragment, without the leading comma and spaces.
	 */
	private static String trimLeadingCommaAndSpaces(String fragment) {
		if ( fragment.length() > 0 && fragment.charAt( 0 ) == ',' ) {
			fragment = fragment.substring( 1 );
		}
		fragment = fragment.trim();
		return fragment.trim();
	}

	public FromClause getFromClause() {
		return fromClause;
	}

	/**
	 * Returns true if this FromElement was implied by a path, or false if this FROM element is explicitly declared in
	 * the FROM clause.
	 *
	 * @return true if this FromElement was implied by a path, or false if this FROM element is explicitly declared
	 */
	boolean isImplied() {
		return implied;
	}

	void setImplied(boolean implied) {
		this.implied = implied;
	}

	/**
	 * Returns additional display text for the AST node.
	 *
	 * @return String - The additional display text.
	 */
	public String getDisplayText() {
		StringBuffer buf = new StringBuffer();
		buf.append( "FromElement{className=" ).append( className );
		buf.append( "," ).append( isImplied() ? (
				isImpliedInFromClause() ? "implied in FROM clause" : "implied" )
				: "explicit" );
		buf.append( "," ).append( isCollectionJoin() ? "collection join" : "not a collection join" );
		buf.append( ",classAlias=" ).append( getClassAlias() );
		buf.append( ",tableName=" ).append( getTableName() );
		buf.append( ",tableAlias=" ).append( getTableAlias() );
		buf.append( ",colums={" );
		if ( columns != null ) {
			for ( int i = 0; i < columns.length; i++ ) {
				buf.append( columns[i] );
				if ( i < columns.length ) {
					buf.append( " " );
				}
			}
		}
		buf.append( "}" );
		buf.append( "}" );
		return buf.toString();
	}

	public int hashCode() {
		return super.hashCode();
//		return className.hashCode();
	}

	public boolean equals(Object obj) {
		return super.equals( obj );
//		if ( obj instanceof FromElement ) {
//			FromElement tableAliasNode = ( FromElement ) obj;
//			return className.equals( tableAliasNode.className )
//					&& tableAlias.equals( tableAliasNode.tableAlias );
//		}
//		else {
//			return super.equals( obj );
//		}
	}

	private static String getSuffix(int size, int k) {
		String suffix = size == 1 ? "" : Integer.toString( k ) + '_';
		return suffix;
	}

	public void setJoinSequence(JoinSequence joinSequence) {
		this.joinSequence = joinSequence;
	}

	public JoinSequence getJoinSequence() {
		if ( joinSequence != null ) {
			return joinSequence;
		}
		
		// Class names in the FROM clause result in a JoinSequence (the old FromParser does this).
		if ( persister instanceof Joinable ) {
			Joinable joinable = ( Joinable ) persister;
			return getSessionFactoryHelper().createJoinSequence().setRoot( joinable, getTableAlias() );
		}
		else {
			return null;	// TODO: Should this really return null?  If not, figure out something better to do here.
		}
	}

	public String renderCollectionSelectFragment() {
		return selectFragment;
	}

	public void setSelectFragment(String selectFragment) {
		this.selectFragment = selectFragment;
	}

	public void setIncludeSubclasses(boolean includeSubclasses) {
		this.includeSubclasses = includeSubclasses;
	}

	public boolean isIncludeSubclasses() {
		return includeSubclasses;
	}

	public String getIdentityColumn() {
		checkInitialized();
		String table = getTableAlias();
		if ( table == null ) {
			throw new IllegalStateException( "No table alias for node " + this );
		}
		String[] cols = getPropertyMapping( EntityPersister.ENTITY_ID ).toColumns( table, EntityPersister.ENTITY_ID );
		if ( cols.length > 1 ) {
			StringBuffer buf = new StringBuffer();
			buf.append( "{composite id for " ).append( classAlias ).append( '}' );
			return buf.toString();
		}
		return cols[0];
	}

	public void setCollectionJoin(boolean collectionJoin) {
		this.collectionJoin = collectionJoin;
	}

	public boolean isCollectionJoin() {
		return collectionJoin;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public void setQueryableCollection(QueryableCollection queryableCollection) {
		if ( this.queryableCollection != null ) {
			throw new IllegalStateException( "QueryableCollection is already defined for " + this + "!" );
		}
		this.queryableCollection = queryableCollection;
		if ( !queryableCollection.isOneToMany() ) {
			// For many-to-many joins, use the tablename from the queryable collection for the default text.
			setText( queryableCollection.getTableName() + " " + getTableAlias() );
		}
	}

	public QueryableCollection getQueryableCollection() {
		return queryableCollection;
	}

	public void setColumns(String[] columns) {
		this.columns = columns;
	}

	public void setOrigin(FromElement origin) {
		this.origin = origin;
	}

	public FromElement getOrigin() {
		return origin;
	}

	/**
	 * Returns the type of a property, given it's name (the last part) and the full path.
	 *
	 * @param propertyName The last part of the full path to the property.
	 * @return The type.
	 * @0param propertyPath The full property path.
	 */
	public Type getPropertyType(String propertyName, String propertyPath) {
		checkInitialized();
		Type type = null;
		// If this is an entity and the property is the identifier property, then use getIdentifierType().
		if ( persister != null && propertyName.equals( persister.getIdentifierPropertyName() ) ) {
			type = persister.getIdentifierType();
		}
		else {	// Otherwise, use the property mapping.
			PropertyMapping mapping = getPropertyMapping( propertyName );
			type = mapping.toType( propertyPath );
		}
		if ( type == null ) {
			throw new MappingException( "Property " + propertyName + " does not exist in " +
					( ( queryableCollection == null ) ? "class" : "collection" ) + " "
					+ ( ( queryableCollection == null ) ? getClassName() : queryableCollection.getRole() ) );
		}
		return type;
	}

	String[] toColumns(String tableAlias, String path, boolean inSelect) {
		checkInitialized();
		PropertyMapping propertyMapping = getPropertyMapping( path );
		// If this from element is a collection and the path is a collection property (maxIndex, etc.) then
		// generate a sub-query.
		if ( !inSelect && queryableCollection != null && CollectionProperties.isCollectionProperty( path ) ) {
			Map enabledFilters = getFromClause().getWalker().getEnabledFilters();
			String subquery = CollectionSubqueryFactory.createCollectionSubquery( joinSequence, enabledFilters,
					propertyMapping.toColumns( tableAlias, path ) );
			if ( log.isDebugEnabled() ) {
				log.debug( "toColumns(" + tableAlias + "," + path + ") : subquery = " + subquery );
			}
			return new String[]{"(" + subquery + ")"};
		}
		else {
			return propertyMapping.toColumns( tableAlias, path );
		}
	}

	PropertyMapping getPropertyMapping(String propertyName) {
		checkInitialized();
		if ( queryableCollection == null ) {		// Not a collection?
			return ( PropertyMapping ) persister;	// Return the entity property mapping.
		}
		// If the property is a special collection property name, return a CollectionPropertyMapping.
		if ( CollectionProperties.isCollectionProperty( propertyName ) ) {
			if ( collectionPropertyMapping == null ) {
				collectionPropertyMapping = new CollectionPropertyMapping( queryableCollection );
			}
			return collectionPropertyMapping;
		}
		if ( queryableCollection.getElementType().isComponentType() ) {	// Collection of components.
			if ( propertyName.equals( EntityPersister.ENTITY_ID ) ) {
				return ( PropertyMapping ) queryableCollection.getOwnerEntityPersister();
			}
		}
		return queryableCollection;
	}

	public void setFetch(boolean fetch) {
		this.fetch = fetch;
		// Fetch can't be used with scroll() or iterate().
		if ( fetch && getFromClause().getWalker().isShallowQuery() ) {
			throw new QueryException( QueryTranslator.ERROR_CANNOT_FETCH_WITH_ITERATE );
		}
	}

	public boolean isFetch() {
		return fetch;
	}

	public int getSequence() {
		return sequence;
	}

	public String toString() {
		return "FromElement{<" + sequence + "> " +
				"tableAlias='" + tableAlias + "'" +
				", className='" + className + "'" +
				", classAlias='" + classAlias + "'" +
				", role='" + role + "'" +
				", includeSubclasses=" + includeSubclasses +
				", collectionJoin=" + collectionJoin +
				", fetch=" + fetch +
				", origin=" + origin +
				", persister=" + persister +
				", queryableCollection=" + queryableCollection +
				", joinSequence=" + joinSequence +
				", columns=" + ( columns == null ? null : Arrays.asList( columns ) ) +
				"}";
	}

	void setFilter(boolean b) {
		filter = b;
	}

	boolean isFilter() {
		return filter;
	}

	/**
	 * Returns true if the from fragment should be included in the from clause.
	 */
	public boolean useFromFragment() {
		checkInitialized();
		// If it's not implied or it is implied and it's a many to many join where the target wasn't found.
		return ( !implied || this.useFromFragment );
	}

	public void setUseFromFragment(boolean useFromFragment) {
		this.useFromFragment = useFromFragment;
	}

	public void setCollectionTableAlias(String collectionTableAlias) {
		this.collectionTableAlias = collectionTableAlias;
	}

	public String getCollectionTableAlias() {
		return collectionTableAlias;
	}

	public boolean isCollectionOfValuesOrComponents() {
		if ( persister == null ) {
			if ( queryableCollection == null ) {
				return false;
			}
			else {
				return !queryableCollection.getElementType().isEntityType();
			}
		}
		else {
			return false;
		}
	}

	public boolean isEntity() {
		return persister != null;
	}

	void setImpliedInFromClause(boolean flag) {
		this.impliedInFromClause = flag;
	}

	boolean isImpliedInFromClause() {
		return impliedInFromClause;
	}

	/**
	 * Returns true if this element should be in the projection list.
	 *
	 * @return
	 */
	boolean inProjectionList() {
		boolean implied = isImplied();
		return !implied && isFromOrJoinFragment();
	}

	boolean isFromOrJoinFragment() {
		return getType() == SqlTokenTypes.FROM_FRAGMENT || getType() == SqlTokenTypes.JOIN_FRAGMENT;
	}
}
