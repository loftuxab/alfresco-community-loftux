// $Id: IdentNode.java,v 1.19 2005/01/22 22:56:15 pgmjsd Exp $
package org.hibernate.hql.ast;

import antlr.SemanticException;
import antlr.collections.AST;
import org.hibernate.hql.antlr.SqlTokenTypes;
import org.hibernate.type.Type;

/**
 * Represents an identifier all by itself, which may be either a function name or a class alias depending on the
 * context.
 *
 * @author josh Aug 16, 2004 7:20:55 AM
 */
class IdentNode extends FromReferenceNode implements SelectExpression {

	public void resolve(boolean generateJoin, boolean implicitJoin, String classAlias, AST parent) throws SemanticException {
		if ( isResolved() ) {
			return;
		}
/*
		if ( log.isDebugEnabled() ) {
			log.debug( "resolve() : " + nodeToString( this, false ) + " implicitJoin = " + implicitJoin + " parent = " + parent );
		}
*/
		// This is not actually a constant, but a reference to FROM element.
		FromElement element = getWalker().getCurrentFromClause().getFromElement( getText() );
		if ( element != null ) {
			setFromElement( element );
			setText( element.getIdentityColumn() );
			setType( SqlTokenTypes.ALIAS_REF );
		}
		setResolved();
	}

	public Type getDataType() {
		Type type = super.getDataType();
		// If there's no type in the superclass, use the from element's type.
		return ( type == null && getFromElement() != null ) ? getFromElement().getDataType() : type;
	}

	public void setScalarColumnText(int i) throws SemanticException {
		setText( getFromElement().renderScalarIdentifierSelect( i ) );
	}

	public boolean isReturnableEntity() throws SemanticException {
		// TODO: Question... Are *all* ident nodes really returnable entities?
		return true;
	}

	public String getDisplayText() {
		StringBuffer buf = new StringBuffer();

		if ( getType() == SqlTokenTypes.ALIAS_REF ) {
			buf.append( "{alias=" ).append( getOriginalText() );
			if ( getFromElement() == null ) {
				buf.append( ", no from element" );
			}
			else {
				buf.append( ", className=" ).append( getFromElement().getClassName() );
				buf.append( ", tableAlias=" ).append( getFromElement().getTableAlias() );
			}
			buf.append( "}" );
		}
		else {
			buf.append( "{originalText=" + getOriginalText() ).append( "}" );
		}
		return buf.toString();
	}

}
