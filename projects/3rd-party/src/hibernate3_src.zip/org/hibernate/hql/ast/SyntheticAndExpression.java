// $Id: SyntheticAndExpression.java,v 1.4 2004/12/19 02:11:19 pgmjsd Exp $
package org.hibernate.hql.ast;

/**
 * Represents a synthesized AND expression e.g. a theta join and or a filter condition.
 *
 * @author josh Aug 15, 2004 2:15:02 PM
 */
class SyntheticAndExpression extends SqlNode implements DisplayableNode {
	private FromElement fromElement;

	public static final int THETA_JOIN_LHS = 0;
	public static final int FILTER_CONDITION_RHS = 1;
	public static final int FILTER_CONDITION_LHS = 2;
	public static final int MULTIPLE_FRAGMENTS = 3;

	private int andType = THETA_JOIN_LHS;

	public void setAndType(int andType) {
		this.andType = andType;
	}

	public String getText() {
		return "{and}";
	}

	private String getAndTypeText() {
		return ASTPrinter.getConstantName( SyntheticAndExpression.class, andType );
	}

	public FromElement getFromElement() {
		return fromElement;
	}

	public void setFromElement(FromElement fromElement) {
		this.fromElement = fromElement;
	}

	public String getDisplayText() {
		return getAndTypeText() + " " + fromElement.getDisplayText();
	}


}
