// $Id: MethodNode.java,v 1.23 2005/01/31 13:03:35 pgmjsd Exp $
package org.hibernate.hql.ast;

import antlr.SemanticException;
import antlr.collections.AST;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.collection.CollectionPropertyNames;
import org.hibernate.collection.QueryableCollection;
import org.hibernate.dialect.SQLFunction;
import org.hibernate.hql.CollectionProperties;
import org.hibernate.hql.antlr.SqlTokenTypes;
import org.hibernate.persister.EntityPersister;
import org.hibernate.persister.PropertyMapping;
import org.hibernate.type.Type;

import java.util.Arrays;

/**
 * Represents a method call.
 *
 * @author josh Aug 16, 2004 7:59:42 AM
 */
class MethodNode extends AbstractSelectExpression implements SelectExpression {

	private static final Log log = LogFactory.getLog( MethodNode.class );

	private String methodName;
	private FromElement fromElement;
	private String[] selectColumns;
	private SQLFunction function;
	private boolean inSelect;

	public void resolve(boolean inSelect) throws SemanticException {
		// Get the function name node.
		AST name = getFirstChild();
		initializeMethodNode( name, inSelect );
		AST exprList = name.getNextSibling();
		// If the expression list has exactly one expression, and the type of the expression is a collection
		// then this might be a collection function, such as index(c) or size(c).
		if ( ASTUtil.hasExactlyOneChild( exprList ) && isCollectionPropertyMethod() ) {
			collectionProperty( exprList.getFirstChild(), name );
		}
		else {
			dialectFunction( exprList );
		}
	}

	public SQLFunction getSQLFunction() {
		return function;
	}

	private void dialectFunction(AST exprList) {
		function = getSessionFactoryHelper().findSQLFunction( methodName );
		if ( function != null ) {
			Type functionReturnType = getSessionFactoryHelper().findFunctionReturnType( methodName,
					( exprList != null ) ? exprList.getFirstChild() : null );
			setDataType( functionReturnType );
		}
	}

	boolean isCollectionPropertyMethod() {
		return CollectionProperties.isAnyCollectionProperty( methodName );
	}

	void initializeMethodNode(AST name, boolean inSelect) {
		name.setType( SqlTokenTypes.METHOD_NAME );
		String text = name.getText();
		methodName = text.toLowerCase();	// Use the lower case function name.
		this.inSelect = inSelect;			// Remember whether we're in a SELECT clause or not.
	}

	private String getMethodName() {
		return methodName;
	}

	private void collectionProperty(AST path, AST name) throws SemanticException {
		if ( path == null ) {
			throw new SemanticException( "Collection function " + name.getText() + " has no path!" );
		}

		SqlNode expr = ( SqlNode ) path;
		Type type = expr.getDataType();
		if ( log.isDebugEnabled() ) {
			log.debug( "collectionProperty() :  name=" + name + " type=" + type );
		}

		resolveCollectionProperty( expr );
	}

	public boolean isScalar() throws SemanticException {
		// Method expressions in a SELECT should always be considered scalar.
		return true;
	}

	void resolveCollectionProperty(AST expr) throws SemanticException {
		String propertyName = CollectionProperties.getNormalizedPropertyName( getMethodName() );
		if ( expr instanceof FromReferenceNode ) {
			FromReferenceNode collectionNode = ( FromReferenceNode ) expr;
			// If this is 'elements' then create a new FROM element.
			if ( CollectionPropertyNames.COLLECTION_ELEMENTS.equals( propertyName ) ) {
				handleElements( collectionNode, propertyName );
			}
			else {
				// Not elements(x)
				fromElement = collectionNode.getFromElement();
				setDataType( fromElement.getPropertyType( propertyName, propertyName ) );
				selectColumns = fromElement.toColumns( fromElement.getTableAlias(), propertyName, inSelect );
			}
			setText( selectColumns[0] );
			setType( SqlTokenTypes.SQL_TOKEN );
		}
		else {
			throw new SemanticException( "Unexpected expression " + expr + " found for collection function " + propertyName );
		}
	}

	private void handleElements(FromReferenceNode collectionNode, String propertyName) throws SemanticException {
		FromElement collectionFromElement = collectionNode.getFromElement();
		QueryableCollection queryableCollection = collectionFromElement.getQueryableCollection();
		if ( getWalker().isShallowQuery() ) {
			// No need to create the extra join if we're in a shallow query.
			fromElement = collectionFromElement;
			if ( fromElement.isCollectionOfValuesOrComponents() ) {
				// Promote the fromElement to a sibling.
				ASTUtil.makeSiblingOfParent( fromElement.getOrigin(), fromElement );
			}
			else {
				getWalker().addQuerySpaces( queryableCollection.getElementPersister().getQuerySpaces() );
			}
		}
		else {
			// Otherwise, this is not a shallow query.
			if ( collectionFromElement.isCollectionOfValuesOrComponents() ) {
				// Non-shallow query for a colletion of values or components.
				fromElement = collectionFromElement;
				// Promote the fromElement to a sibling.
				ASTUtil.makeSiblingOfParent( fromElement.getOrigin(), fromElement );
			}
			else {
				// Non-shallow query for a collection of entities.
				String path = collectionNode.getPath() + "[]." + propertyName;
				log.debug( "Creating  elements for " + path );
				FromElementFactory factory = new FromElementFactory( collectionFromElement.getFromClause(), collectionFromElement, path,
						null, collectionFromElement.getQueryableCollection().getKeyColumnNames(), true );
				fromElement = factory.createElementJoin( queryableCollection );
			}
		}
		setDataType( queryableCollection.getElementType() );
		if ( queryableCollection.isOneToMany() || getWalker().isShallowQuery() ) {
			selectColumns = collectionFromElement.toColumns( fromElement.getTableAlias(), propertyName, inSelect );
		}
		else {
			// TODO: Is this right?  Is 'the identity columns' the right answer for many-to-many collections? This seems to work for MultiTableTest.
			PropertyMapping propertyMapping = fromElement.getPropertyMapping( EntityPersister.ENTITY_ID );
			selectColumns = propertyMapping.toColumns( fromElement.getTableAlias(), EntityPersister.ENTITY_ID );
		}
	}

	public void setScalarColumnText(int i) throws SemanticException {
		if ( selectColumns == null ) { 	// Dialect function
			ColumnHelper.generateSingleScalarColumn( this, i );
		}
		else {	// Collection 'property function'
			ColumnHelper.generateScalarColumns( this, selectColumns, i );
		}
	}

	public FromElement getFromElement() {
		return fromElement;
	}

	public String getDisplayText() {
		return "{" +
				"method=" + getMethodName() +
				",selectColumns=" + ( selectColumns == null ? null : Arrays.asList( selectColumns ) ) +
				",fromElement=" + fromElement +
				"}";
	}
}
