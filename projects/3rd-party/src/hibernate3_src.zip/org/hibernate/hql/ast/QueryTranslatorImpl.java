// $Id: QueryTranslatorImpl.java,v 1.42 2005/01/26 10:45:12 pgmjsd Exp $

package org.hibernate.hql.ast;

import antlr.ANTLRException;
import antlr.RecognitionException;
import antlr.TokenStreamException;
import antlr.collections.AST;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.HibernateException;
import org.hibernate.MappingException;
import org.hibernate.QueryException;
import org.hibernate.ScrollableResults;
import org.hibernate.engine.QueryParameters;
import org.hibernate.engine.SessionFactoryImplementor;
import org.hibernate.engine.SessionImplementor;
import org.hibernate.hql.FilterTranslator;
import org.hibernate.hql.antlr.HqlTokenTypes;
import org.hibernate.hql.antlr.SqlTokenTypes;
import org.hibernate.loader.QueryLoader;
import org.hibernate.type.Type;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * A QueryTranslator that uses an AST based parser.
 * <br>User: josh
 * <br>Date: Dec 31, 2003
 * <br>Time: 7:50:35 AM
 *
 * @author Joshua Davis (pgmjsd@sourceforge.net)
 */
public class QueryTranslatorImpl implements FilterTranslator {
	private static final Log log = LogFactory.getLog( QueryTranslatorImpl.class );
	private static final Log AST_LOG = LogFactory.getLog( "org.hibernate.hql.AST" );

	// --- Input ---
	/**
	 * The query.
	 */
	private String hql;
	/**
	 * True if this is a scalar, or shallow query.
	 */
	private boolean shallowQuery;
	/**
	 * The query parameter replacements for this query.
	 */
	private Map tokenReplacements;

	// --- State ---
	/**
	 * True if the query has been compiled.
	 */
	private boolean compiled;
	/**
	 * Delegate that implements the Loader abstraction.
	 */
	private QueryLoader queryLoader;

	// --- Output ---
	/**
	 * The SQL syntax tree.
	 */
	private QueryNode sqlAst;
	/**
	 * The SQL query.
	 */
	private String sql;
	/**
	 * The alias names present in the query and subqueries.
	 */
	private Map aliasNames = new HashMap();

	private Map enabledFilters;

	private SessionFactoryImplementor factory;

	/**
	 * Creates a new AST-based query translator.
	 *
	 * @param query          The HQL query string.
	 * @param enabledFilters Any filters currently enabled for the session.
	 * @param factory        The session factory constructing this translator instance.
	 */
	public QueryTranslatorImpl(String query, Map enabledFilters, SessionFactoryImplementor factory) {
		this.hql = query;
		this.compiled = false;
		this.shallowQuery = false;
		this.enabledFilters = enabledFilters;
		this.factory = factory;
	}

	/**
	 * Compile a "normal" query. This method may be called multiple
	 * times. Subsequent invocations are no-ops.
	 *
	 * @param replacements Defined query substitutions.
	 * @param shallow      Does this represent a shallow (scalar or entity-id) select?
	 * @throws QueryException   There was a problem parsing the query string.
	 * @throws MappingException There was a problem querying defined mappings.
	 */
	public void compile(Map replacements, boolean shallow)
			throws QueryException, MappingException {
		doCompile( replacements, shallow, null );
	}

	/**
	 * Compile a filter. This method may be called multiple
	 * times. Subsequent invocations are no-ops.
	 *
	 * @param collectionRole the role name of the collection used as the basis for the filter.
	 * @param replacements   Defined query substitutions.
	 * @param shallow        Does this represent a shallow (scalar or entity-id) select?
	 * @throws QueryException   There was a problem parsing the query string.
	 * @throws MappingException There was a problem querying defined mappings.
	 */
	public void compile(String collectionRole, Map replacements, boolean shallow)
			throws QueryException, MappingException {
		doCompile( replacements, shallow, collectionRole );
	}

	/**
	 * Performs both filter and non-filter compiling.
	 *
	 * @param replacements   Defined query substitutions.
	 * @param shallow        Does this represent a shallow (scalar or entity-id) select?
	 * @param collectionRole the role name of the collection used as the basis for the filter, NULL if this
	 *                       is not a filter.
	 */
	private synchronized void doCompile(Map replacements, boolean shallow, String collectionRole) {
		// If the query is already compiled, skip the compilation.
		if ( compiled ) {
			if ( log.isDebugEnabled() ) {
				log.debug( "compile() : The query is already compiled, skipping..." );
			}
			return;
		}

		// Remember the parameters for the compilation.
		this.tokenReplacements = replacements;
		if ( tokenReplacements == null ) {
			tokenReplacements = new HashMap();
		}
		this.shallowQuery = shallow;

		try {
			// PHASE 1 : Parse the HQL into an AST.
			HqlParser parser = parse( true );

			// PHASE 2 : Analyze the HQL AST, and produce an SQL AST.
			HqlSqlWalker w = analyze( parser, collectionRole );
			sqlAst = ( QueryNode ) w.getAST();

			// PHASE 3 : Generate the SQL.
			generate( sqlAst );

			// Create the loader delegate.
			queryLoader = new QueryLoader( this, factory, w.getSelectClause() );
			compiled = true;
		}
		catch ( QueryException qe ) {
			qe.setQueryString( hql );
			throw qe;
		}
		catch ( RecognitionException e ) {
			throw  new QuerySyntaxError( e, hql );
		}
		catch ( ANTLRException e ) {
			QueryException qe = new QueryException( e.getMessage(), e );
			qe.setQueryString( hql );
			throw qe;
		}
	}

	private void generate(AST sqlAst) throws QueryException, RecognitionException {
		if ( sql == null ) {
			// Generate an SQL string from the tree.
			SqlGenerator gen = new SqlGenerator();
			// Generate the SELECT from the AST.
			gen.select( sqlAst );
			sql = gen.getSQL();
			if ( log.isDebugEnabled() ) {
				log.debug( "HQL: " + hql );
				log.debug( "SQL: " + sql );
			}
			gen.getParseErrorHandler().throwQueryException();
		}
	}

	private HqlSqlWalker analyze(HqlParser parser, String collectionRole) throws QueryException, RecognitionException {
		HqlSqlWalker w = new HqlSqlWalker( this, factory, parser, tokenReplacements, collectionRole );
		AST hqlAst = parser.getAST();

		// Transform the tree.
		w.select( hqlAst );

		if ( AST_LOG.isDebugEnabled() ) {
			logAst( "--- SQL AST ---", SqlTokenTypes.class, w.getAST() );
		}

		w.getParseErrorHandler().throwQueryException();

		return w;
	}

	private HqlParser parse(boolean filter) throws TokenStreamException, RecognitionException {
		// Parse the query string into an HQL AST.
		HqlParser parser = HqlParser.getInstance( hql );
		parser.setFilter( filter );

		if ( log.isDebugEnabled() ) {
			log.debug( "parse() - HQL: " + hql );
		}
		parser.query();

		AST hqlAst = parser.getAST();

		showHqlAst( hqlAst );

		parser.getParseErrorHandler().throwQueryException();
		return parser;
	}

	void showHqlAst(AST hqlAst) {
		if ( AST_LOG.isDebugEnabled() ) {
			logAst( "--- HQL AST ---", HqlTokenTypes.class, hqlAst );
		}
	}

	private static void logAst(String header, Class tokenTypeConstants, AST ast) {
		ASTPrinter printer = new ASTPrinter( tokenTypeConstants );
		AST_LOG.debug( printer.showAsString( ast, header ) );
	}

	/**
	 * Types of the return values of an <tt>iterate()</tt> style query.
	 *
	 * @return an array of <tt>Type</tt>s.
	 */
	public Type[] getReturnTypes() {
		return getWalker().getReturnTypes();
	}

	private HqlSqlWalker getWalker() {
		return sqlAst.getWalker();
	}

	public String[][] getColumnNames() {
		return getWalker().getSelectClause().getColumnNames();
	}

	public Set getQuerySpaces() {
		return getWalker().getQuerySpaces();
	}

	public List list(SessionImplementor session, QueryParameters queryParameters)
			throws HibernateException {
		// Delegate to the QueryLoader...
		return queryLoader.list( session, queryParameters );
	}

	/**
	 * Return the query results as an iterator
	 */
	public Iterator iterate(QueryParameters queryParameters, SessionImplementor session)
			throws HibernateException {
		// Delegate to the QueryLoader...
		return queryLoader.iterate( queryParameters, session );
	}

	/**
	 * Return the query results, as an instance of <tt>ScrollableResults</tt>
	 */
	public ScrollableResults scroll(QueryParameters queryParameters, SessionImplementor session)
			throws HibernateException {
		// Delegate to the QueryLoader...
		return queryLoader.scroll( queryParameters, session );
	}

	/**
	 * The SQL query string to be called; implemented by all subclasses
	 */
	public String getSQLString() {
		return sql;
	}

	// -- Package local methods for the QueryLoader delegate --

	boolean isShallowQuery() {
		return shallowQuery;
	}

	public String getQueryString() {
		return hql;
	}

	public String getAliasName(String alias) {
		String name = ( String ) aliasNames.get( alias );
		if ( name == null ) {
			name = alias;
		}
		return name;
	}

	public Map getEnabledFilters() {
		return enabledFilters;
	}

	public int[] getNamedParameterLocs(String name) {
		return getWalker().getNamedParameterLocs( name );
	}
}
