//$Id: SelectPathExpressionParser.java,v 1.1 2004/12/08 00:22:20 oneovthafew Exp $
package org.hibernate.hql.classic;

import org.hibernate.QueryException;

public class SelectPathExpressionParser extends PathExpressionParser {

	public void end(QueryTranslatorImpl q) throws QueryException {
		if ( getCurrentProperty() != null && !q.isShallowQuery() ) {
			// "finish off" the join
			token( ".", q );
			token( null, q );
		}
		super.end( q );
	}

	protected void setExpectingCollectionIndex() throws QueryException {
		throw new QueryException( "expecting .elements or .indices after collection path expression in select" );
	}

	public String getSelectName() {
		return getCurrentName();
	}
}







