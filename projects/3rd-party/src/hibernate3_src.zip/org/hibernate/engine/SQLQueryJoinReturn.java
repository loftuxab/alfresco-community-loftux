// $Id: SQLQueryJoinReturn.java,v 1.1 2005/01/25 02:52:52 oneovthafew Exp $
package org.hibernate.engine;

import org.hibernate.LockMode;

/**
 * Represents a return defined as part of a native sql query which
 * names a fetched role.
 *
 * @author Steve
 */
public class SQLQueryJoinReturn extends SQLQueryReturn {
	private String ownerAlias;
	private String ownerProperty;

	public SQLQueryJoinReturn(String alias, String ownerAlias, String ownerProperty, LockMode lockMode) {
		super(alias, lockMode);
		this.ownerAlias = ownerAlias;
		this.ownerProperty = ownerProperty;
	}

	public String getOwnerAlias() {
		return ownerAlias;
	}

	public String getOwnerProperty() {
		return ownerProperty;
	}
}
