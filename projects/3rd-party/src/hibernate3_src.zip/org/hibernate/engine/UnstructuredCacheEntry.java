//$Id: UnstructuredCacheEntry.java,v 1.1 2005/01/13 19:53:04 oneovthafew Exp $
package org.hibernate.engine;


/**
 * @author Gavin King
 */
public class UnstructuredCacheEntry implements CacheEntryStructure {

	public Object structure(Object item) {
		return item;
	}

	public Object destructure(Object map, SessionFactoryImplementor factory) {
		return map;
	}

}
