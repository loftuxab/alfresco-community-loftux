//$Id: CacheEntry.java,v 1.13 2005/02/11 03:50:51 oneovthafew Exp $
package org.hibernate.engine;

import java.io.Serializable;

import org.hibernate.AssertionFailure;
import org.hibernate.HibernateException;
import org.hibernate.Interceptor;
import org.hibernate.event.PreLoadEvent;
import org.hibernate.event.SessionEventSource;
import org.hibernate.persister.EntityPersister;
import org.hibernate.type.TypeFactory;
import org.hibernate.util.ArrayHelper;

/**
 * A cached instance of a persistent class
 *
 * @author Gavin King
 */
public final class CacheEntry implements Serializable {

	private final Serializable[] disassembledState;
	private final String subclass;
	private final boolean lazyPropertiesAreUnfetched;
	
	public String getSubclass() {
		return subclass;
	}
	
	public boolean areLazyPropertiesUnfetched() {
		return lazyPropertiesAreUnfetched;
	}
	
	public CacheEntry(Object[] state, EntityPersister persister, boolean unfetched, SessionImplementor session) 
	throws HibernateException {
		//disassembled state gets put in a new array (we write to cache by value!)
		this.disassembledState = TypeFactory.disassemble( state, persister.getPropertyTypes(), session);
		subclass = persister.getEntityName();
		lazyPropertiesAreUnfetched = unfetched;
	}
	
	CacheEntry(Serializable[] state, String subclass, boolean unfetched) {
		this.disassembledState = state;
		this.subclass = subclass;
		this.lazyPropertiesAreUnfetched = unfetched;
	}

	public Object[] assemble(
			final Object instance, 
			final Serializable id, 
			final EntityPersister persister, 
			final Interceptor interceptor, 
			final SessionImplementor session) 
	throws HibernateException {

		if ( !persister.getEntityName().equals(subclass) ) {
			throw new AssertionFailure("Tried to assemble a different subclass instance");
		}

		return assemble(disassembledState, instance, id, persister, interceptor, session);

	}

	private static Object[] assemble(
			final Serializable[] values, 
			final Object result, 
			final Serializable id, 
			final EntityPersister persister, 
			final Interceptor interceptor, 
			final SessionImplementor session) 
	throws HibernateException {
			
		//assembled state gets put in a new array (we read from cache by value!)
		Object[] assembledProps = TypeFactory.assemble( values, persister.getPropertyTypes(), session, result );

		//persister.setIdentifier(result, id); //before calling interceptor, for consistency with normal load

		SessionEventSource source = (SessionEventSource) session;
		PreLoadEvent preLoadEvent = new PreLoadEvent(result, assembledProps, id, persister, source);
		source.getListeners().getPreLoadEventListener().onPreLoad(preLoadEvent);

		persister.setPropertyValues(result, assembledProps);

		return assembledProps;
	}

    public Serializable[] getDisassembledState() {
	    // todo: this was added to support initializing an entity's EntityEntry snapshot during reattach;
	    // this should be refactored to instead expose a method to assemble a EntityEntry based on this
	    // state for return.
	    return disassembledState;
    }

	public String toString() {
		return "CacheEntry(" + subclass + ')' + ArrayHelper.toString(disassembledState);
	}

}






