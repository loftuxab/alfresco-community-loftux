//$Id: CacheEntryStructure.java,v 1.1 2005/01/13 19:53:04 oneovthafew Exp $
package org.hibernate.engine;



/**
 * @author Gavin King
 */
public interface CacheEntryStructure {
	public Object structure(Object item);
	public Object destructure(Object map, SessionFactoryImplementor factory);
}
