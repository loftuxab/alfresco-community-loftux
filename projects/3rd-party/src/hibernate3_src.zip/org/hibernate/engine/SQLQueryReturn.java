// $Id: SQLQueryReturn.java,v 1.2 2004/12/17 21:43:40 maxcsaucdk Exp $
package org.hibernate.engine;

import java.io.Serializable;

import org.hibernate.LockMode;

/**
 * Represents the base information for a return defined as part of
 * a native sql query.
 *
 * @author Steve
 */
public abstract class SQLQueryReturn implements Serializable {
	private String alias;
	private LockMode lockMode;

	protected SQLQueryReturn(String alias, LockMode lockMode) {
		this.alias = alias;
		this.lockMode = lockMode;
	}

	public String getAlias() {
		return alias;
	}

	public LockMode getLockMode() {
		return lockMode;
	}
}
