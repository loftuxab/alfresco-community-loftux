// $Id: SQLQueryRootReturn.java,v 1.2 2005/01/24 22:19:40 oneovthafew Exp $
package org.hibernate.engine;

import org.hibernate.LockMode;

/**
 * Represents a return defined as part of a native sql query which
 * names a "root" entity.  A root entity means it is explicitly a
 * "column" in the result, as opposed to a fetched relationship or role.
 *
 * @author Steve
 */
public class SQLQueryRootReturn extends SQLQueryReturn {
	private String returnEntityName;

	public SQLQueryRootReturn(String alias, String returnEntityName, LockMode lockMode) {
		super(alias, lockMode);
		this.returnEntityName = returnEntityName;
	}

	public String getReturnEntityName() {
		return returnEntityName;
	}
}
