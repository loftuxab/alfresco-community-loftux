//$Id: SqlResultsetMappingDefinition.java,v 1.1 2005/05/17 14:13:17 epbernard Exp $
package org.hibernate.engine;

import java.util.ArrayList;
import java.util.List;
import java.io.Serializable;

import org.hibernate.loader.custom.SQLQueryReturn;
import org.hibernate.loader.custom.SQLQueryScalarReturn;

/**
 * Keep a description of the resultset mapping
 *
 * @author Emmanuel Bernard
 */
public class SqlResultsetMappingDefinition implements Serializable {
	/** List<SQLQueryReturn> */
	private List entityQueryReturns = new ArrayList();
	/** List<SQLQueryScalarReturn> */
	private List scalarQueryReturns = new ArrayList();
	private String name;

	public String getName() {
		return name;
	}

	public SqlResultsetMappingDefinition(String name) {
		this.name = name;
	}

	public void addEntityQueryReturn(SQLQueryReturn entityQueryReturn) {
		entityQueryReturns.add(entityQueryReturn);
	}

	public void addScalarQueryReturn(SQLQueryScalarReturn scalarQueryReturn) {
		scalarQueryReturns.add(scalarQueryReturn);
	}

	public SQLQueryReturn[] getEntityQueryReturns() {
		return (SQLQueryReturn[]) entityQueryReturns.toArray( new SQLQueryReturn[0] );
	}

	public SQLQueryScalarReturn[] getScalarQueryReturns() {
		return (SQLQueryScalarReturn[]) scalarQueryReturns.toArray( new SQLQueryScalarReturn[0] );
	}
}
