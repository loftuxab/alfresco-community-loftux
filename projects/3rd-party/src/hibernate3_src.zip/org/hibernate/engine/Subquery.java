//$Id: Subquery.java,v 1.1 2004/08/29 03:43:14 oneovthafew Exp $
package org.hibernate.engine;

import java.util.Collection;

import org.hibernate.persister.Loadable;
import org.hibernate.util.StringHelper;

/**
 * @author Gavin King
 */
public class Subquery {
	private final Collection resultingEntityKeys;
	private final String queryString;
	private final String alias;
	private final String[] identifierColumnNames;
	private final QueryParameters queryParameters;
	
	public Subquery(
		final String queryString, 
		final String alias, 
		final Loadable loadable,
		final QueryParameters queryParameters, 
		final Collection resultingEntityKeys
	) {
		this.resultingEntityKeys = resultingEntityKeys;
		this.queryParameters = queryParameters;
		this.queryString = queryString;
		this.identifierColumnNames = loadable.getIdentifierColumnNames();
		this.alias = alias;
	}

	public QueryParameters getQueryParameters() {
		return queryParameters;
	}
	
	public Collection getResult() {
		return resultingEntityKeys;
	}
	
	public String toSubqueryString() {
		//TODO: move to Template
		int fromIndex = queryString.indexOf(" from ");
		int orderByIndex = queryString.indexOf("order by");
		return new StringBuffer().append("select ")
			.append( 
					StringHelper.join( 
						", ", 
						StringHelper.qualify(alias, identifierColumnNames) 
					) 
			)
			.append( 
					orderByIndex>0 ? 
						queryString.substring(fromIndex, orderByIndex) : 
						queryString.substring(fromIndex) 
			)
			.toString();
	}

}
