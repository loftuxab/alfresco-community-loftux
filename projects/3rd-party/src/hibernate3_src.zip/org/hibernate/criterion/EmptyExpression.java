//$Id: EmptyExpression.java,v 1.6 2005/01/29 12:48:54 oneovthafew Exp $
package org.hibernate.criterion;


import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.collection.QueryableCollection;
import org.hibernate.engine.TypedValue;
import org.hibernate.persister.Loadable;
import org.hibernate.sql.ConditionFragment;

/**
 * @author Gavin King
 */
public class EmptyExpression implements Criterion {
	
	private final String propertyName;
	
	private static final TypedValue[] NO_VALUES = new TypedValue[0];

	protected EmptyExpression(String propertyName) {
		this.propertyName = propertyName;
	}

	public String toString() {
		return propertyName + " is empty";
	}

	public String toSqlString(Criteria criteria, CriteriaQuery criteriaQuery)
	throws HibernateException {
		String role = criteriaQuery.getEntityName(criteria, propertyName) + 
			'.' +  
			criteriaQuery.getPropertyName(propertyName);
		QueryableCollection cp = (QueryableCollection) criteriaQuery.getFactory().getCollectionPersister(role);
		//String[] fk = StringHelper.qualify( "collection_", cp.getKeyColumnNames() );
		String[] fk = cp.getKeyColumnNames();
		String[] pk = ( (Loadable) cp.getOwnerEntityPersister() ).getIdentifierColumnNames(); //TODO: handle property-ref
		return "not exists (select 1 from " +
			cp.getTableName() +
			//" collection_ where " +
			" where " +
			new ConditionFragment()
				.setTableAlias( criteriaQuery.getSQLAlias(criteria, propertyName) )
				.setCondition(pk, fk)
				.toFragmentString() +
			")";
	}

	public TypedValue[] getTypedValues(Criteria criteria, CriteriaQuery criteriaQuery) 
	throws HibernateException {
		return NO_VALUES;
	}

}
