//$Id: Executable.java,v 1.3 2005/01/23 22:25:47 pgmjsd Exp $
package org.hibernate.action;

import org.hibernate.HibernateException;

import java.io.Serializable;

public interface Executable {
	public void beforeExecutions() throws HibernateException;

	public void execute() throws HibernateException;

	public boolean hasAfterTransactionCompletion();

	public void afterTransactionCompletion(boolean success) throws HibernateException;

	public Serializable[] getPropertySpaces();
}
