//$Id: SQLServerDialect.java,v 1.5 2005/01/12 11:28:01 loubyansky Exp $
package org.hibernate.dialect;

import org.hibernate.LockMode;
import org.hibernate.Hibernate;

/**
 * A dialect for Microsoft SQL Server 2000
 * @author Gavin King
 */
public class SQLServerDialect extends SybaseDialect {

	public SQLServerDialect() {
		super();
		registerFunction( "concat", new SQLFunctionTemplate( Hibernate.STRING, "(?1 + ?2)" ) );
	}

	public String getNoColumnsInsertString() {
		return "default values";
	}

	public String getLimitString(String querySelect, boolean hasOffset, int limit) {
		if (hasOffset) throw new UnsupportedOperationException("sql server has no offset");
		return new StringBuffer( querySelect.length()+8 )
			.append(querySelect)
			.insert( getAfterSelectInsertPoint(querySelect), " top " + limit )
			.toString();
	}

	/**
	 * Use <tt>insert table(...) values(...) select SCOPE_IDENTITY()</tt>
	 *
	 * @author <a href="mailto:jkristian@docent.com">John Kristian</a>
	 */
	public String appendIdentitySelectToInsert(String insertSQL) {
		return insertSQL + " select scope_identity()";
	}

	public boolean supportsLimit() {
		return true;
	}

	public boolean useMaxForLimit() {
		return true;
	}

	public boolean supportsLimitOffset() {
		return false;
	}

	public boolean supportsVariableLimit() {
		return false;
	}

	public char closeQuote() {
		return ']';
	}

	public char openQuote() {
		return '[';
	}

	public String appendLockHint(LockMode mode, String tableName) {
		if ( mode.greaterThan(LockMode.READ) ) {
			return tableName + " with (updlock, rowlock)";
		}
		else {
			return tableName;
		}
	}
	
	public String getSelectGUIDString() {
		return "select newid()";
	}

}
