//$Id: MySQLMyISAMDialect.java,v 1.3 2005/01/30 06:38:57 oneovthafew Exp $
package org.hibernate.dialect;

/**
 * @author Gavin King
 */
public class MySQLMyISAMDialect extends MySQLDialect {

	public String getTableTypeString() {
		return " type=MyISAM";
	}

	public boolean dropConstraints() {
		return false;
	}

}
