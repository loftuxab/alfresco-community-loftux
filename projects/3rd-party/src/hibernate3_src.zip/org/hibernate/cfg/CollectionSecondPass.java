//$Id: CollectionSecondPass.java,v 1.10 2004/12/01 00:24:08 epbernard Exp $
package org.hibernate.cfg;

/**
 * @author Emmanuel Bernard
 */
import java.util.Map;

import org.hibernate.FetchMode;
import org.hibernate.MappingException;
import org.hibernate.mapping.Collection;

/**
 * Second pass for colelctions once every entity is known
 * 
 * @author Emmanuel Bernard
 */
public class CollectionSecondPass extends SecondPass {
	Ejb3JoinColumn[] keyColumns;
	Ejb3JoinColumn[] inverseColumns;
	String collType;
	FetchMode fetchMode;
	
	/** one to many collections */
	public CollectionSecondPass(
		ExtendedMappings mappings, 
		Collection coll,
		Ejb3JoinColumn[] keyColumns) {
		super(mappings, coll);
		this.keyColumns = keyColumns;
	}
	
	/** many to many collections */
	public CollectionSecondPass(
		ExtendedMappings mappings, 
		Collection coll,
		Ejb3JoinColumn[] keyColumns,
		Ejb3JoinColumn[] inverseColumns,
		String collType,
		FetchMode fetchMode) {
		super(mappings, coll);
		this.keyColumns = keyColumns;
		this.inverseColumns = inverseColumns;
		this.collType = collType;
		this.fetchMode = fetchMode;
	}

	/**
	 * @see org.hibernate.cfg.HbmBinder
	 */
	void secondPass(Map persistentClasses, Map inheritedMetas) throws MappingException {
		if ( isManyToMany() ) {
			AnnotationBinder.bindManyToManySecondPass(
				collection, 
				persistentClasses,
				keyColumns,
				inverseColumns,
				collType,
				fetchMode
			);
		}
		else {
			AnnotationBinder.bindCollectionSecondPass(
				collection, 
				persistentClasses,
				keyColumns,
				(ExtendedMappings) mappings
			);
		}
	}
	private boolean isManyToMany() {
		return inverseColumns != null;
	}
}