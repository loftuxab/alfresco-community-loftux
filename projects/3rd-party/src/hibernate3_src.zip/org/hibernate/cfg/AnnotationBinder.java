//$Id: AnnotationBinder.java,v 1.50 2005/01/25 00:20:11 epbernard Exp $
package org.hibernate.cfg;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.AnnotationException;
import org.hibernate.AssertionFailure;
import org.hibernate.FetchMode;
import org.hibernate.MappingException;
import org.hibernate.engine.Versioning;
import org.hibernate.id.PersistentIdentifierGenerator;
import org.hibernate.id.TableHiLoGenerator;
import org.hibernate.id.MultipleHiLoPerTableGenerator;
import org.hibernate.mapping.Bag;
import org.hibernate.mapping.Collection;
import org.hibernate.mapping.DependantValue;
import org.hibernate.mapping.IdGenerator;
import org.hibernate.mapping.Join;
import org.hibernate.mapping.JoinedSubclass;
import org.hibernate.mapping.KeyValue;
import org.hibernate.mapping.PersistentClass;
import org.hibernate.mapping.Property;
import org.hibernate.mapping.RootClass;
import org.hibernate.mapping.SimpleValue;
import org.hibernate.mapping.Subclass;
import org.hibernate.mapping.Table;
import org.hibernate.mapping.TableOwner;
import org.hibernate.mapping.Value;
import org.hibernate.mapping.Component;
import org.hibernate.persister.JoinedSubclassEntityPersister;
import org.hibernate.persister.SingleTableEntityPersister;
import org.hibernate.type.ForeignKeyDirection;
import org.hibernate.util.ReflectHelper;
import org.hibernate.util.StringHelper;

import javax.ejb.*;
import java.lang.reflect.AnnotatedElement;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.*;

/**
 * JSR 175 annotation binder
 * Will read the annotation from classes, apply the
 * principles of the EJB3 spec and produces the Hibernate
 * configuration-time metamodel (the classes in the <tt>mapping</tt> 
 * package)
 * 
 * @author Emmanuel Bernard
 */
public final class AnnotationBinder {
	private static final String GENERATOR_TABLE_NAME_PARAM = "generatorTableName";

	/*
	 * Some design description
	 * I tried to remove any link to annotation except from the 2 first level of 
	 * method call.
	 * It'll enable to:
	 *   - facilitate annotation overriding
	 *   - mutualize one day xml and annotation binder (probably a dream though)
	 *   - split this huge class in smaller mapping oriented classes
	 *
	 * bindSomething usually create the mapping container and is accessed by one of the 2 first level method
	 * makeSomething usually create the mapping container and is accessed by bindSomething[else]
	 * fillSomething take the container into parameter and fill it.
	 * 
	 *
	 */
	private AnnotationBinder() {}
	
	private static final Log log = LogFactory.getLog(AnnotationBinder.class);
	
	public static void bindPackage(String packageName, ExtendedMappings mappings) {
		Package pckg = null;
		try {
			pckg = ReflectHelper.classForName(packageName + ".package-info").getPackage();
		}
		catch (ClassNotFoundException cnf) {
			log.warn("Package not found or wo package-info.java: " + packageName);
			return;
		}
		if ( pckg.isAnnotationPresent(SequenceGenerator.class) ) {
			SequenceGenerator ann = pckg.getAnnotation(SequenceGenerator.class);
			IdGenerator idGen = buildIdGenerator(ann);
			mappings.addGenerator(idGen);
			log.debug("Add sequence generator with name: " + idGen.getName() );
		}
		if ( pckg.isAnnotationPresent(TableGenerator.class) ) {
			TableGenerator ann = pckg.getAnnotation(TableGenerator.class);
			IdGenerator idGen = buildIdGenerator(ann);
			mappings.addGenerator(idGen);
			log.debug("Add table generator with name: " + idGen.getName() );
		}
		if ( pckg.isAnnotationPresent(GeneratorTable.class) ) {
			String name;
			GeneratorTable ann = pckg.getAnnotation(GeneratorTable.class);
			Properties params = buildPropertiesFromGeneratorTable(ann);
			mappings.addGeneratorTable(ann.name(), params);
		}
	}

	private static Properties buildPropertiesFromGeneratorTable(GeneratorTable ann) {
		Properties params = new Properties();
		if ( ! "".equals( ann.pkColumnName() ) )
			params.setProperty( MultipleHiLoPerTableGenerator.PK_COLUMN_NAME, ann.pkColumnName() );
		if ( ! "".equals( ann.valueColumnName() ) )
			params.setProperty( MultipleHiLoPerTableGenerator.VALUE_COLUMN_NAME, ann.valueColumnName() );
		if ( ann.table().specified() == true ) {
			javax.ejb.Table table = ann.table();
			if ( ! "".equals( table.name() ) )
				params.setProperty( MultipleHiLoPerTableGenerator.TABLE, table.name() );
			if ( ! "".equals( table.catalog() ) )
				params.setProperty( MultipleHiLoPerTableGenerator.CATALOG, table.catalog() );
			if ( ! "".equals( table.schema() ) )
				params.setProperty( MultipleHiLoPerTableGenerator.SCHEMA, table.schema() );
			//FIXME implements uniqueconstrains
		}
		else {
			params.setProperty( MultipleHiLoPerTableGenerator.TABLE, ann.name() );
		}
		return params;
	}

	private static IdGenerator buildIdGenerator(java.lang.annotation.Annotation ann) {
		IdGenerator idGen = new IdGenerator();
		if (ann == null) {
			idGen = null;
		}
		else if (ann instanceof TableGenerator) {
			TableGenerator tabGen = (TableGenerator) ann;
			idGen.setName( tabGen.name() );
			idGen.setIdentifierGeneratorStrategy( MultipleHiLoPerTableGenerator.class.getName() );
			String tableName = "".equals( tabGen.tableName() ) ? 
				MultipleHiLoPerTableGenerator.DEFAULT_TABLE_NAME
				: tabGen.tableName();
			idGen.addParam(GENERATOR_TABLE_NAME_PARAM, tableName);
			String pkColumn = "".equals( tabGen.pkColumnValue() ) ?
				 MultipleHiLoPerTableGenerator.DEFAULT_KEY
				 : tabGen.pkColumnValue();
			idGen.addParam(MultipleHiLoPerTableGenerator.KEY, pkColumn);
			idGen.addParam(TableHiLoGenerator.MAX_LO, String.valueOf( tabGen.allocationSize() ) );
		}
		else if (ann instanceof SequenceGenerator) {
			SequenceGenerator seqGen = (SequenceGenerator) ann;
			idGen.setName( seqGen.name() );
			idGen.setIdentifierGeneratorStrategy("sequence");
			
			idGen.addParam( org.hibernate.id.SequenceGenerator.SEQUENCE, seqGen.sequenceName() );
			//FIXME: work on initialValue() and allocationSize() through SequenceGenerator.PARAMETERS
			if (seqGen.initialValue() != 0 || seqGen.allocationSize() != 50) {
				log.warn("Hibernate does not support SequenceGenerator.initialValue() neither SequenceGenerator.allocationSize()");
			}
		}
		else {
			throw new AssertionFailure("Unknown Generator annotation: " + ann);
		}
		return idGen;
	}
	
	/**
	 * Bind a class having JSR175 annotations
	 * The subclasses <b>have to</b> be binded after its mother class
	 * 
	 * @param annotatedClass
	 * @param mappings
	 * @throws MappingException
	 */
	public static void bindClass(Class annotatedClass, ExtendedMappings mappings) throws MappingException {
		//FIXME: enable inheritance to be specified only once per hierarchy
		//TODO: be more strict with secondarytable allowance (not for ids, not for secondary table join columns etc)

		//TODO check if its the more convinient default
		if ( ! mappings.getClassType(annotatedClass).equals(AnnotatedClassType.ENTITY) ) {
			throw new AnnotationException( "Annotated class should have an @Entity annotation: " + annotatedClass.getName() );
		}
		Class superClass = annotatedClass.getSuperclass();
		PersistentClass superEntity = mappings.getClass( superClass.getName() );
		if (superEntity == null) {
			//check if superclass is not a potential persistent class
			if ( mappings.getClassType(superClass).equals(AnnotatedClassType.ENTITY) ) {
				throw new AnnotationException( "Subclass has to be binded after it's mother class: "
					+ superClass.getName() );
			}
		}
		boolean isRootClass = superEntity == null;
		boolean isSubClass = false;
		boolean isJoinedSubclass = false;
		String schema = "";
		String table = ""; //might be no @Table annotation on the annotated class
		String catalog = "";
		String discrimValue = null;
		List uniqueConstraints = new ArrayList();

		if (annotatedClass.isAnnotationPresent(javax.ejb.Table.class) ) {
			javax.ejb.Table tabAnn = (javax.ejb.Table) annotatedClass.getAnnotation(javax.ejb.Table.class);
			table = tabAnn.name();
			schema = tabAnn.schema();
			catalog = tabAnn.catalog();
			if (tabAnn.uniqueConstraints().length != 0) {
				for( UniqueConstraint uc : tabAnn.uniqueConstraints() ) {
					if (! uc.primary() ) {
                        uniqueConstraints.add( uc.columnNames() );
					}
					else {
						log.warn("@UniqueConstraint(primaryKey=true) not yet supported");
					}
				}
			}
		}
		//discriminator parameters
		Ejb3DiscriminatorColumn discriminatorColumn = null;
		boolean singleTableStrategy = true;
		Ejb3JoinColumn[] joinedColumns = null;
		if (annotatedClass.isAnnotationPresent(javax.ejb.Inheritance.class) ) {
			//FIXME: check for homogenous inheritance strategy
			javax.ejb.Inheritance inhAnn = (javax.ejb.Inheritance) annotatedClass.getAnnotation(javax.ejb.Inheritance.class);
			if ( inhAnn.strategy().equals(InheritanceType.TABLE_PER_CLASS) ) {
				singleTableStrategy = false;
				if (!isRootClass) {
					//TODO: ask Gavin if the EG expected data duplication in the DB
					throw new AnnotationException("TABLE_PER_CLASS only allows hierarchy leaf mapping");
				}
			}
			if ( inhAnn.strategy().equals(InheritanceType.JOINED) ) {
				//mark as joined subclass if needed and prepare thr join column
				singleTableStrategy = false;
				isJoinedSubclass = !isRootClass;
				if (isJoinedSubclass) {
					InheritanceJoinColumns jcsAnn = (InheritanceJoinColumns) annotatedClass.getAnnotation(InheritanceJoinColumns.class);
					boolean explicitInheritanceJoinedColumns = jcsAnn != null && jcsAnn.value().length != 0;
					if (explicitInheritanceJoinedColumns) {
						int nbrOfInhJoinedColumns = jcsAnn.value().length;
						InheritanceJoinColumn jcAnn;
						joinedColumns = new Ejb3JoinColumn[nbrOfInhJoinedColumns];
						for (int colIndex = 0 ; colIndex < nbrOfInhJoinedColumns ; colIndex++) {
							jcAnn = jcsAnn.value()[colIndex];
							joinedColumns[colIndex] = Ejb3JoinColumn.buildJoinColumn(jcAnn, superEntity.getIdentifier(),
								(Map<String, Join>) null, (PropertyHolder) null, mappings);
						}
					}
					else {
						//FIXME do we support implicit composite PK? HBX-75
						InheritanceJoinColumn jcAnn = (InheritanceJoinColumn) annotatedClass.getAnnotation(InheritanceJoinColumn.class);
						joinedColumns = new Ejb3JoinColumn[1];
						joinedColumns[0] = Ejb3JoinColumn.buildJoinColumn(jcAnn, superEntity.getIdentifier(),
								(Map<String, Join>) null, (PropertyHolder) null, mappings);
					}
					log.debug("Joined column(s) created" );
				}
			}
			if ( inhAnn.strategy().equals(InheritanceType.SINGLE_TABLE) ) {
				singleTableStrategy = true;
				if (annotatedClass.isAnnotationPresent(javax.ejb.DiscriminatorColumn.class) ) {
					javax.ejb.DiscriminatorColumn discAnn =
						(javax.ejb.DiscriminatorColumn) annotatedClass.getAnnotation(javax.ejb.DiscriminatorColumn.class);
					if (isRootClass) {
						discriminatorColumn = Ejb3DiscriminatorColumn.buildDiscriminatorColumn(inhAnn.discriminatorType(), discAnn, mappings);
					} else {
						log.warn("Discriminator should not be defined in a subclass, annotation ignored");
					}
				}
				discrimValue = inhAnn.discriminatorValue();
			}
		}
		//we now know what kind of persistent entity it is
		PersistentClass persistentClass;
		isSubClass = ! isRootClass && singleTableStrategy;
		//create eprsistent class
		if (isRootClass) {
			 persistentClass = new RootClass();
		}
		else if (isSubClass) {
			persistentClass = new Subclass(superEntity);
		} 
		else {
			persistentClass = new JoinedSubclass(superEntity); 
		}
		bindEntity(persistentClass, annotatedClass, discrimValue);
		if (! isSubClass) {
			bindTable(persistentClass, schema, catalog, table, uniqueConstraints, mappings);
		}
		PropertyHolder propertyHolder = PropertyHolderBuilder.buildPropertyHolder(persistentClass);

		Map<String, Join> secondaryTables = new HashMap<String, Join>();
		Map<String, Object> secondaryTableJoins = new HashMap<String, Object>();

		if (annotatedClass.isAnnotationPresent(javax.ejb.SecondaryTable.class) ) {
			javax.ejb.SecondaryTable tabAnn = (javax.ejb.SecondaryTable)
				annotatedClass.getAnnotation(javax.ejb.SecondaryTable.class);
			prepareForSecondaryTable(tabAnn, persistentClass, secondaryTables, secondaryTableJoins, mappings);
		}
		if (annotatedClass.isAnnotationPresent(javax.ejb.SecondaryTables.class) ) {
			javax.ejb.SecondaryTables tabsAnn = (javax.ejb.SecondaryTables)
				annotatedClass.getAnnotation(javax.ejb.SecondaryTables.class);
			for (SecondaryTable tab : tabsAnn.value() ) {
				prepareForSecondaryTable(tab, persistentClass, secondaryTables, secondaryTableJoins, mappings);
			}
		}
		 
		if (isJoinedSubclass) {
			JoinedSubclass jsc = (JoinedSubclass) persistentClass;
			if ( persistentClass.getClassPersisterClass()==null ) {
				persistentClass.getRootClass().setClassPersisterClass(JoinedSubclassEntityPersister.class);
			}
			SimpleValue key = new DependantValue( jsc.getTable(), jsc.getIdentifier() );
			jsc.setKey(key);
			key.setCascadeDeleteEnabled(false);
			bindFk(jsc, joinedColumns, key);
			jsc.createPrimaryKey();
			jsc.createForeignKey();
			
		} 
		else if (isSubClass) {
			if ( persistentClass.getClassPersisterClass() == null ) {
				persistentClass.getRootClass().setClassPersisterClass(SingleTableEntityPersister.class);
			}
			boolean uninilializedDiscrim = persistentClass.getRootClass().getDiscriminator() == null;
			if (uninilializedDiscrim) {
				bindDiscriminatorToPersistentClass( persistentClass.getRootClass(), null, secondaryTables, propertyHolder, mappings );
			}
		}
		else if (singleTableStrategy && isRootClass && discriminatorColumn != null) {
			bindDiscriminatorToPersistentClass( (RootClass) persistentClass, discriminatorColumn, secondaryTables, propertyHolder, mappings );
		}
		
		//try to find class level generators
		HashMap<String, IdGenerator> classGenerators = buildLocalGenerators(annotatedClass);
		HashMap<String, Properties> classGeneratorTables = buildLocalGeneratorTable(annotatedClass);

		Entity entityAnn = (Entity) annotatedClass.getAnnotation(Entity.class);
		boolean propertyAccess = entityAnn.access() == AccessType.PROPERTY;
		// check properties
		Class currentClassInHierarchy = annotatedClass;
		do {
            processElementsOfAClass(propertyHolder, propertyAccess, true, currentClassInHierarchy, classGenerators, classGeneratorTables, secondaryTables, mappings);
			currentClassInHierarchy = currentClassInHierarchy.getSuperclass();
		} while ( isRootClass && ! Object.class.equals( currentClassInHierarchy ) );
		
		if (isRootClass) {
			( (RootClass) persistentClass).createPrimaryKey();
		}
		else {
			superEntity.addSubclass( (Subclass) persistentClass ); 
		}

		String entityName = "".equals( entityAnn.name() ) ? StringHelper.unqualify( annotatedClass.getName() ) : entityAnn.name();
		log.debug("Import with entity name=" + entityName);
		try {
			mappings.addImport( persistentClass.getEntityName(), entityName );
		}
		catch (MappingException me) {
			throw new AnnotationException("Use of the same entity name twice: " + entityName);
		}
		mappings.addClass(persistentClass);
		mapSecondaryTables(secondaryTables, secondaryTableJoins, persistentClass, propertyHolder, mappings);
    }

	private static HashMap<String, Properties> buildLocalGeneratorTable(AnnotatedElement annotatedClass) {
		HashMap<String, Properties> result = new HashMap<String, Properties>();
		GeneratorTable ann = (GeneratorTable) annotatedClass.getAnnotation(GeneratorTable.class);
		if (ann != null) {
			result.put( ann.name(), buildPropertiesFromGeneratorTable(ann) );
		}
		return result;
	}

	private static void mapSecondaryTables(Map<String, Join> secondaryTables, Map<String, Object> secondaryTableJoins, PersistentClass persistentClass, PropertyHolder propertyHolder, ExtendedMappings mappings) {
		Iterator joins = secondaryTables.values().iterator();
		Iterator joinColumns = secondaryTableJoins.values().iterator();

		while ( joins.hasNext() ) {
			JoinColumn[] columns = (JoinColumn[]) joinColumns.next();
			Join join = (Join) joins.next();
			SimpleValue key = new DependantValue( join.getTable(), persistentClass.getIdentifier() );
			join.setKey(key);
			join.setSequentialSelect(false);
			join.setInverse(false);
			join.setOptional(false);

			key.setCascadeDeleteEnabled(false);
			Ejb3JoinColumn[] ejb3JoinColumns;
			int nbrOfJoinColumns = columns.length;
			if (nbrOfJoinColumns == 0) {
				ejb3JoinColumns = new Ejb3JoinColumn[1];
				ejb3JoinColumns[0] = Ejb3JoinColumn.buildJoinColumn(
						(JoinColumn) null,
						persistentClass.getIdentifier(),
						secondaryTables,
						propertyHolder, mappings
				);
			}
			else {
				ejb3JoinColumns = new Ejb3JoinColumn[nbrOfJoinColumns];
				for (int colIndex = 0 ; colIndex < nbrOfJoinColumns ; colIndex++) {
					ejb3JoinColumns[colIndex] = Ejb3JoinColumn.buildJoinColumn(
							columns[colIndex],
							persistentClass.getIdentifier(),
							secondaryTables,
							propertyHolder, mappings
					);
				}
			}

			for (Ejb3JoinColumn joinColumn : ejb3JoinColumns) {
				joinColumn.forceNotNull();
			}
			bindFk(persistentClass, ejb3JoinColumns, key);
			join.createPrimaryKey(); //
			join.createForeignKey(); //
			persistentClass.addJoin(join); //
		}
		mappings.addJoins(persistentClass, secondaryTables);
	}

    private static void bindDiscriminatorToPersistentClass(RootClass rootClass,
														   Ejb3DiscriminatorColumn discriminatorColumn, Map<String, Join> secondaryTables,
														   PropertyHolder propertyHolder, ExtendedMappings mappings) {
		if (rootClass.getDiscriminator() == null) {
			if (discriminatorColumn == null) {
				Class clazz;
				try {
					clazz = ReflectHelper.classForName(rootClass.getClassName());
				}
				catch (ClassNotFoundException e) {
					throw new AnnotationException( "Root Class not found in classpath: " + rootClass.getClassName() );
				}
				Inheritance inhAnn = (Inheritance) clazz.getAnnotation(Inheritance.class);
				DiscriminatorType type;
				if (inhAnn == null) {
					type = null;
				}
				else {
					type = inhAnn.discriminatorType();
				}
				discriminatorColumn = Ejb3DiscriminatorColumn.buildDiscriminatorColumn(type, null, mappings);
			}
			discriminatorColumn.setJoins(secondaryTables);
			discriminatorColumn.setPropertyHolder(propertyHolder);
			SimpleValue discrim = new SimpleValue( rootClass.getTable() );
			rootClass.setDiscriminator(discrim);
			org.hibernate.mapping.Column col = discriminatorColumn.getMappingColumn();
			col.setValue(discrim);
			discrim.getTable().addColumn(col); //not sure this is the right place
			discrim.addColumn(col);
			discrim.setTypeName(discriminatorColumn.getDiscriminatorTypeName());
			rootClass.setPolymorphic(true);
			log.debug( "Setting discriminator for entity " + rootClass.getEntityName() );
		}
	}

	/**
	 * Process the elements of a particular class
	 */
	private static void processElementsOfAClass(PropertyHolder propertyHolder, boolean propertyAccess,
												boolean isNullable, final Class annotatedClass, HashMap<String, IdGenerator> classGenerators, HashMap<String, Properties> classGeneratorTables, Map<String, Join> secondaryTables,
												ExtendedMappings mappings) {
		ArrayList<AnnotatedElement> annElts = new ArrayList<AnnotatedElement>();
		ArrayList<AnnotedElementInferredData> inferredDatas = new ArrayList<AnnotedElementInferredData>();
		if (propertyAccess) {
			log.debug("Processing " + propertyHolder.getEntityName() + " per property access");
			Method[] methods = annotatedClass.getDeclaredMethods();
			AnnotatedElement currentElt;
			int index = 0;
			while( index < methods.length) {
				currentElt = (AnnotatedElement) methods[index];
				addAnnotatedElement(currentElt, annElts, inferredDatas);
				index++;
			}
		}
		else {
			log.debug("Processing " + propertyHolder.getEntityName() + " per field access");
			Field[] fields = annotatedClass.getDeclaredFields();
			AnnotatedElement currentElt;
			int index = 0;
			while( index < fields.length) {
				currentElt = (AnnotatedElement) fields[index];
				addAnnotatedElement(currentElt, annElts, inferredDatas);
				index++;
			}
		}
		//process them
		int size = annElts.size();
		for (int index = 0 ; index < size ; index++) {
			processElementAnnotations(propertyHolder, isNullable, annElts.get(index),
				mappings,
				inferredDatas.get(index),
				classGenerators,
				classGeneratorTables,
				secondaryTables);
		}
	}

	private static void addAnnotatedElement(AnnotatedElement elt, ArrayList<AnnotatedElement> annElts, ArrayList<AnnotedElementInferredData> inferredDatas) {
		AnnotedElementInferredData inferredData = new AnnotedElementInferredData(elt);
		if ( inferredData.isAnnotable() ) {
			/* 
			 * put element annotated by @Id in front
			 * since it has to be parsed before any assoctation by Hibernate 
			 */
			if ( elt.isAnnotationPresent(Id.class) ) {
				annElts.add(0, elt);
				inferredDatas.add(0, inferredData);
			}
			else {
				annElts.add(elt);
				inferredDatas.add(inferredData);
			}
		}
	}
	
	public static void bindEntity(PersistentClass persistentClass, Class clazz, String discrimValue) {
		persistentClass.setAbstract(false);
		persistentClass.setClassName( clazz.getName() );
		persistentClass.setDynamic(false);
		persistentClass.setEntityName( clazz.getName() );
		if ( discrimValue == null || discrimValue.equals("") ) {
			persistentClass.setDiscriminatorValue( persistentClass.getEntityName() );
		}
		else {
			persistentClass.setDiscriminatorValue(discrimValue);
		}
		
		/* 
		 * Gavin asked me to make all class as lazy since it is
		 * allowed by the EJB3 spec 
		 */
		persistentClass.setProxyInterfaceName( clazz.getName() );
	}
	
	public static void bindTable(PersistentClass persistentClass, String schema, String catalog, String tableName,
								 List uniqueConstraints, ExtendedMappings mappings) {
		Table table = fillTable(
			schema, catalog, 
			getClassTableName(persistentClass, tableName, mappings), 
			persistentClass.isAbstract(), uniqueConstraints, mappings
		); 
		
		if (persistentClass instanceof TableOwner) {
			( (TableOwner) persistentClass).setTable(table);	
		}
		else {
			throw new AssertionFailure("call of AnnBinder.bindTable for a SubClass");
		}
	}
	
	public static Table fillTable(String schema, String catalog, String realTableName, boolean isAbstract,
								  List uniqueConstraints, ExtendedMappings mappings) {
		schema = "".equals(schema) ? schema = mappings.getSchemaName() : schema;
		catalog = "".equals(catalog) ? catalog = mappings.getCatalogName() : catalog;
		Table table = mappings.addTable(
			schema,
			catalog,
			realTableName,
			null, //subselect
			isAbstract
		);
		if (uniqueConstraints.size() > 0)
			mappings.addUniqueConstraints(table, uniqueConstraints);
		return table;
	}

	/**
	 * Process annotation of a particular element
	 */
	private static void processElementAnnotations(PropertyHolder propertyHolder, boolean isNullable, AnnotatedElement annotedElt,
												  ExtendedMappings mappings,
												  AnnotedElementInferredData inferredData,
												  HashMap<String, IdGenerator> classGenerators,
												  HashMap<String, Properties> classGeneratorTables, Map<String, Join> secondaryTables)
		throws MappingException {
		Ejb3Column[] columns = null;
		if ( annotedElt.isAnnotationPresent(Transient.class) ) {
			return;
		}
		log.debug( "Processing " + inferredData.getPropertyName() );
		if ( annotedElt.isAnnotationPresent(Column.class) ) {
			Column ann = (Column) annotedElt.getAnnotation(Column.class);
			columns = Ejb3Column.buildColumnFromAnnotation(ann, propertyHolder, inferredData, secondaryTables, mappings);
		}  
		else if ( annotedElt.isAnnotationPresent(JoinColumn.class) ) {
			JoinColumn ann = (JoinColumn) annotedElt.getAnnotation(JoinColumn.class);
			columns = new Ejb3JoinColumn[1];
			columns[0] = Ejb3JoinColumn.buildJoinColumn(ann, inferredData.getPropertyName(),
				secondaryTables, propertyHolder, mappings);
		}
		else if ( annotedElt.isAnnotationPresent(JoinColumns.class) ) {
			JoinColumns ann = annotedElt.getAnnotation(JoinColumns.class);
			JoinColumn[] annColumns = ann.value();
			int length = annColumns.length;
			if (length == 0) {
				//FIXME not sure this is appropriate, I need to reread the spec later
				throw new AnnotationException("Cannot bind an empty @JoinColumns");
			}
			columns = new Ejb3JoinColumn[length];
			for (int index = 0 ; index < length ; index++) {
				columns[index] = Ejb3JoinColumn.buildJoinColumn(annColumns[index], inferredData.getPropertyName(),
						secondaryTables, propertyHolder, mappings);
			}
		}
		else {
			//Collection.DEFAULT_KEY_COLUMN_NAME for many-to-many
			if ( annotedElt.isAnnotationPresent(ManyToOne.class) ) {
				columns = new Ejb3JoinColumn[1];
				columns[0] = Ejb3JoinColumn.buildJoinColumn( (JoinColumn) null,
					inferredData.getPropertyName(), secondaryTables, 
					propertyHolder, mappings);
			}
			else if ( annotedElt.isAnnotationPresent(OneToMany.class) ) {
				//FIXME: guess the correct name by getting it from ManyToOne side
				columns = new Ejb3JoinColumn[1];
				columns[0] = Ejb3JoinColumn.buildJoinColumn( (JoinColumn) null,
					inferredData.getPropertyName(), secondaryTables, 
					propertyHolder, mappings);
			}
			else if ( annotedElt.isAnnotationPresent(OneToOne.class) ) {
				columns = null;
			}
			else {
				columns = Ejb3Column.buildColumnFromAnnotation(null, propertyHolder, inferredData, secondaryTables, mappings);
			}
		}
		if (isNullable == false) {
			//force columns to not null
			for (Ejb3Column col : columns) {
				col.forceNotNull();
			}
		}

		if ( annotedElt.isAnnotationPresent(Id.class) ) {
			log.debug(inferredData.getPropertyName() + " is an id");
			Id ann = (Id) annotedElt.getAnnotation(Id.class);
			
			//clone classGenerator and override with local values
			HashMap<String, IdGenerator> localGenerators = (HashMap<String, IdGenerator>) classGenerators.clone();
			HashMap<String, Properties> localGeneratorTables = (HashMap<String, Properties>) classGeneratorTables.clone();
			localGenerators.putAll( buildLocalGenerators(annotedElt) );
			localGeneratorTables.putAll( buildLocalGeneratorTable(annotedElt) );
			DependentObject depAnn = (DependentObject) inferredData.getReturnedClass().getAnnotation(DependentObject.class);
			Dependent overrideAnn = (Dependent) annotedElt.getAnnotation(Dependent.class);
			Map<String, Column[]> columnOverride = new HashMap<String, Column[]>();
			if (overrideAnn != null) {
				for ( DependentAttribute depAttr : overrideAnn.value() ) {
					columnOverride.put( depAttr.name(), depAttr.column() );
				}
			}
			final boolean isComponent = depAnn != null;
			final boolean propertyAccess = isComponent ? depAnn.access() == AccessType.PROPERTY : false;
			//for now columns.length > 1 is impossible for @Id
			bindId(
				generatorType( ann.generate() ),
				ann.generator(),
				inferredData,
				columns[0],
				(RootClass) propertyHolder.getPersistentClass(),
				localGenerators,
				localGeneratorTables,
				isComponent,
				columnOverride,
				propertyAccess,
				secondaryTables,
				mappings);
			log.debug("Bind @Id on " + inferredData.getPropertyName() );
		}
		else if ( annotedElt.isAnnotationPresent(Version.class) ) {
			log.debug(inferredData.getPropertyName() + " is a version property");
			RootClass rootClass = (RootClass) propertyHolder.getPersistentClass();
			boolean lazy = false;
			//for now columns.length > 1 is impossible for @Version
            Property prop = bindProperty(
				inferredData.getPropertyName(), 
				inferredData.getReturnedClassName(), 
				lazy, 
				inferredData.getDefaultAccess(), 
				columns[0],
				PropertyHolderBuilder.buildPropertyHolder(rootClass)
			);
			rootClass.setVersion(prop);
			SimpleValue simpleValue = (SimpleValue) prop.getValue();
			if ( !simpleValue.isTypeSpecified() ) simpleValue.setTypeName("integer");
			simpleValue.setNullValue("undefined");
			rootClass.setOptimisticLockMode(Versioning.OPTIMISTIC_LOCK_VERSION);
			log.debug( "Version name: " + rootClass.getVersion().getName() + ", unsavedValue: " + ( (SimpleValue) rootClass.getVersion().getValue() ).getNullValue() );
		}
		else if ( annotedElt.isAnnotationPresent(ManyToOne.class) ) {
			ManyToOne ann = (ManyToOne) annotedElt.getAnnotation(ManyToOne.class);
			
			bindManyToOne( getCascadeStrategy( ann.cascade() ), 
				(Ejb3JoinColumn[]) columns,
				ann.optional(), 
				getFetchMode( ann.fetch() ), 
				inferredData.getPropertyName(), 
				inferredData.getReturnedClassName(), 
				ann.targetEntity(),
				inferredData.getDefaultAccess(),
				propertyHolder,
				mappings
			);
		}
		else if ( annotedElt.isAnnotationPresent(OneToOne.class) ) {
			OneToOne ann = annotedElt.getAnnotation(OneToOne.class);
			if (columns == null) {
				columns = new Ejb3JoinColumn[0];
			}
			bindOneToOne( getCascadeStrategy( ann.cascade() ), 
				(Ejb3JoinColumn[]) columns,
				ann.optional(), 
				getFetchMode( ann.fetch() ), 
				inferredData.getPropertyName(), 
				inferredData.getReturnedClassName(), 
				ann.targetEntity(), 
				inferredData.getDefaultAccess(),
				propertyHolder,
				mappings
			);
		}
		else if ( annotedElt.isAnnotationPresent(OneToMany.class) ) {
			OneToMany ann = annotedElt.getAnnotation(OneToMany.class);
			
			bindOneToMany(inferredData.getCollectionType(), ann.targetEntity(), 
				inferredData.getPropertyName(), inferredData.getReturnedClass(), 
				getFetchMode( ann.fetch() ), 
				(Ejb3JoinColumn[]) columns, getCascadeStrategy( ann.cascade() ),
				inferredData.getDefaultAccess(), propertyHolder, mappings);
		}
		else if ( annotedElt.isAnnotationPresent(ManyToMany.class) ) {
			ManyToMany ann = annotedElt.getAnnotation(ManyToMany.class);
			Table assocTable;
			JoinColumn[] annJoins = null;
			JoinColumn[] annInverseJoins = null;
			if ( annotedElt.isAnnotationPresent(AssociationTable.class) ) {
				AssociationTable atAnn = annotedElt.getAnnotation(AssociationTable.class);
				if (! atAnn.table().specified() ) {
					throw new NotYetImplementedException("Implicit Table in AssociationTable");
				}
				assocTable = fillTable(atAnn.table().schema(), 
					atAnn.table().catalog(),
					mappings.getNamingStrategy().tableName( atAnn.table().name() ),
					false, new ArrayList(), mappings);
				
				JoinColumn[] joins = atAnn.joinColumns();
				
				if (joins.length == 0) {
					annJoins = null;
				}
				else {
					annJoins = joins;
				}

				JoinColumn[] inverseJoins = atAnn.inverseJoinColumns();
				
				if (inverseJoins.length == 0) {
					annInverseJoins = null;
				}
				else {
					annInverseJoins = inverseJoins;
				}
			}
			else {
				throw new NotYetImplementedException("Implicit AssociationTable");
			}
			Ejb3JoinColumn[] joinColumns = buildArrayOfEjb3JoinColumn(annJoins, secondaryTables, propertyHolder, mappings);
			Ejb3JoinColumn[] inverseJoinColumns = buildArrayOfEjb3JoinColumn(annInverseJoins, secondaryTables, propertyHolder, mappings);
			bindManyToMany(inferredData.getCollectionType(), ann.targetEntity(),
				inferredData.getPropertyName(), inferredData.getReturnedClass(), 
				getFetchMode( ann.fetch() ), 
				assocTable, getCascadeStrategy( ann.cascade() ), 
				inferredData.getDefaultAccess(), propertyHolder, ann.isInverse(),
				joinColumns, inverseJoinColumns,
				mappings
			);
		}
		else {
			if (mappings.getClassType( inferredData.getReturnedClass() ).equals(AnnotatedClassType.DEPENDENT) ) {
				//dependent object
				DependentObject ann = (DependentObject) inferredData.getReturnedClass().getAnnotation(DependentObject.class);
				final boolean propertyAccess = ann.access() == AccessType.PROPERTY;
				Dependent depAnn = (Dependent) annotedElt.getAnnotation(Dependent.class);
				Map<String, Column[]> columnOverride = new HashMap<String, Column[]>();
				if (depAnn != null) {
					for ( DependentAttribute depAttr : depAnn.value() ) {
						columnOverride.put( depAttr.name(), depAttr.column() );
					}
				}
				bindComponent(inferredData, propertyHolder, propertyAccess, secondaryTables, columnOverride,  mappings);
			}
			else {
				//provide the basic property mapping
				log.debug(inferredData.getPropertyName() + " is a property");
				boolean lazy = false;

				if ( annotedElt.isAnnotationPresent(Basic.class) ) {
					Basic ann = (Basic) annotedElt.getAnnotation(Basic.class);
					if ( ann.fetch() == FetchType.LAZY ) {
						lazy = true;
						log.debug(inferredData.getPropertyName() + " is lazy");
					}
				}

				bindProperty(
					inferredData.getPropertyName(),
					inferredData.getReturnedClassName(),
					lazy,
					inferredData.getDefaultAccess(),
					columns[0],
					propertyHolder
				);
			}
		}
	}

	private static Ejb3JoinColumn[] buildArrayOfEjb3JoinColumn(JoinColumn[] annJoins, Map<String, Join> secondaryTables,
												   PropertyHolder propertyHolder, ExtendedMappings mappings) {
		Ejb3JoinColumn[] joinColumns;
		if (annJoins == null) {
			joinColumns = new Ejb3JoinColumn[] {
				Ejb3JoinColumn.buildJoinColumn( (JoinColumn) null, (String) null, secondaryTables, propertyHolder, mappings)
			};
		}
		else {
			joinColumns = new Ejb3JoinColumn[annJoins.length];
			JoinColumn annJoin;
			int length = annJoins.length;
			for (int index = 0 ; index < length ; index++) {
				annJoin = annJoins[index];
				joinColumns[index] = Ejb3JoinColumn.buildJoinColumn( (JoinColumn) annJoin, (String) null, secondaryTables, propertyHolder, mappings);
			}
		}
		return joinColumns;
	}

	private static void bindComponent(
			AnnotedElementInferredData inferredData,
			PropertyHolder propertyHolder,
			boolean propertyAccess,
			Map<String, Join> secondaryTables,
			Map<String, Column[]> columnOverride,
			ExtendedMappings mappings) {
		Component comp = fillComponent(propertyHolder, inferredData, propertyAccess, true, secondaryTables, columnOverride, mappings);

		Property prop = makeProperty(
				inferredData.getPropertyName(),
				comp,
				true,
				true,
				false,
				null,
				inferredData.getDefaultAccess()
		);
		propertyHolder.addProperty(prop);
	}

	private static Component fillComponent(PropertyHolder propertyHolder, AnnotedElementInferredData inferredData,
										   boolean propertyAccess, boolean isNullable, Map<String, Join> secondaryTables,
										   Map<String, Column[]> columnOverride, ExtendedMappings mappings) {
		Component comp = new Component( propertyHolder.getPersistentClass() );
		comp.setComponentClassName( inferredData.getReturnedClassName() );
		String subpath = StringHelper.qualify( propertyHolder.getPath(), inferredData.getPropertyName() );
		log.debug("Binding component with path: " + subpath);
		PropertyHolder subHolder = PropertyHolderBuilder.buildPropertyHolder(comp, subpath, columnOverride);

		processElementsOfAClass(
				subHolder,
				propertyAccess,
				isNullable, inferredData.getReturnedClass(),
				new HashMap<String, IdGenerator>(),
				new HashMap<String, Properties>(),
				secondaryTables,
				mappings
		);
		return comp;
	}

	private static void bindId(String generatorType, String generatorName,
							   AnnotedElementInferredData inferredData, Ejb3Column column, RootClass rootClass,
							   Map<String, IdGenerator> localGenerators, HashMap<String, Properties> localGeneratorTables, boolean isComposite, Map<String, Column[]> columnOverride, boolean isPropertyAccess,
							   Map<String, Join> secondaryTables, ExtendedMappings mappings)  {
		/*
		 * Fill simple value and property since and Id is a property
		 */
		String persistentClassName = rootClass == null ? null : rootClass.getClassName();
		SimpleValue id;
		if (isComposite) {
			id = fillComponent(PropertyHolderBuilder.buildPropertyHolder(rootClass), inferredData, isPropertyAccess, false, secondaryTables, columnOverride, mappings);
		}
		else {
			column.forceNotNull(); //this is an id
			id = makeSimpleValue(inferredData.getPropertyName(), inferredData.getReturnedClassName(), column, persistentClassName);
		}
		rootClass.setIdentifier(id);
		Table table = id.getTable();
		table.setIdentifierValue(id);
		//generator settings
		id.setIdentifierGeneratorStrategy(generatorType);
		if (generatorType == "assigned") id.setNullValue("undefined");
		Properties params = new Properties();
		//always settable
		params.setProperty(
			PersistentIdentifierGenerator.TABLE, table.getName()
		);
		params.setProperty(
			PersistentIdentifierGenerator.PK,
			( (org.hibernate.mapping.Column) id.getColumnIterator().next() ).getName()
		);
		if (! "".equals(generatorName) ) {
			//we have a named generator
			IdGenerator gen = mappings.getGenerator(generatorName, localGenerators);
			if (gen == null) {
				throw new AnnotationException("Unknown Id.generator: " + generatorName);
			}
			if ( ! gen.getIdentifierGeneratorStrategy().equals(generatorType) ) {
				//named generator and id one should be compatible
				throw new AnnotationException(
					"Incompatible generator between Id.generate and its named generator: "
					+ generatorType + "!=" + generatorName);
			}
			Iterator genParams = gen.getParams().entrySet().iterator();
			while ( genParams.hasNext() ) {
				Map.Entry elt = (Map.Entry) genParams.next();
				params.setProperty(  (String) elt.getKey(), (String) elt.getValue() );
			}
			if ( MultipleHiLoPerTableGenerator.class.getName().equals(generatorType) ) {
				//try and find the associated Generator Table
				fillGeneratorWithGeneratorTableParams(params, localGeneratorTables, generatorName, mappings);
			}
		}
		id.setIdentifierGeneratorProperties(params);
		
		Property prop = makeProperty(inferredData.getPropertyName(), id, true, true, false, null, inferredData.getDefaultAccess());
		rootClass.setIdentifierProperty(prop);
	}

	private static void fillGeneratorWithGeneratorTableParams(Properties params, HashMap<String, Properties> localGeneratorTables, String generatorName, ExtendedMappings mappings) {
		final String generatorTableName = params.getProperty(GENERATOR_TABLE_NAME_PARAM);
		Properties props = mappings.getGeneratorTableProperties(generatorTableName, localGeneratorTables);
		if (props == null) {
			if ( MultipleHiLoPerTableGenerator.DEFAULT_TABLE_NAME.equals(generatorTableName) ) {
				//default value
				return;
			}
			else {
				throw new AnnotationException("Unable to find a @GeneratorTable for table name in " + generatorName + ": " + generatorTableName );
			}
		}
		else {
			Iterator properties = props.entrySet().iterator();
			java.util.Map.Entry<String, String> property;
			while ( properties.hasNext() ) {
				property = (java.util.Map.Entry<String, String>) properties.next();
				params.setProperty( property.getKey(), property.getValue() );
			}
		}
	}

	private static SimpleValue makeSimpleValue(String propertyName, String returnedClassName, Ejb3Column column,
											   String persistentClassName) {
		log.debug("making simplevalue for " + propertyName);
		Table table = column.getTable();
		SimpleValue simpleValue = new SimpleValue(table);
		return fillSimpleValue(simpleValue, propertyName, returnedClassName, column, persistentClassName);
	}
	
	private static SimpleValue fillSimpleValue(SimpleValue simpleValue, String propertyName, String returnedClassName,
											   Ejb3Column column, String persistentClassName) {
		simpleValue.setTypeName(returnedClassName);
		if (persistentClassName != null) {
			simpleValue.setTypeUsingReflection( persistentClassName, propertyName );
		}
		column.linkWithValue(simpleValue);
		return simpleValue;
	}

	private static Property bindProperty(String name, String returnedClassName, boolean lazy, String propertyAccessorName, Ejb3Column column, PropertyHolder propertyHolder) {
		log.debug("binding property " + name);
		String containerClassName = propertyHolder == null ? null : propertyHolder.getClassName();
		SimpleValue propertyValue = makeSimpleValue(name, returnedClassName, column, containerClassName);
		
		Property prop = makeProperty(name, propertyValue, column.isInsertable(), column.isUpdatable(), lazy, null, propertyAccessorName);
		column.addPropertyToMappingContainer(prop);
		return prop;
	}
	
	private static Property makeProperty(String propertyName, Value value, boolean insertable, boolean updatable, boolean lazy, String cascade, String propertyAccessorName) {
		log.debug("Building property " + propertyName);
		Property prop = new Property();
		prop.setName(propertyName);
		prop.setValue(value);
		prop.setInsertable(insertable);
		prop.setUpdateable(updatable);
		prop.setLazy(lazy);
		prop.setCascade(cascade);
		prop.setPropertyAccessorName(propertyAccessorName);
		log.debug("Cascading " + propertyName + " with " + cascade);
		return prop;
	}
	
	private static void bindManyToOne(String cascadeStrategy, Ejb3JoinColumn[] columns, boolean optional, FetchMode fetchMode, String propertyName, String returnedClassName, String targetEntity, String propertyAccessorName, PropertyHolder propertyHolder, ExtendedMappings mappings) {
		//All FK columns should be in the same table
		org.hibernate.mapping.ManyToOne value = new org.hibernate.mapping.ManyToOne( columns[0].getTable() );
		if ( "".equals(targetEntity) ) {
			value.setReferencedEntityName(returnedClassName);	
		} 
		else {
			value.setReferencedEntityName(targetEntity); 
		}
		value.setFetchMode(fetchMode);
		
		//TODO: manytoOne(optional=false)
		if (!optional) log.warn( new NotYetImplementedException("ManyToOne.optional() == false") );
		value.setTypeName(returnedClassName);
		value.setTypeUsingReflection(propertyHolder.getClassName() , propertyName);
		String propertyRef = value.getReferencedPropertyName();
		if (propertyRef!=null) mappings.addUniquePropertyReference(
				value.getReferencedEntityName(),
				propertyRef
			);
		//value.createForeignKey();
		mappings.addSecondPass( new FkSecondPass(value, columns, mappings) );
		Property prop = makeProperty(propertyName, value, true, true, false, cascadeStrategy, propertyAccessorName);
		prop.setCascade(cascadeStrategy);

		//composite FK columns are in the same table so its OK
		columns[0].addPropertyToMappingContainer(prop);
	}

	public static void bindFkSecondPass(org.hibernate.mapping.ManyToOne manyToOne, Ejb3JoinColumn[] columns, Map persistentClasses) {
		PersistentClass ref = (PersistentClass) persistentClasses.get( manyToOne.getReferencedEntityName() );
		if (ref == null) throw new AnnotationException("Unable to find entity " + manyToOne.getReferencedEntityName() );
		bindFk(ref, columns, manyToOne);
	}

	private static void bindFk(PersistentClass referencedEntity, Ejb3JoinColumn[] columns, SimpleValue value) {
		if (referencedEntity.getIdentifier().getColumnSpan() == 1) {
			if (columns.length != 1) {
				throw new AnnotationException("@JoinColumns with " + columns.length + " columns"
					+ " refers to " + referencedEntity.getEntityName() + " which has a "
					+ referencedEntity.getIdentifier().getColumnSpan() + " sized PK");
			}
			else {
				//nothing has to be explicit
				columns[0].linkWithValue(value);
			}
		}
		else {
			//Check if we have to do it the implicit way
			//TODO: clarify the spec on it
			boolean noReferencedColumn = true;
			for (Ejb3JoinColumn joinCol : columns) {
				if ( StringHelper.isNotEmpty( joinCol.getReferencedColumn() ) ) {
					noReferencedColumn = false;
					break;
				}
			}
			if (noReferencedColumn) {
				//implicit case, we hope PK and FK columns are in the same order
				if (columns.length != referencedEntity.getIdentifier().getColumnSpan() ) {
					throw new AnnotationException("A Foreign key refering " + referencedEntity.getEntityName()
						+ " has the wrong number of column. should be " + referencedEntity.getIdentifier().getColumnSpan());
				}
				for (Ejb3JoinColumn joinCol : columns) {
					joinCol.linkWithValue(value);
				}
			}
			else {
				//explicit referencedColumnName
				Iterator idColItr = referencedEntity.getIdentifier().getColumnIterator();
				org.hibernate.mapping.Column col;
				if (! idColItr.hasNext()) log.debug("No column in the identifier!");
				while ( idColItr.hasNext() ) {
					boolean match = false;
					//for each PK column, find the associated FK column.
					col = (org.hibernate.mapping.Column) idColItr.next();
					for (Ejb3JoinColumn joinCol : columns) {
						if ( joinCol.getReferencedColumn().equals( col.getName() ) ) {
							//proper join column
							joinCol.linkWithValue(value);
							match = true;
							break;
						}
					}
					if (match == false) {
						throw new AnnotationException("Column name " + col.getName() + " of "
								+ referencedEntity.getEntityName() + " not found in JoinColumns.referencedColumnName");
					}
				}
			}
		}
        value.createForeignKey();
	}

	private static void bindOneToOne(String cascadeStrategy, Ejb3JoinColumn[] columns, boolean optional, FetchMode fetchMode, String propertyName, String returnedClassName, String targetEntity, String propertyAccessorName, PropertyHolder propertyHolder, ExtendedMappings mappings) {
		//column.getTable() => persistentClass.getTable()
		Iterator idColumns = propertyHolder.getIdentifier().getColumnIterator();
		List<String> idColumnNames = new ArrayList<String>();
		org.hibernate.mapping.Column currentColumn;
		while( idColumns.hasNext() ) {
			currentColumn = (org.hibernate.mapping.Column) idColumns.next();
			idColumnNames.add( currentColumn.getName() );
		}
		boolean trueOneToOne = true;
		for (Ejb3JoinColumn col : columns) {
			if ( ! idColumnNames.contains( col.getMappingColumn().getName() ) ) {
				trueOneToOne = false;
				break;
			}
//			if (StringHelper.isEmpty( col.getReferencedColumn() ) ) {
//				// this is not an id to id
//				referenced = false;
//			}
		}

		if (trueOneToOne) {
			//is a true one-to-one
			//FIXME referencedColumnName ignored => ordering may fail.
			org.hibernate.mapping.OneToOne value = new org.hibernate.mapping.OneToOne( propertyHolder.getTable(), propertyHolder.getIdentifier() );
			if ( "".equals(targetEntity) ) {
				value.setReferencedEntityName(returnedClassName);
			}
			else {
				value.setReferencedEntityName(targetEntity);
			}
			value.setFetchMode(fetchMode);

			//TODO: manytoOne(optional=false)
			if (!optional) log.warn( new NotYetImplementedException("OneToOne.optional()") );
			//FIXME Handle bidir OneToOne
			boolean constrained = false;
			value.setForeignKeyType(
				constrained ?
				ForeignKeyDirection.FOREIGN_KEY_FROM_PARENT :
				ForeignKeyDirection.FOREIGN_KEY_TO_PARENT
			);

			String propertyRef = value.getReferencedPropertyName();
			if (propertyRef!=null) mappings.addUniquePropertyReference(
				value.getReferencedEntityName(),
				propertyRef
			);
			//value.createForeignKey();
			Property prop = makeProperty(propertyName, value, true, true, false, cascadeStrategy, propertyAccessorName);
			prop.setCascade(cascadeStrategy);
			//no column associated since its a one to one
			propertyHolder.addProperty(prop);
		}
		else {
			//has a FK on the table
			//TODO add the unique constrains
			bindManyToOne(cascadeStrategy, columns, optional, fetchMode, propertyName, returnedClassName, targetEntity,
				propertyAccessorName, propertyHolder, mappings);
		}
	}
	
	private static void bindOneToMany(Class collectionType, String targetEntity, 
		String propertyName, Class returnedClass, FetchMode fetchMode, 
		Ejb3JoinColumn[] columns, String cascadeStrategy, String propertyAccessorName,
		PropertyHolder propertyHolder, ExtendedMappings mappings) {
		for (Ejb3JoinColumn column : columns) {
			if ( column.isSecondary() ) {
				throw new NotYetImplementedException("Collections having FK in secondary table");
			}
		}
		Collection collection = fillCollection(
				propertyName, returnedClass,
				fetchMode, propertyHolder);
		collection.setInverse(true); //If I understand well EJB3 6.1.6
		
		org.hibernate.mapping.OneToMany oneToMany = new org.hibernate.mapping.OneToMany( collection.getOwner() );
		collection.setElement(oneToMany);
		oneToMany.setReferencedEntityName( getCollectionType(collectionType, targetEntity) );
		mappings.addSecondPass( new CollectionSecondPass(mappings, collection, columns) );
		mappings.addCollection(collection);
		Property prop = makeProperty(propertyName, collection, true, true, false, cascadeStrategy, propertyAccessorName);
		//we don't care about the join stuffs because the column is on the other side.
		propertyHolder.addProperty(prop);
	}
	
	private static void bindManyToMany(Class collectionType, String targetEntity, 
		String propertyName, Class returnedClass, FetchMode fetchMode, 
		Table table, String cascadeStrategy, String propertyAccessorName, 
		PropertyHolder propertyHolder, boolean isInverse,
		Ejb3JoinColumn[] joinColumns, Ejb3JoinColumn[] inverseJoinColumns, ExtendedMappings mappings) {
			
		log.debug("Binding ManyToMany: " + propertyName);
		//log.debug( "Joincolumn: " + joinColumn.getMappingColumn().getName() );
		//log.debug( "InverseJoincolumn: " + inverseJoinColumn.getMappingColumn().getName() );
		Collection collection = fillCollection(
			propertyName, returnedClass,
			fetchMode, propertyHolder);
		collection.setInverse(isInverse);
		collection.setCollectionTable(table);
		String collType = getCollectionType(collectionType, targetEntity);
		//NEXT: think of second mapp and JoinColumns
		mappings.addSecondPass( 
			new CollectionSecondPass(
				mappings, collection, 
				joinColumns, inverseJoinColumns,
				collType,
				fetchMode
			) 
		);
		mappings.addCollection(collection);
		Property prop = makeProperty(propertyName, collection, true, true, false, cascadeStrategy, propertyAccessorName);
		//we don't care about the join stuffs because the column is on the association table.
		propertyHolder.addProperty(prop);
	}

	private static Collection fillCollection(
		String propertyName, Class returnedClass, 
		FetchMode fetchMode, PropertyHolder propertyHolder) {
		
		Collection collection;
		if ( returnedClass.equals(Set.class) ) {
			collection = new org.hibernate.mapping.Set( propertyHolder.getPersistentClass() );
		}
		else if ( returnedClass.equals(java.util.Collection.class) ) {
			collection = new Bag( propertyHolder.getPersistentClass() );
		}
		else {
			throw new AnnotationException(returnedClass.getName() + " collection not yet supported");
		}
		log.debug("Collection role: " + StringHelper.qualify(propertyHolder.getPath(), propertyName) );
		collection.setRole( StringHelper.qualify(propertyHolder.getPath(), propertyName) );
	
		//set laziness
		collection.setFetchMode(fetchMode);
		collection.setLazy(fetchMode == FetchMode.SELECT);
		return collection;
	}
	
	private static String getCollectionType(Class collectionType, String targetEntity) {

        if ( "".equals(targetEntity) ) {
			if (collectionType != null) {
				return collectionType.getName();
			} 
			else {
				throw new AnnotationException("Collection has neither generic type or OneToMany.targetEntity() defined");
			}
		} 
		else {
			return targetEntity;
		}
	}
	
	public static void bindCollectionSecondPass(Collection collValue, java.util.Map persistentClasses, Ejb3JoinColumn[] columns, ExtendedMappings mappings) throws MappingException {
		if ( collValue.isOneToMany() ) {
			org.hibernate.mapping.OneToMany oneToMany = 
				(org.hibernate.mapping.OneToMany) collValue.getElement();
			String assocClass = oneToMany.getReferencedEntityName();
			PersistentClass persistentClass = (PersistentClass) persistentClasses.get(assocClass);
			if (mappings == null) {
				throw new AssertionFailure("CollectionSecondPass for oneToMany should not be called with null mappings");
			}
			Map<String, Join> joins = mappings.getJoins(assocClass);
			if (persistentClass==null) throw new MappingException(
				"Association references unmapped class: " + assocClass
			);
			oneToMany.setAssociatedClass(persistentClass);
			//FIXME: find the appropriate table between second and primary
			for (Ejb3JoinColumn column : columns) {
				column.setPersistentClass(persistentClass);
				column.setJoins(joins);
				collValue.setCollectionTable( column.getTable() );
			}

			log.info("Mapping collection: " + collValue.getRole() + " -> " + collValue.getCollectionTable().getName() );
		}
		
		//binding key reference using column
		KeyValue keyVal;
		String propRef = collValue.getReferencedPropertyName();
		if (propRef==null) {
			keyVal = collValue.getOwner().getIdentifier();
		}
		else {
			keyVal = (KeyValue) collValue.getOwner()
				.getProperty(propRef)
				.getValue();
		}
		SimpleValue key = new DependantValue( collValue.getCollectionTable(), keyVal );
		//fillSimpleValue(key, null, null, column, null);
		key.setTypeName(null);
		bindFk(collValue.getOwner(), columns, key);

		collValue.setKey(key);
	}
	
	public static void bindManyToManySecondPass(
		Collection collValue, 
		java.util.Map persistentClasses, 
		Ejb3JoinColumn[] joinColumns,
		Ejb3JoinColumn[] inverseJoinColumns,
		String collType,
		FetchMode fetchMode) throws MappingException {
		
		bindCollectionSecondPass(collValue, persistentClasses, joinColumns, null);
		org.hibernate.mapping.ManyToOne element = 
			new org.hibernate.mapping.ManyToOne( collValue.getCollectionTable() );
		collValue.setElement(element);
		element.setReferencedEntityName(collType);
		element.setFetchMode(fetchMode);
		
		//FIXME: do optional = false
//		value.setTypeName(returnedClassName);
//		value.setTypeUsingReflection(persistentClass.getClassName() , propertyName);
		PersistentClass persistentClass = (PersistentClass) persistentClasses.get(collType);
		if (persistentClass==null) throw new MappingException(
			"Association references unmapped class: " + collType
		);
		bindFk(persistentClass, inverseJoinColumns, element);

		//inverseJoinColumn.getMappingColumn().setValue(element);
		//element.getTable().addColumn( inverseJoinColumn.getMappingColumn() );
		//element.addColumn( inverseJoinColumn.getMappingColumn() );
//		String referencedColumn = ( (Ejb3JoinColumn) inverseJoinColumn ).getReferencedColumn();
//		if ( referencedColumn != null && !referencedColumn.equals("") ) throw new NotYetImplementedException("JoinColumn.referencedColumnName");

//		value.createForeignKey();
		//bindManyToOne(subnode, element, Collection.DEFAULT_ELEMENT_COLUMN_NAME, false, mappings);
		//FIXME: Watch for fetch of the element in the collection
		
	}
	
	private static String generatorType(GeneratorType generatorEnum) {
		switch ( generatorEnum ) {
			case NONE : return "assigned";
			case IDENTITY:return "identity";
			case AUTO:return "native";
			case TABLE:return MultipleHiLoPerTableGenerator.class.getName();
			case SEQUENCE:return "sequence";
		} 
		throw new AssertionFailure("Unknown GeneratorType: " + generatorEnum);
	}
	
	private static String getClassTableName(PersistentClass model, String tableName, ExtendedMappings mappings) {
		if ( tableName.equals("") ) {
			return mappings.getNamingStrategy().classToTableName( model.getEntityName() );
		}
		else {
			return mappings.getNamingStrategy().tableName(tableName);
		}
	}
	
	private static String getCascadeStrategy(CascadeType[] cascades) {
		if (cascades.length == 0) {
			return "none";
		}
		boolean all = false;
		boolean create = false;
		boolean merge = false;
		boolean remove = false;
		for(CascadeType cascade: cascades) {
			switch (cascade) {
				case ALL:
					all = true; 
					break;
				case CREATE:
					create = true;
					break;
				case MERGE:
					merge = true;
					break;
				case REMOVE:
					remove = true;
					break;
			}
		}
		
		if (!all) all = create && merge && remove;
		
		
		if (all) return "all";
		if (create && merge) return "create,merge,save-update"; //HBX-47
		if (create && remove) return "create,delete,save-update"; //HBX-47
		if (merge && remove) return "merge,delete,save-update"; //HBX-47
		if (remove) return "delete";
		if (create) return "create,save-update"; //HBX-47
		if (merge) return "merge,save-update"; //HBX-47
		
		
		throw new AssertionFailure("Error in cascade strategies mapper");
	}
	
	private static FetchMode getFetchMode(FetchType fetch) {
		if (fetch == FetchType.EAGER) {
			return FetchMode.JOIN;
		} 
		else {
			return FetchMode.SELECT;
		}
	}
	
	private static HashMap<String,IdGenerator> buildLocalGenerators(AnnotatedElement annElt) {
		HashMap<String,IdGenerator> generators = new HashMap<String, IdGenerator>();
		TableGenerator tabGen = (TableGenerator) annElt.getAnnotation(TableGenerator.class);
		SequenceGenerator seqGen = (SequenceGenerator) annElt.getAnnotation(SequenceGenerator.class);
		if (tabGen != null) {
			IdGenerator idGen = buildIdGenerator(tabGen);
			generators.put(idGen.getName(), idGen);
		}
		if (seqGen != null) {
			IdGenerator idGen = buildIdGenerator(seqGen);
			generators.put(idGen.getName(), idGen);
		}
		return generators;
	}
	
	private static void prepareForSecondaryTable(SecondaryTable tabAnn, PersistentClass persistentClass, Map<String, Join> secondaryTables, Map<String, Object> secondaryTableJoins, ExtendedMappings mappings) {
		Join join = new Join();
		join.setPersistentClass(persistentClass);
		List uniqueConstraints = new ArrayList();
		if (tabAnn.uniqueConstraints().length != 0) {
			for( UniqueConstraint uc : tabAnn.uniqueConstraints() ) {
				if (! uc.primary() ) {
					uniqueConstraints.add( uc.columnNames() );
				}
				else {
					log.warn("@UniqueConstraint(primaryKey=true) not yet supported");
				}
			}
		}
		org.hibernate.mapping.Table tableMapping = fillTable(
			tabAnn.schema(), tabAnn.catalog(), 
			tabAnn.name(), 
			false, uniqueConstraints, mappings
		);
		join.setTable(tableMapping);
		//somehow keep joins() for later.
		//Has to do the work later because it needs persistentClass id!
		secondaryTableJoins.put(tabAnn.name(), tabAnn.join() );
		log.info("Mapping class join: " + persistentClass.getEntityName() + " -> " + join.getTable().getName() );
		secondaryTables.put(tabAnn.name(), join);
	}
}
