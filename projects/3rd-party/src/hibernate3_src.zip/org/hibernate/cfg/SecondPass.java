//$Id: SecondPass.java,v 1.4 2004/09/14 21:06:05 epbernard Exp $
package org.hibernate.cfg;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.mapping.Collection;

/**
 * Abstract Second pass class for collection process.
 * FIXME: Have to extends HbmBinder.SecondPass to allow mapping.addSecondPass(SecondPass)
 * This sucks a bit because we have linked Node and Mappings via SecondPass.  
 * 
 * @author Emmanuel Bernard
 */
public abstract class SecondPass extends HbmBinder.SecondPass {
	protected static Log log = LogFactory.getLog(SecondPass.class);
	
	SecondPass(
		Mappings mappings, 
		Collection coll) {
		super(null, mappings, coll);
	}

}
