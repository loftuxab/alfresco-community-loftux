//$Id: Ejb3Column.java,v 1.8 2004/12/24 11:32:35 epbernard Exp $
package org.hibernate.cfg;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.AnnotationException;
import org.hibernate.AssertionFailure;
import org.hibernate.mapping.Column;
import org.hibernate.mapping.Join;
import org.hibernate.mapping.Property;
import org.hibernate.mapping.SimpleValue;
import org.hibernate.mapping.Table;
import org.hibernate.util.StringHelper;

import java.util.Map;

/**
 * Wrap state of an EJB3 @Column annotation
 * and build the Hibernate column mapping element
 * 
 * @author Emmanuel Bernard
 */
public class Ejb3Column {
	private static final Log log = LogFactory.getLog(Ejb3Column.class);
	private final Column mappingColumn;
	private final boolean insertable;
	private final boolean updatable;
	private final String secondaryTableName;
	protected Map<String, Join> joins;
	protected PropertyHolder propertyHolder;

    public Ejb3Column(String sqlType, int length,
					  String name, boolean nullable,
					  boolean unique, boolean insertable, boolean updatable,
					  String secondaryTableName,
					  Map<String, Join> joins,
					  PropertyHolder propertyHolder, Mappings mappings) {
		log.debug("Binding column " + name + " unique " + unique);
		org.hibernate.mapping.Column hibColumn = new org.hibernate.mapping.Column();
		hibColumn.setName( mappings.getNamingStrategy().columnName( name ) );
		hibColumn.setLength(length);
		hibColumn.setNullable(nullable);
		hibColumn.setSqlType(sqlType);
		hibColumn.setUnique(unique);
		this.mappingColumn = hibColumn;
		this.insertable = insertable;
		this.updatable = updatable;
		this.secondaryTableName = secondaryTableName;
		this.joins = joins;
		this.propertyHolder = propertyHolder;
	}

	public Column getMappingColumn() {
		return mappingColumn;
	}

	public boolean isInsertable() {
		return insertable;
	}

	public boolean isUpdatable() {
		return updatable;
	}

	public void setJoins(Map<String, Join> joins) {
		this.joins = joins;
	}

	public void setPropertyHolder(PropertyHolder propertyHolder) {
		this.propertyHolder = propertyHolder;
	}

	public void linkWithValue(SimpleValue value) {
		getMappingColumn().setValue(value);
		value.addColumn( getMappingColumn() );
		value.getTable().addColumn( getMappingColumn() );
	}
	/**
	 * Find appropriate table of the column.
	 * It can come from a secondary table or from the main table of the persistent class
	 * 
	 * @return appropriate table
	 * @exception AnnotationException missing secondary table
	 */
	public Table getTable() {
		
		if ( isSecondary() ) {
			return getJoin().getTable();
		}
		else {
			return propertyHolder.getTable();
		}
	}
	
	public boolean isSecondary() {
		if (propertyHolder == null) {
			throw new AssertionFailure("Should not call getTable() on column wo persistent class defined");
		}
		if ( StringHelper.isNotEmpty(secondaryTableName) ) {
			return true;
		}
		// else {
		return false;
	}

	private Join getJoin() {
		Join join = joins.get(secondaryTableName);
		if (join == null) {
			throw new AnnotationException("Cannot find the expected secondary table: no " 
				+ secondaryTableName + " in " + propertyHolder.getClassName() );
		}
		else {
			return join;
		}
	}
	
	/**
	 * Add a property to either the persistent class or the 
	 * join stuff.
	 * @FIXME: this should *not* be here because we mix contexts,
	 * but thats the easiest way for now
	 */
	public void addPropertyToMappingContainer(Property prop) {
		if ( isSecondary() ) {
			getJoin().addProperty(prop);
		}
		else {
			propertyHolder.addProperty(prop);
		}
	}

	public void forceNotNull() {
		 mappingColumn.setNullable(false);
	}
	
	public static Ejb3Column[] buildColumnFromAnnotation(
			javax.ejb.Column ann, 
			PropertyHolder propertyHolder, 
			AnnotedElementInferredData inferredData, 
			Map<String, Join> secondaryTables,
			ExtendedMappings mappings) {
		Ejb3Column[] columns;
		javax.ejb.Column actualCol = ann;
		javax.ejb.Column[] overriddenCols = propertyHolder.getOverriddenColumn( inferredData.getPropertyName() );
		if (overriddenCols != null) {
			//check for overridden first
			if (overriddenCols.length > 1) {
				throw new AnnotationException("DependentAttribute.column().length > 1 is a non sense to me. Please report your use case to JIRA");
			}
			actualCol = overriddenCols.length == 0 ? null : overriddenCols[0];
			log.debug( "Column overridden for property " + inferredData.getPropertyName() );
		}
		if (actualCol == null) {
			columns = new Ejb3Column[1];
			columns[0] = new Ejb3Column( (String) null, 255, inferredData.getPropertyName(),
				true, false, true, true, (String) null, secondaryTables,
					propertyHolder, mappings );
		}
		else {
			String sqlType = actualCol.columnDefinition().equals("") ? null : actualCol.columnDefinition();
			String name = actualCol.name().equals("") ? inferredData.getPropertyName() : actualCol.name();
			columns = new Ejb3Column[1];
			columns[0] = new Ejb3Column(sqlType, actualCol.length(),
				name, actualCol.nullable(), actualCol.unique(),
				actualCol.insertable(), actualCol.updatable(), actualCol.secondaryTable(),
				secondaryTables, propertyHolder, mappings);
		}
		return columns;
	}
}