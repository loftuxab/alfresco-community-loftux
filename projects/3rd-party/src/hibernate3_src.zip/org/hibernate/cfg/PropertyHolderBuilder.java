//$Id: PropertyHolderBuilder.java,v 1.2 2004/12/11 14:36:11 epbernard Exp $
package org.hibernate.cfg;

import org.hibernate.mapping.PersistentClass;
import org.hibernate.mapping.Component;

import javax.ejb.Column;
import java.util.Map;

/**
 * This factory is here ot build a PropertyHolder and prevent .mapping interface adding
 *
 * @author Emmanuel Bernard
 */
public final class PropertyHolderBuilder {
	private PropertyHolderBuilder() {}

	public static PropertyHolder buildPropertyHolder(PersistentClass persistentClass) {
		return (PropertyHolder) new ClassPropertyHolder(persistentClass);
	}

	/**
	 * build a component proeprty holder
	 *
	 * @param component component to wrap
	 * @param path component path
	 * @return PropertyHolder
	 */
	public static PropertyHolder buildPropertyHolder(Component component, String path, Map<String, Column[]> columnOverride) {
		return (PropertyHolder) new ComponentPropertyHolder(component, path, columnOverride);
	}
}
