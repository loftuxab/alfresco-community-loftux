//$Id: Ejb3DiscriminatorColumn.java,v 1.1 2004/12/24 11:32:35 epbernard Exp $
package org.hibernate.cfg;

import org.hibernate.mapping.Join;
import org.hibernate.AssertionFailure;

import javax.ejb.DiscriminatorType;
import javax.ejb.DiscriminatorColumn;
import java.util.Map;

/**
 * Discriminator column
 *
 * @author Emmanuel Bernard
 */
public class Ejb3DiscriminatorColumn extends Ejb3Column {


	private static final String DEFAULT_DISCRIMINATOR_COLUMN_NAME = "TYPE";

	private String discriminatorTypeName;

	public Ejb3DiscriminatorColumn(String sqlType, int length, String name, boolean nullable, boolean unique, boolean insertable,
								   boolean updatable, String secondaryTableName, Map<String, Join> joins, PropertyHolder propertyHolder,
								   String discriminatorTypeName, Mappings mappings) {
		super(sqlType, length, name, nullable, unique, insertable, updatable, secondaryTableName, joins, propertyHolder, mappings);
		this.discriminatorTypeName = discriminatorTypeName;
	}

	public String getDiscriminatorTypeName() {
		return discriminatorTypeName;
	}

	public void setDiscriminatorTypeName(String discriminatorTypeName) {
		this.discriminatorTypeName = discriminatorTypeName;
	}

	public static Ejb3DiscriminatorColumn buildDiscriminatorColumn(DiscriminatorType type, DiscriminatorColumn discAnn, ExtendedMappings mappings) {
		String discrSqlType = null;
		String discrColumnName = DEFAULT_DISCRIMINATOR_COLUMN_NAME;
		int discrLength = 255;
		boolean discrNullable = false;
		String discrTypeName = "string";

		boolean overrideDefaultValues = discAnn != null;
		if (overrideDefaultValues) {
			discrSqlType = "".equals( discAnn.columnDefinition() ) ? null : discAnn.columnDefinition();
			discrColumnName = "".equals( discAnn.name() ) ? DEFAULT_DISCRIMINATOR_COLUMN_NAME : discAnn.name();
			discrNullable = discAnn.nullable();
			if (DiscriminatorType.CHAR.equals(type) ) {
				discrTypeName = "character";
			}
			else if (DiscriminatorType.INTEGER.equals(type) ) {
				discrTypeName = "integer";
			}
			else if (DiscriminatorType.STRING.equals(type) || type == null ) {
				//default value is DiscriminatorType.String
				discrLength = discAnn.length();
				discrTypeName = "string";
			} else {
				throw new AssertionFailure("Unknown discriminator type: " + type);
			}
		}
		Ejb3DiscriminatorColumn discriminatorColumn = new Ejb3DiscriminatorColumn(discrSqlType, discrLength, discrColumnName, discrNullable,
			false, false, false, (String) null, null, null, discrTypeName, mappings);
		return discriminatorColumn;
	}
}
