// $Id: FkSecondPass.java,v 1.1 2004/11/29 23:48:35 epbernard Exp $
package org.hibernate.cfg;

import org.hibernate.AssertionFailure;
import org.hibernate.MappingException;
import org.hibernate.mapping.ManyToOne;
import org.hibernate.mapping.Value;

import java.util.Map;

/**
 * Enable a proper set of the FK columns in respect with the id column order
 *
 * @author Emmanuel Bernard
 */
public class FkSecondPass extends SecondPass {
	private Value value;
	private Ejb3JoinColumn[] columns;

	FkSecondPass(Value value, Ejb3JoinColumn[] columns, Mappings mappings) {
		super(mappings, null);
		this.value = value;
		this.columns = columns;
	}

	void doSecondPass(java.util.Map persistentClasses, java.util.Map inheritedMetas) throws MappingException {
		secondPass(persistentClasses, inheritedMetas);
	}

	void secondPass(Map persistentClasses, Map inheritedMetas) throws MappingException {
		if (value instanceof ManyToOne) {
			AnnotationBinder.bindFkSecondPass((ManyToOne) value, columns, persistentClasses);
		}
		else {
			throw new AssertionFailure("FkSecondPass for a wrong value type: " + value.getClass().getName() );
		}
	}
}
