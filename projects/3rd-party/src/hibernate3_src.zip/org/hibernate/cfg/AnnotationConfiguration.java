// $Id: AnnotationConfiguration.java,v 1.14 2005/01/25 00:20:14 epbernard Exp $
package org.hibernate.cfg;

import java.util.*;
import java.io.File;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import org.hibernate.MappingException;
import org.hibernate.util.ReflectHelper;
import org.hibernate.mapping.Join;
import org.hibernate.mapping.Table;
import org.hibernate.mapping.Column;
import org.hibernate.mapping.UniqueKey;
import org.dom4j.Element;
import org.dom4j.Attribute;

/**
 * Add JSR 175 configuration capability.
 * For now, only programmatic configuration is available. 
 * 
 * @author Emmanuel Bernard
 */
public class AnnotationConfiguration extends Configuration {
	private static Log log = LogFactory.getLog(AnnotationConfiguration.class);
	
	private Map namedGenerators;
	private Map<String, Map<String, Join>> joins;
	private Map<Class, AnnotatedClassType> classTypes;
	private Map<String,Properties> generatorTables;
	private Map<Table, List<String[]>> tableUniqueConstraints;

	/**
	 * Read a mapping from the class annotation metadata (JSR 175).
	 * 
	 * @param persistentClass the mapped class
	 * 
	 * @return the configuration object
	 */
	public AnnotationConfiguration addAnnotatedClass(Class persistentClass) throws MappingException {
		log.info( "Mapping class using metadata: " + persistentClass.getName() );
		try {
			AnnotationBinder.bindClass( persistentClass, createExtendedMappings() );
			return this;
		}
		catch (MappingException me) {
			log.error("Could not compile the mapping annotations", me);
			throw me;
		}
	}
	
	/**
	 * Read package level metadata
	 * 
	 * @param packageName java package name
	 * @return the configuration object
	 */
	public AnnotationConfiguration addPackage(String packageName) throws MappingException {
		log.info("Mapping package " + packageName);
		try {
			AnnotationBinder.bindPackage( packageName, createExtendedMappings() );
			return this;
		}
		catch (MappingException me) {
			log.error("Could not compile the mapping annotations", me);
			throw me;
		}
	}
	
	public ExtendedMappings createExtendedMappings() {
		return new ExtendedMappings(
			classes,
			collections,
			tables,
			namedQueries,
			namedSqlQueries,
			imports,
			secondPasses,
			propertyReferences,
			namingStrategy,
			typeDefs,
		    filterDefinitions,
			namedGenerators,
			joins,
			classTypes,
            extendsQueue,
			generatorTables,
			tableUniqueConstraints
		);
	}
	protected void reset() {
		super.reset();
		namedGenerators = new HashMap();
		joins = new HashMap<String, Map<String, Join>>();
		classTypes = new HashMap<Class, AnnotatedClassType>();
		generatorTables = new HashMap<String, Properties>();
		tableUniqueConstraints = new HashMap<Table, List<String[]>>();
	}

	//TODO: consider removing several second passes and manage the order in this method
	protected void secondPassCompile() throws MappingException {
	    log.debug("processing manytoone fk mappings");

		Iterator iter = secondPasses.iterator();
		while ( iter.hasNext() ) {
			HbmBinder.SecondPass sp = (HbmBinder.SecondPass) iter.next();
			//do the second pass of fk before the others and remove them
			if (sp instanceof FkSecondPass) {
				sp.doSecondPass(classes, Collections.EMPTY_MAP); // TODO: align meta-attributes with normal bind...
				iter.remove();
			}
		}
		super.secondPassCompile();
        Iterator tables = (Iterator<Map.Entry<Table, List<String[]>>>) tableUniqueConstraints.entrySet().iterator();
		Table table;
		Map.Entry entry;
		String keyName;
		int uniqueIndexPerTable;
		while ( tables.hasNext() ) {
			entry = (Map.Entry) tables.next();
			table = (Table) entry.getKey();
			List<String[]> uniqueConstraints = (List<String[]>) entry.getValue();
			uniqueIndexPerTable = 0;
			for (String[] columnNames : uniqueConstraints) {
				keyName = "key" + uniqueIndexPerTable++;
				buildUniqueKeyFromColumnNames(columnNames, table, keyName);
			}
		}
	}

	private void buildUniqueKeyFromColumnNames(String[] columnNames, Table table, String keyName) {
		Set preparedColumnNames;
		Iterator columns;
		Column column;
		UniqueKey uc;
		preparedColumnNames = new HashSet();
		for (String columnName : columnNames) {
			preparedColumnNames.add(columnName);
		}
		columns = table.getColumnIterator();
		while ( columns.hasNext() ) {
			column = (Column) columns.next();
			if ( preparedColumnNames.contains( column.getName() ) ) {
				uc = table.getUniqueKey(keyName);
				uc.addColumn(column);
			}
		}
	}

	protected void parseMappingElement(Element subelement, String name) {
		Attribute rsrc = subelement.attribute( "resource" );
		Attribute file = subelement.attribute( "file" );
		Attribute jar = subelement.attribute( "jar" );
		Attribute pckg = subelement.attribute( "package" );
		Attribute clazz = subelement.attribute( "class" );
		if ( rsrc != null ) {
			log.debug( name + "<-" + rsrc );
			addResource( rsrc.getValue() );
		}
		else if ( jar != null ) {
			log.debug( name + "<-" + jar );
			addJar( new File( jar.getValue() ) );
		}
		else if ( file != null) {
			log.debug( name + "<-" + file );
			addFile( file.getValue() );
		}
		else if (pckg != null) {
			log.debug( name + "<-" + pckg );
			addPackage( pckg.getValue() );
		}
		else if (clazz != null) {
			log.debug( name + "<-" + clazz );
			Class loadedClass = null;
			try {
				loadedClass = ReflectHelper.classForName( clazz.getValue() );
			}
			catch (ClassNotFoundException cnf) {
				throw new MappingException("Unable to load class declared as <mapping class=\"" + clazz.getValue() + "\"/> in the configuration:", cnf);
			}
			addAnnotatedClass(loadedClass);
		}
		else {
			throw new MappingException( "<mapping> element in configuration specifies no attributes" );
		}
	}
}
