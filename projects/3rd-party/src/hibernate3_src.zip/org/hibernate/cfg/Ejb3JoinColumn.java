//$Id: Ejb3JoinColumn.java,v 1.6 2004/12/28 22:19:25 epbernard Exp $
package org.hibernate.cfg;

import java.util.Map;
import javax.ejb.JoinColumn;
import javax.ejb.InheritanceJoinColumn;

import org.hibernate.mapping.Column;
import org.hibernate.mapping.PersistentClass;
import org.hibernate.mapping.Value;
import org.hibernate.mapping.Join;

/**
 * Wrap state of an EJB3 @JoinColumn annotation
 * and build the Hibernate column mapping element
 * 
 * @author Emmanuel Bernard
 */
public class Ejb3JoinColumn extends Ejb3Column {
	private static final int DEFAULT_COLUMN_LENGTH = 255;
	
	private String referencedColumn;
	
	public Ejb3JoinColumn(String sqlType,
						  String name,
						  boolean nullable,
						  boolean unique,
						  boolean insertable,
						  boolean updatable,
						  String referencedColumn,
						  String secondaryTable,
						  Map<String, Join> joins,
						  PropertyHolder propertyHolder, Mappings mappings) {
		super(
			sqlType,
			DEFAULT_COLUMN_LENGTH,
			name,
			nullable,
			unique,
			insertable,
			updatable,
			secondaryTable,
			joins,
				propertyHolder, mappings);
		this.referencedColumn = referencedColumn;
	}

	public String getReferencedColumn() {
		return referencedColumn;
	}

	public static Ejb3JoinColumn buildJoinColumn(JoinColumn ann,
												 String defaultName,
												 Map<String, Join> joins,
												 PropertyHolder propertyHolder,
												 ExtendedMappings mappings) {
		if (ann != null) {
			String sqlType = ann.columnDefinition().equals("") ? null : ann.columnDefinition();
			String name = ann.name().equals("") ? defaultName : ann.name();
			return new Ejb3JoinColumn(sqlType,  
				name, ann.nullable(), ann.unique(), 
				ann.insertable(), ann.updatable(), 
				ann.referencedColumnName(), 
				ann.secondaryTable(),
				joins,
					propertyHolder, mappings);
		}
		else {
			return new Ejb3JoinColumn( (String) null, defaultName, 
					true, false, true, true, null, (String) null, joins,
					propertyHolder, mappings );
		}
	}
	
	/**
	 * Build an Ejb3JoinColumn from a potential annotation and
	 * the identifier it refers to
	 *  
	 * @param ann JoinColumn annotation
	 * @param identifier value explaining the identifier
	 * @param propertyHolder
	 * @param mappings mappings
	 *
	 * @return Ejb3JoinColumn
	 */
	public static Ejb3JoinColumn buildJoinColumn(JoinColumn ann,
												 Value identifier,
												 Map<String, Join> joins,
												 PropertyHolder propertyHolder, ExtendedMappings mappings) {
			
		Column col = (Column) identifier.getColumnIterator().next();
		String defaultName = col.getName();
		if (ann != null) {
			String sqlType = ann.columnDefinition().equals("") ? null : ann.columnDefinition();
			String name = ann.name().equals("") ? defaultName : ann.name();
			return new Ejb3JoinColumn(sqlType,  
				name, ann.nullable(), ann.unique(), 
				ann.insertable(), ann.updatable(), 
				ann.referencedColumnName(), 
				ann.secondaryTable(),
				joins,
					propertyHolder, mappings);
		}
		else {
			return new Ejb3JoinColumn( (String) null, defaultName, 
					true, false, true, true, null, (String) null, 
					joins, propertyHolder, mappings
				);
		}
	}

	public static Ejb3JoinColumn buildJoinColumn(InheritanceJoinColumn ann,
												 Value identifier,
												 Map<String, Join> joins,
												 PropertyHolder propertyHolder, ExtendedMappings mappings) {

		Column col = (Column) identifier.getColumnIterator().next();
		String defaultName = col.getName();
		if (ann != null) {
			String sqlType = ann.columnDefinition().equals("") ? null : ann.columnDefinition();
			String name = ann.name().equals("") ? defaultName : ann.name();
			return new Ejb3JoinColumn(sqlType,
				name, false, false,
				true, true,
				ann.referencedColumnName(),
				null, joins,
				propertyHolder, mappings);
		}
		else {
			return new Ejb3JoinColumn( (String) null, defaultName,
					false, false, true, true, null, (String) null,
					joins, propertyHolder, mappings
				);
		}
	}
	/**
	 * Override persistent class on oneToMany Cases for late settings
	 */
	public void setPersistentClass(PersistentClass persistentClass) {
		this.propertyHolder = PropertyHolderBuilder.buildPropertyHolder(persistentClass);
	}
}