//$Id: ClassPropertyHolder.java,v 1.3 2004/12/24 15:07:24 epbernard Exp $
package org.hibernate.cfg;

import org.hibernate.mapping.Table;
import org.hibernate.mapping.PersistentClass;
import org.hibernate.mapping.Property;
import org.hibernate.mapping.KeyValue;

import javax.ejb.Column;

/**
 * @author Emmanuel Bernard
 */
public class ClassPropertyHolder implements PropertyHolder {
	PersistentClass persistentClass;
	public ClassPropertyHolder(PersistentClass persistentClass) {
		this.persistentClass = persistentClass;
	}

	public String getPath() {
		return persistentClass.getEntityName();
	}

	public Column[] getOverriddenColumn(String propertyName) {
		return null;
	}

	public String getEntityName() {
		return persistentClass.getEntityName();
	}

	public void addProperty(Property prop) {
		persistentClass.addProperty(prop);
	}
	
	public String getClassName() {
		return persistentClass.getClassName();
	}

	public Table getTable() {
		return persistentClass.getTable();
	}

	public boolean isComponent() {
		return false;
	}

	public PersistentClass getPersistentClass() {
		return persistentClass;
	}

	public KeyValue getIdentifier() {
		return persistentClass.getIdentifier();
	}
}
