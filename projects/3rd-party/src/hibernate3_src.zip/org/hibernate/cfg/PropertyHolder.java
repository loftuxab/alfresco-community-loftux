package org.hibernate.cfg;

import org.hibernate.mapping.Table;
import org.hibernate.mapping.Property;
import org.hibernate.mapping.PersistentClass;
import org.hibernate.mapping.KeyValue;

import javax.ejb.Column;

/**
 * Property holder abstract property containers from their direct implementation
 *
 * @author Emmanuel Bernard
 */
public interface PropertyHolder {
	String getClassName();
	Table getTable();
	void addProperty(Property prop);
	KeyValue getIdentifier();
	PersistentClass getPersistentClass();
	boolean isComponent();
	String getPath();
	/**
	 * return null if the column is not overridden, or an array of column if true
	 */
	Column[] getOverriddenColumn(String propertyName);

	String getEntityName();
}
