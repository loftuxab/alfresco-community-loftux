//$Id: AbstractEventListener.java,v 1.6 2004/08/28 08:38:24 oneovthafew Exp $
package org.hibernate.event;

import java.io.Serializable;


/**
 * Defines a convenience base class for session event listeners.
 *
 * @author Steve Ebersole
 */
public abstract class AbstractEventListener implements Serializable {

}
