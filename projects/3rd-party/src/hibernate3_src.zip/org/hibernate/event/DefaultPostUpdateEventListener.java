//$Id: DefaultPostUpdateEventListener.java,v 1.2 2004/12/22 18:11:27 oneovthafew Exp $
package org.hibernate.event;

/**
 * Default implementation is a noop.
 * 
 * @author Gavin King
 */
public class DefaultPostUpdateEventListener extends AbstractEventListener implements PostUpdateEventListener {

	public void onPostUpdate(PostUpdateEvent event) {}

}
