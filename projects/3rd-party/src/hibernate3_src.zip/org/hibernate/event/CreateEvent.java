//$Id: CreateEvent.java,v 1.1 2004/09/05 05:04:17 oneovthafew Exp $
package org.hibernate.event;


/** 
 * An event class for create()
 *
 * @author Gavin King
 */
public class CreateEvent extends AbstractEvent {

	private Object object;
	private String entityName;

	public CreateEvent(String entityName, Object original, SessionEventSource source) {
		this(original, source);
		this.entityName = entityName;
	}

	public CreateEvent(Object object, SessionEventSource source) {
		super(source);
		if ( object == null ) {
			throw new IllegalArgumentException(
					"attempt to create create event with null entity"
			);
		}
		this.object = object;
	}

	public Object getObject() {
		return object;
	}

	public void setObject(Object object) {
		this.object = object;
	}

	public String getEntityName() {
		return entityName;
	}

	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}

}
