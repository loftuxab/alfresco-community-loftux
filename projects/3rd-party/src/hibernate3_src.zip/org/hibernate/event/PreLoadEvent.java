//$Id: PreLoadEvent.java,v 1.1 2004/12/19 20:15:13 oneovthafew Exp $
package org.hibernate.event;

import java.io.Serializable;

import org.hibernate.persister.EntityPersister;

/**
 * Called before injecting property values into a newly 
 * loaded entity instance.
 *
 * @author Gavin King
 */
public class PreLoadEvent extends AbstractEvent {
	private Object entity;
	private Object[] state;
	private Serializable id;
	private EntityPersister persister;

	public PreLoadEvent(
		final Object entity, 
		final Object[] state, 
		final Serializable id, 
		final EntityPersister persister, 
		final SessionEventSource source
	) {
		super( source );
		this.entity = entity;
		this.state = state;
		this.id = id;
		this.persister = persister;
	}

	public Object getEntity() {
		return entity;
	}
	
	public Serializable getId() {
		return id;
	}
	
	public EntityPersister getPersister() {
		return persister;
	}
	
	public Object[] getState() {
		return state;
	}
}
