//$Id: DirtyCheckEvent.java,v 1.3 2004/08/28 08:38:24 oneovthafew Exp $
package org.hibernate.event;

/** Defines an event class for the dirty-checking of a session.
 *
 * @author Steve Ebersole
 */
public class DirtyCheckEvent extends FlushEvent {

	public DirtyCheckEvent(SessionEventSource source) {
		super(source);
	}

}
