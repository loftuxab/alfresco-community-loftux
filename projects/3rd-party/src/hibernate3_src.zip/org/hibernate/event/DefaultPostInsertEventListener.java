//$Id: DefaultPostInsertEventListener.java,v 1.2 2004/12/22 18:11:27 oneovthafew Exp $
package org.hibernate.event;

/**
 * Default implementation is a noop.
 * 
 * @author Gavin King
 */
public class DefaultPostInsertEventListener extends AbstractEventListener implements PostInsertEventListener {

	public void onPostInsert(PostInsertEvent event) {}

}
