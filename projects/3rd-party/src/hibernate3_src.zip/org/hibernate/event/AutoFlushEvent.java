///$Id: AutoFlushEvent.java,v 1.3 2004/08/28 08:38:24 oneovthafew Exp $
package org.hibernate.event;

import java.util.Set;


/** Defines an event class for the auto-flushing of a session.
 *
 * @author Steve Ebersole
 */
public class AutoFlushEvent extends FlushEvent {

	private Set querySpaces;

	public AutoFlushEvent(Set querySpaces, SessionEventSource source) {
		super(source);
		this.querySpaces = querySpaces;
	}

	public Set getQuerySpaces() {
		return querySpaces;
	}

	public void setQuerySpaces(Set querySpaces) {
		this.querySpaces = querySpaces;
	}
}
