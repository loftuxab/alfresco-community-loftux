//$Id: WrapVisitor.java,v 1.12 2005/02/01 13:03:28 oneovthafew Exp $
package org.hibernate.event;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.HibernateException;
import org.hibernate.collection.PersistentArrayHolder;
import org.hibernate.collection.CollectionPersister;
import org.hibernate.collection.PersistentCollection;
import org.hibernate.engine.PersistenceContext;
import org.hibernate.persister.EntityPersister;
import org.hibernate.type.AbstractComponentType;
import org.hibernate.type.CollectionType;
import org.hibernate.type.Type;

/**
 * Wrap collections in a Hibernate collection
 * wrapper.
 * @author Gavin King
 */
public class WrapVisitor extends ProxyVisitor {

	private static final Log log = LogFactory.getLog(WrapVisitor.class);

	boolean substitute = false;

	boolean isSubstitutionRequired() {
		return substitute;
	}

	WrapVisitor(SessionEventSource session) {
		super(session);
	}

	Object processCollection(Object collection, CollectionType collectionType)
	throws HibernateException {

		if ( collection!=null && (collection instanceof PersistentCollection) ) {

			final SessionEventSource session = getSession();
			PersistentCollection coll = (PersistentCollection) collection;
			if ( coll.setCurrentSession(session) ) {
				reattachCollection( coll, coll.getCollectionSnapshot() );
			}
			return null;

		}
		else {
			return processArrayOrNewCollection(collection, collectionType);
		}

	}

	final Object processArrayOrNewCollection(Object collection, CollectionType collectionType)
	throws HibernateException {

		final SessionEventSource session = getSession();

		if (collection==null) {
			//do nothing
			return null;
		}
		else {
			CollectionPersister persister = session.getFactory().getCollectionPersister( collectionType.getRole() );

			final PersistenceContext persistenceContext = session.getPersistenceContext();
			if ( collectionType.isArrayType() ) {

				PersistentArrayHolder ah = persistenceContext.getArrayHolder(collection);
				if (ah==null) {
					ah = new PersistentArrayHolder(session, collection);
					persistenceContext.addNewCollection(ah, persister);
					persistenceContext.addArrayHolder(ah);
				}
				return null;
			}
			else {

				PersistentCollection persistentCollection = collectionType.wrap(session, collection);
				persistenceContext.addNewCollection(persistentCollection, persister);

				if ( log.isTraceEnabled() ) log.trace( "Wrapped collection in role: " + collectionType.getRole() );

				return persistentCollection; //Force a substitution!

			}

		}

	}

	void processValues(Object[] values, Type[] types) throws HibernateException {
		for ( int i=0; i<types.length; i++ ) {
			if ( includeProperty(values, i) ) {
				Object result = processValue( values[i], types[i] );
				if (result!=null) {
					substitute = true;
					values[i] = result;
				}
			}
		}
	}

	Object processComponent(Object component, AbstractComponentType componentType)
	throws HibernateException {

		if (component!=null) {
			Object[] values = componentType.getPropertyValues( component, getSession() );
			Type[] types = componentType.getSubtypes();
			boolean substituteComponent = false;
			for ( int i=0; i<types.length; i++ ) {
				Object result = processValue( values[i], types[i] );
				if (result!=null) {
					values[i] = result;
					substituteComponent = true;
				}
			}
			if (substituteComponent) {
				componentType.setPropertyValues(component, values);
			}
		}

		return null;
	}

	void process(Object object, EntityPersister persister) throws HibernateException {
		Object[] values = persister.getPropertyValues(object);
		Type[] types = persister.getPropertyTypes();
		processValues(values, types);
		if ( isSubstitutionRequired() ) persister.setPropertyValues(object, values);
	}

}
