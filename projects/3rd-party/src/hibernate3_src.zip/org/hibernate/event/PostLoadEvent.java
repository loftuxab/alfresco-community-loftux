//$Id: PostLoadEvent.java,v 1.5 2004/12/19 20:56:53 oneovthafew Exp $
package org.hibernate.event;

import java.io.Serializable;

import org.hibernate.persister.EntityPersister;

/**
 * Occurs after an an entity instance is fully loaded.
 *
 * @author <a href="mailto:kabir.khan@jboss.org">Kabir Khan</a>, Gavin King
 */
public class PostLoadEvent extends AbstractEvent {
	private Object entity;
	private Serializable id;
	private EntityPersister persister;

	public PostLoadEvent(Object entity, Serializable id, EntityPersister persister, SessionEventSource source) {
		super( source );
		this.entity = entity;
		this.id = id;
		this.persister = persister;
	}

	public Object getEntity() {
		return entity;
	}
	
	public EntityPersister getPersister() {
		return persister;
	}
	
	public Serializable getId() {
		return id;
	}
}
