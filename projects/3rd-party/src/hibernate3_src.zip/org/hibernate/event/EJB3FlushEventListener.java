//$Id: EJB3FlushEventListener.java,v 1.2 2005/01/13 15:54:06 oneovthafew Exp $
package org.hibernate.event;

import org.hibernate.engine.Cascades;
import org.hibernate.util.IdentityMap;

/**
 * In EJB3, it is the create operation that is cascaded to unmanaged
 * ebtities at flush time (instead of the save-update operation in 
 * Hibernate).
 * 
 * @author Gavin King
 */
public class EJB3FlushEventListener extends DefaultFlushEventListener {

	protected Cascades.CascadingAction getCascadingAction() {
		return Cascades.ACTION_CREATE;
	}

	protected Object getAnything() { return IdentityMap.instantiate(10); }

}
