// $Id: DefaultCreateEventListener.java,v 1.8 2005/02/01 13:03:28 oneovthafew Exp $
package org.hibernate.event;

import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.HibernateException;
import org.hibernate.ObjectDeletedException;
import org.hibernate.PersistentObjectException;
import org.hibernate.engine.Cascades;
import org.hibernate.engine.Cascades.CascadingAction;
import org.hibernate.persister.EntityPersister;
import org.hibernate.proxy.HibernateProxy;
import org.hibernate.proxy.LazyInitializer;
import org.hibernate.util.IdentityMap;

/**
 * Defines the default create event listener used by hibernate for creating
 * transient entities in response to generated create events.
 *
 * @author Gavin King
 */
public class DefaultCreateEventListener extends AbstractSaveEventListener implements CreateEventListener {

	private static final Log log = LogFactory.getLog(DefaultCreateEventListener.class);

	/** 
	 * Handle the given create event.
	 *
	 * @param event The create event to be handled.
	 * @throws HibernateException
	 */
	public void onCreate(CreateEvent event) throws HibernateException {
		onCreate( event, IdentityMap.instantiate(10) );
	}
		

	/** 
	 * Handle the given create event.
	 *
	 * @param event The create event to be handled.
	 * @throws HibernateException
	 */
	public void onCreate(CreateEvent event, Map createCache) throws HibernateException {
			
		final SessionEventSource source = event.getSource();
		final Object object = event.getObject();
		
		final Object entity;
		if (object instanceof HibernateProxy) {
			LazyInitializer li = ( (HibernateProxy) object ).getHibernateLazyInitializer();
			if ( li.isUninitialized() ) {
				if ( li.getSession()==this ) {
					return; //NOTE EARLY EXIT!
				}
				else {
					throw new PersistentObjectException("uninitialized proxy passed to create()");
				}
			}
			entity = li.getImplementation();
		}
		else {
			entity = object;
		}
		
		int entityState = getEntityState( 
				entity, 
				event.getEntityName(), 
				source.getPersistenceContext().getEntry(entity), 
				source 
		);
		
		switch (entityState) {
			case DETACHED: 
				throw new PersistentObjectException( "detached entity passed to create: " + event.getEntityName() );
			case PERSISTENT:
				entityIsPersistent(event, createCache);
				break;
			case TRANSIENT:
				entityIsTransient(event, createCache);
				break;
			default: 
				throw new ObjectDeletedException( "deleted entity passed to create", null, event.getEntityName() );
		}

	}
		
	protected void entityIsPersistent(CreateEvent event, Map createCache) {
		log.trace("ignoring persistent instance");
		final SessionEventSource source = event.getSource();
		
		//TODO: check that entry.getIdentifier().equals(requestedId)
		
		final Object entity = source.getPersistenceContext().unproxy( event.getObject() );
		final EntityPersister persister = source.getEntityPersister( event.getEntityName(), entity );
		
		if ( createCache.put(entity, entity)==null ) {
			//TODO: merge into one method!
			cascadeBeforeSave(source, persister, entity, createCache);
			cascadeAfterSave(source, persister, entity, createCache);
		}

	}
	
	/** 
	 * Handle the given create event.
	 *
	 * @param event The save event to be handled.
	 * @throws HibernateException
	 */
	protected void entityIsTransient(CreateEvent event, Map createCache) throws HibernateException {
		
		log.trace("saving transient instance");

		final SessionEventSource source = event.getSource();
		
		final Object entity = source.getPersistenceContext().unproxy( event.getObject() );
		
		if ( createCache.put(entity, entity)==null ) {
			saveWithGeneratedId( entity, event.getEntityName(), createCache, source );
		}

	}

	protected CascadingAction getCascadeAction() {
		return Cascades.ACTION_CREATE;
	}
	
	protected Boolean getAssumedUnsaved() {
		return Boolean.TRUE;
	}

}
