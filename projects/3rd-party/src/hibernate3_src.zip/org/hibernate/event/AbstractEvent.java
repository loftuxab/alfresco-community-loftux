//$Id: AbstractEvent.java,v 1.1 2004/07/20 13:45:07 steveebersole Exp $
package org.hibernate.event;

import java.io.Serializable;


/**
 * Defines a base class for Session generated events.
 *
 * @author Steve Ebersole
 */
public abstract class AbstractEvent implements Serializable {

	private final SessionEventSource source;

    /**
     * Constructs an event from the given event session.
     *
     * @param source The session event source.
     */
	public AbstractEvent(SessionEventSource source) {
		this.source = source;
	}

    /**
     * Returns the session event source for this event.  This is the underlying
     * session from which this event was generated.
     *
     * @return The session event source.
     */
	public final SessionEventSource getSource() {
		return source;
	}

}
