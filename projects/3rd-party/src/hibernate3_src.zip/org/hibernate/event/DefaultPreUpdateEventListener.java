//$Id: DefaultPreUpdateEventListener.java,v 1.1 2004/12/22 18:11:28 oneovthafew Exp $
package org.hibernate.event;

/**
 * @author Gavin King
 */
public class DefaultPreUpdateEventListener 
	extends AbstractEventListener 
	implements PreUpdateEventListener {

	public boolean onPreUpdate(PreUpdateEvent event) {
		return false;
	}
}
