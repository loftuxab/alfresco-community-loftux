//$Id: DefaultPreInsertEventListener.java,v 1.1 2004/12/22 18:11:28 oneovthafew Exp $
package org.hibernate.event;

/**
 * @author Gavin King
 */
public class DefaultPreInsertEventListener 
	extends AbstractEventListener 
	implements PreInsertEventListener {

	public boolean onPreInsert(PreInsertEvent event) {
		return false;
	}
}
