//$Id: EvictEvent.java,v 1.2 2004/08/08 11:24:54 oneovthafew Exp $
package org.hibernate.event;

/**
 *  Defines an event class for the evicting of an entity.
 *
 * @author Steve Ebersole
 */
public class EvictEvent extends AbstractEvent {

	private Object object;

	public EvictEvent(Object object, SessionEventSource source) {
		super(source);
		this.object = object;
	}

	public Object getObject() {
		return object;
	}

	public void setObject(Object object) {
		this.object = object;
	}
}
