//$Id: FlushEvent.java,v 1.3 2004/08/28 08:38:24 oneovthafew Exp $
package org.hibernate.event;

/** 
 * Defines an event class for the flushing of a session.
 *
 * @author Steve Ebersole
 */
public class FlushEvent extends AbstractEvent {
	
	public FlushEvent(SessionEventSource source) {
		super(source);
	}

}
