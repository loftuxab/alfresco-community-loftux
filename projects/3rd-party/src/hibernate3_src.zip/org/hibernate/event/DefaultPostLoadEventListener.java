//$Id: DefaultPostLoadEventListener.java,v 1.5 2004/12/22 18:11:27 oneovthafew Exp $
package org.hibernate.event;

import org.hibernate.classic.Lifecycle;

/**
 * Default implementation is a noop.
 *
 * @author <a href="mailto:kabir.khan@jboss.org">Kabir Khan</a>
 */
public class DefaultPostLoadEventListener extends AbstractEventListener implements PostLoadEventListener {
	
	public void onPostLoad(PostLoadEvent event) {
		if ( event.getPersister().implementsLifecycle() ) {
			//log.debug( "calling onLoad()" );
			( ( Lifecycle ) event.getEntity() ).onLoad( event.getSource(), event.getId() );
		}

	}
}
