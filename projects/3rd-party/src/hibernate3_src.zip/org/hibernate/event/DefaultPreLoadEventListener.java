//$Id: DefaultPreLoadEventListener.java,v 1.2 2004/12/22 18:11:28 oneovthafew Exp $
package org.hibernate.event;

import org.hibernate.persister.EntityPersister;

/**
 * Called before injecting property values into a newly 
 * loaded entity instance.
 *
 * @author Gavin King
 */
public class DefaultPreLoadEventListener extends AbstractEventListener implements PreLoadEventListener {
	public void onPreLoad(PreLoadEvent event) {
		EntityPersister persister = event.getPersister();
		event.getSource()
			.getInterceptor()
			.onLoad( 
					event.getEntity(), 
					event.getId(), 
					event.getState(), 
					persister.getPropertyNames(), 
					persister.getPropertyTypes() 
			);
	}
}
