//$Id: DefaultDirtyCheckEventListener.java,v 1.4 2004/12/17 15:10:03 steveebersole Exp $
package org.hibernate.event;

import org.hibernate.HibernateException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Defines the default dirty-check event listener used by hibernate for
 * checking the session for dirtiness in response to generated dirty-check
 * events.
 *
 * @author Steve Ebersole
 */
public class DefaultDirtyCheckEventListener extends AbstractFlushingEventListener implements DirtyCheckEventListener {

	private static final Log log = LogFactory.getLog(DefaultDirtyCheckEventListener.class);

    /** Handle the given dirty-check event.
     *
     * @param event The dirty-check event to be handled.
     * @throws HibernateException
     */
	public boolean onDirtyCheck(DirtyCheckEvent event) throws HibernateException {

		boolean wasNeeded = false;
		int oldSize = event.getSource().getActionQueue().numberOfCollectionRemovals();

		try {
			flushEverythingToExecutions(event);
			wasNeeded = event.getSource().getActionQueue().hasAnyQueuedActions();
			log.debug( wasNeeded ? "session dirty" : "session not dirty" );
			return wasNeeded;
		}
		finally {
			event.getSource().getActionQueue().clearFromFlushNeededCheck( oldSize );
		}
	}
}
