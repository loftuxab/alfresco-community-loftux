//$Id: SessionEventSource.java,v 1.21 2005/02/01 13:03:28 oneovthafew Exp $
package org.hibernate.event;

import org.hibernate.engine.SessionImplementor;


/**
 * Interface for callbacks into the session from event listeners.
 *
 * @author Steve Ebersole
 */
public interface SessionEventSource extends SessionImplementor {






}
