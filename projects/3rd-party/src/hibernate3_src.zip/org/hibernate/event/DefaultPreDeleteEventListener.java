//$Id: DefaultPreDeleteEventListener.java,v 1.1 2004/12/22 18:11:27 oneovthafew Exp $
package org.hibernate.event;

/**
 * @author Gavin King
 */
public class DefaultPreDeleteEventListener 
	extends AbstractEventListener 
	implements PreDeleteEventListener {

	public boolean onPreDelete(PreDeleteEvent event) {
		return false;
	}
}
