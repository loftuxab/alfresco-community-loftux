//$Id: FlushVisitor.java,v 1.6 2005/02/01 13:03:28 oneovthafew Exp $
package org.hibernate.event;

import org.hibernate.HibernateException;
import org.hibernate.collection.PersistentCollection;
import org.hibernate.engine.Collections;
import org.hibernate.type.CollectionType;

/**
 * Process collections reachable from an entity. This
 * visitor assumes that wrap was already performed for
 * the entity.
 *
 * @author Gavin King
 */
public class FlushVisitor extends AbstractVisitor {
	
	private Object owner;

	Object processCollection(Object collection, CollectionType type)
	throws HibernateException {

		if (collection!=null) {
			final PersistentCollection coll;
			if ( type.isArrayType() ) {
				coll = getSession().getPersistenceContext().getArrayHolder(collection);
			}
			else {
				coll = (PersistentCollection) collection;
			}

			Collections.updateReachableCollection( coll, type, owner, getSession() );
		}

		return null;

	}

	FlushVisitor(SessionEventSource session, Object owner) {
		super(session);
		this.owner = owner;
	}

}
