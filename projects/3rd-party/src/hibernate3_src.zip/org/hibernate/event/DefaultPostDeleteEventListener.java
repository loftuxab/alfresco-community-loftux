//$Id: DefaultPostDeleteEventListener.java,v 1.5 2004/12/22 18:11:27 oneovthafew Exp $
package org.hibernate.event;

/**
 * Default implementation is a noop.
 * 
 * @author Gavin King
 */
public class DefaultPostDeleteEventListener extends AbstractEventListener implements PostDeleteEventListener {

	public void onPostDelete(PostDeleteEvent event) {}

}
