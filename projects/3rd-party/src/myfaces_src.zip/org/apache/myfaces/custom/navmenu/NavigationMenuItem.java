/*
 * Copyright 2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.myfaces.custom.navmenu;

import javax.faces.model.SelectItem;

/**
 * @author Thomas Spiegl (latest modification by $Author: oros $)
 * @version $Revision: 1.6 $ $Date: 2004/12/13 23:14:38 $
 *          $Log: NavigationMenuItem.java,v $
 *          Revision 1.6  2004/12/13 23:14:38  oros
 *          fix #1044663: handle enabledOnUserRole/visibleOnUserRole, disabled menu items are rendered with null actions
 *
 *          Revision 1.5  2004/10/13 11:50:57  matze
 *          renamed packages to org.apache
 *
 *          Revision 1.4  2004/07/05 08:32:41  royalts
 *          changed constructor signature
 *
 *          Revision 1.3  2004/07/05 08:28:25  royalts
 *          added example for <x:navigationMenuItems>
 *
 *          Revision 1.2  2004/07/01 21:53:07  mwessendorf
 *          ASF switch
 *
 *          Revision 1.1  2004/06/23 13:44:31  royalts
 *          no message
 *
 */
public class NavigationMenuItem
    extends SelectItem
{
    private String _icon;
    private String _action;
    boolean _split;
    private boolean rendered = true;
    private NavigationMenuItem[] _navigationMenuItems = null;

    public NavigationMenuItem(String label, String action, String icon, boolean split)
    {
        super(label, label);
        _action = action;
        _icon = icon;
        _split = split;
    }

    public NavigationMenuItem(Object value,
                              String label,
                              String description,
                              boolean disabled,
                              String action,
                              String icon,
                              boolean split)
    {
        super(value, label, description, disabled);
        _action = action;
        _icon = icon;
        _split = split;
    }

    public NavigationMenuItem(Object value,
                              String label,
                              String description,
                              boolean disabled,
                              boolean rendered,
                              String action,
                              String icon,
                              boolean split)
    {
        this(value, label, description, disabled, action, icon, split);
        this.rendered = rendered;
    }


    public boolean isRendered()
    {
        return rendered;
    }


    public String getAction()
    {
        return _action;
    }

    public void setAction(String action)
    {
        _action = action;
    }

    public boolean isSplit()
    {
        return _split;
    }

    public void setSplit(boolean split)
    {
        _split = split;
    }

    public String getIcon()
    {
        return _icon;
    }

    public void setIcon(String icon)
    {
        _icon = icon;
    }

    public NavigationMenuItem[] getNavigationMenuItems()
    {
        return _navigationMenuItems;
    }

    public void setNavigationMenuItems(NavigationMenuItem[] navigationMenuItems)
    {
        _navigationMenuItems = navigationMenuItems;
    }
}
