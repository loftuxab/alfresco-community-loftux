/*
 * Copyright 2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.myfaces.custom.selectOneCountry;

import org.apache.myfaces.renderkit.html.ext.HtmlMenuRenderer;

/**
 * @author Sylvain Vieujot (latest modification by $Author: svieujot $)
 * @version $Revision: 1.1 $ $Date: 2005/02/09 13:05:20 $
 * $Log: SelectOneCountryRenderer.java,v $
 * Revision 1.1  2005/02/09 13:05:20  svieujot
 * new x:selectOneCountry component
 *
 */
public class SelectOneCountryRenderer extends HtmlMenuRenderer {
}