package org.apache.myfaces.renderkit.html.ext;

/**
 * @author Manfred Geiler (latest modification by $Author: matze $)
 * @version $Revision: 1.2 $ $Date: 2004/10/13 11:50:59 $
 */

import org.apache.myfaces.renderkit.html.HtmlTableRendererBase;

public class HtmlTableRenderer
        extends HtmlTableRendererBase
{
    //private static final Log log = LogFactory.getLog(HtmlTableRenderer.class);
}
