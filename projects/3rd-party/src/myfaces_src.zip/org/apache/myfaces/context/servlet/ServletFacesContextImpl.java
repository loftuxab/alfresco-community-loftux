/*
 * Copyright 2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.myfaces.context.servlet;

import org.apache.myfaces.util.NullIterator;

import javax.faces.FactoryFinder;
import javax.faces.application.Application;
import javax.faces.application.ApplicationFactory;
import javax.faces.application.FacesMessage;
import javax.faces.component.UIViewRoot;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.context.ResponseStream;
import javax.faces.context.ResponseWriter;
import javax.faces.render.RenderKit;
import javax.faces.render.RenderKitFactory;
import javax.servlet.ServletContext;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import java.util.*;
import javax.portlet.PortletContext;
import javax.portlet.PortletRequest;
import javax.portlet.PortletResponse;
import org.apache.myfaces.context.ReleaseableExternalContext;
import org.apache.myfaces.context.portlet.PortletExternalContextImpl;


/**
 * @author Manfred Geiler (latest modification by $Author: matzew $)
 * @author Anton Koinov
 * @version $Revision: 1.18 $ $Date: 2005/01/26 17:03:11 $
 * $Log: ServletFacesContextImpl.java,v $
 * Revision 1.18  2005/01/26 17:03:11  matzew
 * MYFACES-86. portlet support provided by Stan Silver (JBoss Group)
 *
 * Revision 1.17  2004/10/13 11:51:00  matze
 * renamed packages to org.apache
 *
 * Revision 1.16  2004/07/18 21:44:40  o_rossmueller
 * fix #992629: implemented FacesContext.getRenderKit()
 *
 * Revision 1.15  2004/07/01 22:05:04  mwessendorf
 * ASF switch
 *
 * Revision 1.14  2004/04/16 13:56:59  manolito
 * Bug #922317 - ClassCastException in action handler after adding message
 *
 * Revision 1.13  2004/03/31 11:58:38  manolito
 * custom component refactoring
 *
 */
public class ServletFacesContextImpl
    extends FacesContext
{
    //~ Static fields/initializers -----------------------------------------------------------------

    protected static final Object NULL_DUMMY        = new Object();

    //~ Instance fields ----------------------------------------------------------------------------

    List                                _messageClientIds = null;
    private List                        _messages         = null;
    private Application                 _application;
    private ReleaseableExternalContext  _externalContext;
    private ResponseStream              _responseStream   = null;
    private ResponseWriter              _responseWriter   = null;
    private FacesMessage.Severity       _maximumSeverity  = FacesMessage.SEVERITY_INFO;
    private UIViewRoot                  _viewRoot;
    private boolean                     _renderResponse   = false;
    private boolean                     _responseComplete = false;
    private RenderKitFactory            _renderKitFactory;

    //~ Constructors -------------------------------------------------------------------------------

    // TODO: FIXME: the name of this class should be changed.
    public ServletFacesContextImpl(PortletContext portletContext,
                                   PortletRequest portletRequest,
                                   PortletResponse portletResponse) 
    {
        this(new PortletExternalContextImpl(portletContext,
                                            portletRequest,
                                            portletResponse));
    }
    
    public ServletFacesContextImpl(ServletContext servletContext,
                                   ServletRequest servletRequest,
                                   ServletResponse servletResponse)
    {
        this(new ServletExternalContextImpl(servletContext, 
                                            servletRequest,
                                            servletResponse));
    }
        
    private ServletFacesContextImpl(ReleaseableExternalContext externalContext)
    {
        _application = ((ApplicationFactory)FactoryFinder.getFactory(FactoryFinder.APPLICATION_FACTORY))
                            .getApplication();
        _renderKitFactory = (RenderKitFactory) FactoryFinder.getFactory(FactoryFinder.RENDER_KIT_FACTORY);
        _externalContext = externalContext;
        FacesContext.setCurrentInstance(this);  //protected method, therefore must be called from here
    }

    //~ Methods ------------------------------------------------------------------------------------

    public ExternalContext getExternalContext()
    {
        return (ExternalContext)_externalContext;
    }

    public FacesMessage.Severity getMaximumSeverity()
    {
        return _maximumSeverity;
    }

    public Iterator getMessages()
    {
        return (_messages != null) ? _messages.iterator() : Collections.EMPTY_LIST.iterator();
    }

    public Application getApplication()
    {
        return _application;
    }

    public Iterator getClientIdsWithMessages()
    {
        if (_messages == null || _messages.isEmpty())
        {
            return NullIterator.instance();
        }

        return new Iterator()
            {
                private int _next;
                boolean     _nextFound;

                public void remove()
                {
                    throw new UnsupportedOperationException(this.getClass().getName() + " UnsupportedOperationException");
                }

                public boolean hasNext()
                {
                    if (!_nextFound)
                    {
                        for (int len = _messageClientIds.size(); _next < len; _next++)
                        {
                            if (_messageClientIds.get(_next) != NULL_DUMMY)
                            {
                                _nextFound = true;
                                break;
                            }
                        }
                    }
                    return _nextFound;
                }

                public Object next()
                {
                    if (hasNext())
                    {
                        _nextFound = false;
                        return _messageClientIds.get(_next++);
                    }

                    throw new NoSuchElementException();
                }
            };
    }

    public Iterator getMessages(String clientId)
    {
        if (_messages == null)
        {
            return NullIterator.instance();
        }

        List lst = new ArrayList();
        for (int i = 0; i < _messages.size(); i++)
        {
            Object savedClientId = _messageClientIds.get(i);
            if (clientId == null)
            {
                if (savedClientId == NULL_DUMMY) lst.add(_messages.get(i));
            }
            else
            {
                if (clientId.equals(savedClientId)) lst.add(_messages.get(i));
            }
        }
        return lst.iterator();
    }

    public RenderKit getRenderKit()
    {
         if (getViewRoot() == null)
         {
             return null;
         }

         String renderKitId = getViewRoot().getRenderKitId();
        
         if (renderKitId == null)
         {
             return null;
         }

         return _renderKitFactory.getRenderKit(this, renderKitId);
    }

    public boolean getRenderResponse()
    {
        return _renderResponse;
    }

    public boolean getResponseComplete()
    {
        return _responseComplete;
    }

    public void setResponseStream(ResponseStream responseStream)
    {
        if (responseStream == null)
        {
            throw new NullPointerException("responseStream");
        }
        _responseStream = responseStream;
    }

    public ResponseStream getResponseStream()
    {
        return _responseStream;
    }

    public void setResponseWriter(ResponseWriter responseWriter)
    {
        if (responseWriter == null)
        {
            throw new NullPointerException("responseWriter");
        }
        _responseWriter = responseWriter;
    }

    public ResponseWriter getResponseWriter()
    {
        return _responseWriter;
    }

    public void setViewRoot(UIViewRoot viewRoot)
    {
        if (viewRoot == null)
        {
            throw new NullPointerException("viewRoot");
        }
        _viewRoot = viewRoot;
    }

    public UIViewRoot getViewRoot()
    {
        return _viewRoot;
    }

    public void addMessage(String clientId, FacesMessage message)
    {
        if (message == null)
        {
            throw new NullPointerException("message");
        }

        if (_messages == null)
        {
            _messages             = new ArrayList();
            _messageClientIds     = new ArrayList();
        }
        _messages.add(message);
        _messageClientIds.add((clientId != null) ? clientId : NULL_DUMMY);
        FacesMessage.Severity serSeverity =  message.getSeverity();
        if (serSeverity != null && serSeverity.compareTo(_maximumSeverity) > 0)
        {
            _maximumSeverity = message.getSeverity();
        }
    }

    public void release()
    {
        if (_externalContext != null)
        {
            _externalContext.release();
            _externalContext = null;
        }

        _messageClientIds     = null;
        _messages             = null;
        _application          = null;
        _responseStream       = null;
        _responseWriter       = null;
        _viewRoot             = null;

        FacesContext.setCurrentInstance(null);
    }

    public void renderResponse()
    {
        _renderResponse = true;
    }

    public void responseComplete()
    {
        _responseComplete = true;
    }
    
    // Portlet need to do this to change from ActionRequest/Response to
    // RenderRequest/Response
    public void setExternalContext(ReleaseableExternalContext extContext)
    {
        _externalContext = extContext;
        FacesContext.setCurrentInstance(this); //TODO: figure out if I really need to do this
    }
}
