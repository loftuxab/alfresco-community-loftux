======================Alfresco Language Pack======================

Release: 1.0

For locale: fr_CA  (Canadian French)

==============================
Content of this Language Pack
==============================

action-config_fr_CA.properties
action-service_fr_CA.properties
application-model_fr_CA.properties
bootstrap-spaces_fr_CA.properties
bootstrap-templates_fr_CA.properties
bootstrap-tutorial_fr_CA.properties
coci-service_fr_CA.properties
content-model_fr_CA.properties
content-service_fr_CA.properties
dictionary-model_fr_CA.properties
permissions-service_fr_CA.properties
rule-config_fr_CA.properties
system-model_fr_CA.properties
version-service_fr_CA.properties
webclient_fr_CA.properties


============Installation============

    - Copier tous les fichiers vers le dossier <config root>/messages.

    - Aller dans le dossier <config root> d'Alfresco

    - Sauvegarder une copie du fichier 'web-client-config.xml'

    - Editer le fichier 'web-client-config.xml' pour modifier les langues disponibles:

    - Rechercher la section '<languages>'  

    - Ajouter la ligne suivante :     
  
             '<language locale="fr_CA">Fran�ais (Canada)</language>'

    - Sauvegarder le ficher

    - Red�marrer le serveur Alfresco

================================
Contributeurs � ce Language Pack
================================

Cette version: Fran�ois Ouellette, Toronto, Canada               
               fouellet@idirect.com

Voir le groupe de discussion Alfresco Forum pour le statut des Language Packs:

http://www.alfresco.org/forums/viewforum.php?f=16



Auteur(s) Originaux : L'�quipe Alfresco

Contributeurs :

Traducteurs Anglais - Fran�ais: Camille B�gnis, Laurent Genier, Christian Roy, Philippe Seillier, Frank Shipley