======================
Alfresco Language Pack
======================

For release: PR6

For locale: EN-US (default)


==============================
Contents of this Language Pack
==============================

action-config.properties (more generally 'action-config_XX_YY.properties')

messages.properties (more generally 'messages_XX_YY.properties')

rule-config.properties (more generally 'rule-config_XX_YY.properties')


============
Installation
============

- Copy 'messages_XX_YY.properties' file into <config root> folder.

- Copy 'action-config_XX_YY.properties' file into <config root>/messages folder.

- Copy 'rule-config_XX_YY.properties' file into <config root>/messages folder.

- Edit the 'web-client-config.xml' file in the <config root> folder to set what languages
  you wish to be available:

  - Find the '<languages>' section
  - Add or remove languages of the form:

       '<language locale="XX_YY">LangName</language>'

- Save the file

- Restart the Alfresco server


==================================
Contributors to this Language Pack
==================================

See the Alfresco Forum for status on Language Packs:
http://www.alfresco.org/forums/viewforum.php?f=16

Original Author(s): Alfresco Team
Contributors: