/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.tika.detect;

import java.io.IOException;
import java.io.InputStream;

import org.apache.poi.poifs.common.POIFSConstants;
import org.apache.poi.poifs.storage.HeaderBlockConstants;
import org.apache.poi.util.IOUtils;
import org.apache.poi.util.LittleEndian;
import org.apache.tika.io.TikaInputStream;
import org.apache.tika.metadata.Metadata;
import org.apache.tika.mime.MediaType;


/**
 * A detector that knows about the container 
 *  formats that we support (eg POIFS, Zip), 
 *  and is able to peek inside them to 
 *  better figure out the contents.
 * Should normally be used with a 
 *  {@link TikaInputStream} to minimise the
 *  memory usage.
 */
public class ContainerAwareDetector implements Detector {
    private Detector fallbackDetector;
    private ZipContainerDetector zipDetector;
    private POIFSContainerDetector poifsDetector;
    
    public ContainerAwareDetector(Detector fallbackDetector) {
        this.fallbackDetector = fallbackDetector;
        poifsDetector = new POIFSContainerDetector();
        zipDetector = new ZipContainerDetector();
    }
    
    public MediaType detect(InputStream input, Metadata metadata)
            throws IOException {
        return detect(TikaInputStream.get(input), metadata);
    }
    
    public MediaType detect(TikaInputStream input, Metadata metadata)
            throws IOException {
	
        // Grab the first 8 bytes, used to do container detection
        input.mark(8);
        byte[] first8 = new byte[8];
        IOUtils.readFully(input, first8);
        input.reset();
	
        // Is this a zip file?
        if(first8[0] == POIFSConstants.OOXML_FILE_HEADER[0] &&
           first8[1] == POIFSConstants.OOXML_FILE_HEADER[1] &&
           first8[2] == POIFSConstants.OOXML_FILE_HEADER[2] &&
           first8[3] == POIFSConstants.OOXML_FILE_HEADER[3]) {
            return zipDetector.detect(input, metadata);
        }
        
        // Is this an ole2 file?
        long ole2Signature = LittleEndian.getLong(first8, 0);
        if(ole2Signature == HeaderBlockConstants._signature) {
            return poifsDetector.detect(input, metadata);
        }
        
        // Not a supported container, fall back
        return fallbackDetector.detect(input, metadata);
    }
}

