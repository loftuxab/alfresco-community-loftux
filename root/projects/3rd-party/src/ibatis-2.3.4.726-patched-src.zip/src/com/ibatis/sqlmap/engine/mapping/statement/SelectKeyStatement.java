/*
 *  Copyright 2004 Clinton Begin
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
package com.ibatis.sqlmap.engine.mapping.statement;

import com.ibatis.sqlmap.client.event.RowHandler;
import com.ibatis.sqlmap.engine.execution.GeneratedKeyThreadLocal;
import com.ibatis.sqlmap.engine.scope.StatementScope;
import com.ibatis.sqlmap.engine.transaction.Transaction;

import java.sql.SQLException;
import java.util.List;

/**
 * Regarding jdbc 3 generated keys:
 * <ul>
 * <li>
 * 	Objectives were to make the least possible amount of changes. No change in xml 
 *  was done, only re-interpretation of contents. 
 * </li>
 * <li>
 * 	The selectKey xml element should contain the column name for the generated key 
 *  in the following format: KEY_COLUMN:column_name. The "KEY_COLUMN:" prefix serves 
 *  as a flag to indicate that it does not contain a normal sql query.
 * </li>
 * <li>
 * 	The runAfterSQL field is ignored when a keyColumn is defined.
 * </li>
 * <li>
 *  The {@link GeneratedKeyThreadLocal} class is used to pass the key between the 
 *  SqlMapExecutorDelegate and the SqlExecutor. This was least intrusive to current 
 *  interface layers, since no signatures needed to be changed.
 * </li> 
 *   
 */
public class SelectKeyStatement extends SelectStatement {

  private String keyProperty;
  private boolean runAfterSQL;

  /**
   * The keyColumn stores the column name for which a key will be generated in the 
   * database. It will only be set when a jdbc3 auto generated key is to be 
   * retrieved, effectively replacing the selectKey statement
   * 
   */
  private String keyColumn; 
  
	public String getKeyColumn( )
	{
		return keyColumn;
	}

	public void setKeyColumn( String keyColumn )
	{
		this.keyColumn = keyColumn;
	}

	public String getKeyProperty() {
    return keyProperty;
  }

  public void setKeyProperty(String keyProperty) {
    this.keyProperty = keyProperty;
  }

  public boolean isRunAfterSQL() {
    return runAfterSQL;
  }

  public void setRunAfterSQL(boolean runAfterSQL) {
    this.runAfterSQL = runAfterSQL;
  }

  public List executeQueryForList(StatementScope statementScope, Transaction trans, Object parameterObject, int skipResults, int maxResults)
      throws SQLException {
    throw new SQLException("Select Key statements cannot be executed for a list.");
  }

  public void executeQueryWithRowHandler(StatementScope statementScope, Transaction trans, Object parameterObject, RowHandler rowHandler)
      throws SQLException {
    throw new SQLException("Select Key statements cannot be executed with a row handler.");
  }

}
