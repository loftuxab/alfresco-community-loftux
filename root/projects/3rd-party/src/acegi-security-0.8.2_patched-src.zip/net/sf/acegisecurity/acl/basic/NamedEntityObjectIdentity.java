/* Copyright 2004 Acegi Technology Pty Limited
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.sf.acegisecurity.acl.basic;

import org.springframework.util.Assert;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;


/**
 * Simple implementation of {@link AclObjectIdentity}.
 * 
 * <P>
 * Uses <code>String</code>s to store the identity of the domain object
 * instance. Also offers a constructor that uses reflection to build the
 * identity information.
 * </p>
 *
 * @author Ben Alex
 * @version $Id: NamedEntityObjectIdentity.java,v 1.3 2005/04/15 01:21:33 luke_t Exp $
 */
public class NamedEntityObjectIdentity implements AclObjectIdentity {
    //~ Instance fields ========================================================

    private String classname;
    private String id;

    //~ Constructors ===========================================================

    public NamedEntityObjectIdentity(String classname, String id) {
        if ((classname == null) || "".equals(classname)) {
            throw new IllegalArgumentException("classname required");
        }

        if ((id == null) || "".equals(id)) {
            throw new IllegalArgumentException("id required");
        }

        this.classname = classname;
        this.id = id;
    }

    /**
     * Creates the <code>NamedEntityObjectIdentity</code> based on the passed
     * object instance. The passed object must provide a <code>getId()</code>
     * method, otherwise an exception will be thrown.
     *
     * @param object the domain object instance to create an identity for
     *
     * @throws IllegalAccessException
     * @throws InvocationTargetException
     * @throws IllegalArgumentException
     */
    public NamedEntityObjectIdentity(Object object)
        throws IllegalAccessException, InvocationTargetException {
        Assert.notNull(object, "object cannot be null");

        this.classname = object.getClass().getName();

        Class clazz = object.getClass();

        try {
            Method method = clazz.getMethod("getId", null);
            Object result = method.invoke(object, null);
            this.id = result.toString();
        } catch (NoSuchMethodException nsme) {
            throw new IllegalArgumentException("Object of class '" + clazz
                    + "' does not provide the required getId() method: " + object);
        }
    }

    protected NamedEntityObjectIdentity() {
        throw new IllegalArgumentException("Cannot use default constructor");
    }

    //~ Methods ================================================================

    /**
     * Indicates the classname portion of the object identity.
     *
     * @return the classname (never <code>null</code>)
     */
    public String getClassname() {
        return classname;
    }

    /**
     * Indicates the instance identity portion of the object identity.
     *
     * @return the instance identity (never <code>null</code>)
     */
    public String getId() {
        return id;
    }

    /**
     * Important so caching operates properly.
     * 
     * <P>
     * Considers an object of the same class equal if it has the same
     * <code>classname</code> and <code>id</code> properties.
     * </p>
     *
     * @param arg0 object to compare
     *
     * @return <code>true</code> if the presented object matches this object
     */
    public boolean equals(Object arg0) {
        if (arg0 == null) {
            return false;
        }

        if (!(arg0 instanceof NamedEntityObjectIdentity)) {
            return false;
        }

        NamedEntityObjectIdentity other = (NamedEntityObjectIdentity) arg0;

        if (this.getId().equals(other.getId())
            && this.getClassname().equals(other.getClassname())) {
            return true;
        }

        return false;
    }

    /**
     * Important so caching operates properly.
     *
     * @return the hash of the classname and id
     */
    public int hashCode() {
        StringBuffer sb = new StringBuffer();
        sb.append(this.classname).append(this.id);

        return sb.toString().hashCode();
    }

    public String toString() {
        StringBuffer sb = new StringBuffer();
        sb.append(this.getClass().getName()).append("[");
        sb.append("Classname: ").append(this.classname);
        sb.append("; Identity: ").append(this.id).append("]");

        return sb.toString();
    }
}
