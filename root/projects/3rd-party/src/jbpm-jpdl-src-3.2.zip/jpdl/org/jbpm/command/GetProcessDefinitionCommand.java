package org.jbpm.command;

import java.util.Iterator;
import java.util.List;

import org.jbpm.JbpmContext;
import org.jbpm.graph.def.ProcessDefinition;

/**
 * This Command returns all process definitions (or only the latest if 
 * onlyLatest is true)
 * 
 * @author Bernd Ruecker (bernd.ruecker@camunda.com)
 */
public class GetProcessDefinitionCommand implements Command {
	
	private static final long serialVersionUID = -1908847549444051495L;
	
	private boolean onlyLatest = true;

	public GetProcessDefinitionCommand() {		
	}
		
	public GetProcessDefinitionCommand(boolean onlyLatest) {
		this.onlyLatest = onlyLatest;
	}

	public Object execute(JbpmContext jbpmContext) throws Exception {
		List result = (onlyLatest ?  
			jbpmContext.getGraphSession().findLatestProcessDefinitions() :
			jbpmContext.getGraphSession().findAllProcessDefinitions());			

		/* traverse and access property if it is missing in the default fetchgroup
		 * at the moment, nothing is missing, so skip that :-)
		Iterator iter = pds.iterator();
		while (iter.hasNext()) {
			ProcessDefinition pd = (ProcessDefinition)iter.next();
		}
		 */
		return result;
	}

	public boolean isOnlyLatest() {
		return onlyLatest;
	}

	public void setOnlyLatest(boolean onlyLatest) {
		this.onlyLatest = onlyLatest;
	}

}
