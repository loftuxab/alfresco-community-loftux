package org.jbpm.command;

import java.util.Iterator;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jbpm.context.exe.ContextInstance;
import org.jbpm.graph.exe.ProcessInstance;
import org.jbpm.graph.exe.Token;
import org.jbpm.logging.log.ProcessLog;
import org.jbpm.taskmgmt.exe.TaskInstance;

public abstract class AbstractGetObjectBaseCommand implements Command {

    static final Log log = LogFactory
	    .getLog(AbstractGetObjectBaseCommand.class);

    /**
         * if true, all process variables in the context (process instance /
         * task) are prefetched too
         */
    private boolean includeAllVariables = true;

    /**
         * specify the names of the variables to prefetch
         */
    private String[] variablesToInclude = new String[0];

    /**
         * if true, the logs for the process are prefetched too
         */
    private boolean includeLogs = true;

    public AbstractGetObjectBaseCommand() {
    }

    public AbstractGetObjectBaseCommand(boolean includeAllVariables,
	    boolean includeLogs) {
	this.includeAllVariables = includeAllVariables;
    }

    public AbstractGetObjectBaseCommand(String[] variablesToInclude) {
	this.variablesToInclude = variablesToInclude;
    }

    public void retrieveTaskInstanceDetails(TaskInstance ti) {
	try {
	    ti.getToken().getProcessInstance().getProcessDefinition().getName();

	    // in TaskInstances created with jbpm 3.1, this association was
	    // not present!
	    ti.setProcessInstance(ti.getToken().getProcessInstance());
	    ti.getToken().getNode().getName();
	    ti.getTask().getName();
	    
	    ti.getAvailableTransitions();

	    retrieveVariables(ti);
	}
	catch (Exception ex) {
	    log.warn(
		    "exception while retrieving task instance data for task instance "
			    + ti.getId(), ex);
	}
    }

    public ProcessInstance retrieveProcessInstance(ProcessInstance pi) {
	try {
	    pi.getProcessDefinition().getName();
	    retrieveToken(pi.getRootToken());

	    retrieveVariables(pi);
	    
	    if (includeLogs)
		retrieveLogs(pi);
	}
	catch (Exception ex) {
	    log.warn(
		    "exception while retrieving process instance data for process instance "
			    + pi, ex);
	}
	return pi;
    }

    protected void retrieveToken(Token t) {
	t.getNode().getName();
	t.getAvailableTransitions();
	
	Iterator iter = t.getChildren().values().iterator();
	while (iter.hasNext()) {
	    retrieveToken((Token) iter.next());
	}
    }

    public void retrieveVariables(ProcessInstance pi) {
	if (includeAllVariables) {
	    pi.getContextInstance().getVariables();
	}
	else {
	    for (int i = 0; i < variablesToInclude.length; i++) {
		pi.getContextInstance().getVariable(variablesToInclude[i]);
	    }
	}
    }

    public void retrieveVariables(TaskInstance ti) {
	if (includeAllVariables) {
	    ti.getContextInstance().getVariables();
	}
	else {
	    for (int i = 0; i < variablesToInclude.length; i++) {
		ti.getVariable(variablesToInclude[i]);
	    }
	}
    }

    protected void retrieveLogs(ProcessInstance pi) {
	Iterator iter = pi.getLoggingInstance().getLogs().iterator();
	while (iter.hasNext()) {
	    ProcessLog pl = (ProcessLog) iter.next();
	    pl.getToken().getId();
	}
    }

    public boolean isIncludeAllVariables() {
	return includeAllVariables;
    }

    public void setIncludeAllVariables(boolean includeAllVariables) {
	this.includeAllVariables = includeAllVariables;
    }

    public String[] getVariablesToInclude() {
	return variablesToInclude;
    }

    public void setVariablesToInclude(String[] variablesToInclude) {
	this.variablesToInclude = variablesToInclude;
    }

    public void setVariablesToInclude(String variableToInclude) {
	this.variablesToInclude = new String[] { variableToInclude };
    }

    public boolean isIncludeLogs() {
	return includeLogs;
    }

    public void setIncludeLogs(boolean includeLogs) {
	this.includeLogs = includeLogs;
    }
}