//----------------------------------------------------------------------------
// 
//  Note:  
//   This version of ExcludeDoclet is public domain from:
//      http://sixlegs.com/blog/java/exclude-javadoc-tag.html
//
//   I (Jon Cox <jcox@alfresco.org>) just tweaked it a bit for Java 5.
//
//   To recompile:
//         javac  -classpath /.../tools.jar  ExcludeDoclet.java 
//
//   To run it:
//      CLASSPATH=$CLASSPATH:/.../tools.jar javadoc               \
//                                          -doclet ExcludeDoclet \
//                                           ...your files...
//
//   To hide public stuff from javadoc, just give it an '@exclude' tag!
//----------------------------------------------------------------------------

import com.sun.javadoc.*;
import com.sun.tools.doclets.standard.Standard;
import com.sun.tools.javadoc.Main;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;

/**
*   A doclet that allows public classes/members to be hidden 
*   using an @exclude tag.  This lets you make a distinction
*   between a public API and a published API.  For a nice 
*   discussion on public-vs-published see Martin Fowler's
*   <a href='http://www.martinfowler.com/ieeeSoftware/published.pdf'>
*   paper</a>
*
*   <p>
*   This clever/open-source version of ExcludeDoclet was found
*   <a href='http://sixlegs.com/blog/java/exclude-javadoc-tag.html'>
*   here</a>.<br>
*   <p>
*   Usage:
*   <pre>
*       public SomeClass
*       {
*             &#047;**  blah blah.. *&#047;
*             public void show_me_in_javadocs() { ... }
*
*             &#047;** @exclude *&#047;
*             public void hide_me_in_javadocs() { ... }
*       }
*   </pre>
*
*  All you need to do in order to use this doclet instead of the
*  default doclet is say:
*  <pre>
*       javadoc -doclet       ExcludeDoclet                                \
*               -docletpath   /...installed location.../exclude-doclet.jar \
*               ...your files...
*
*  </pre>
*
*  Alternatively, if you're using Ant you could say:
*
*  <pre>
*      &lt;javadoc ...&gt;
*
*          &lt;!-- Hide public classes/members that use the @exclude tag --&gt;
*          &lt;doclet name="ExcludeDoclet" path=".../exclude-doclet.jar"/&gt;
*
*      &lt;/javadoc&gt;
*  </pre>
*
*/
public class ExcludeDoclet
{
    public static void main(String[] args)
    {
        String name = ExcludeDoclet.class.getName();
        Main.execute(name, name, args);
    }

    public static boolean 
    validOptions(String[][] options, DocErrorReporter reporter)
    throws java.io.IOException
    {
        return Standard.validOptions(options, reporter);
    }
    
    public static int optionLength(String option)
    {
        return Standard.optionLength(option);
    }
        
    public static boolean start(RootDoc root)
    throws java.io.IOException
    {
        return Standard.start((RootDoc)process(root, RootDoc.class));
    }

    private static boolean exclude(Doc doc)
    {
        return doc.tags("exclude").length > 0;
    }

    private static Object process(Object obj, Class expect)
    {
        if (obj == null)
            return null;
        Class cls = obj.getClass();
        if (cls.getName().startsWith("com.sun.")) {
            return Proxy.newProxyInstance(cls.getClassLoader(),
                                          cls.getInterfaces(),
                                          new ExcludeHandler(obj));
        } else if (obj instanceof Object[]) {
            Class componentType = expect.getComponentType();
            Object[] array = (Object[])obj;
            List<Object> list = new ArrayList<Object>(array.length);
            for (int i = 0; i < array.length; i++) {
                Object entry = array[i];
                if ((entry instanceof Doc) && exclude((Doc)entry))
                    continue;
                list.add(process(entry, componentType));
            }
            return list.toArray((Object[])
                                Array.newInstance(componentType, list.size()));
        } 
        else { return obj; }
    }

    private static class ExcludeHandler
    implements InvocationHandler
    {
        private Object target;
        
        public ExcludeHandler(Object target)
        {
            this.target = target;
        }

        public Object invoke(Object proxy, Method method, Object[] args)
        throws Throwable
        {
            if (args != null) {
                String methodName = method.getName();
                if (methodName.equals("compareTo") ||
                    methodName.equals("equals") ||
                    methodName.equals("overrides") ||
                    methodName.equals("subclassOf")) {
                    args[0] = unwrap(args[0]);
                }
            }
            try {
                return process(method.invoke(target, args), method.getReturnType());
            } catch (InvocationTargetException e) {
                throw e.getTargetException();
            }
        }

        private Object unwrap(Object proxy)
        {
            if (proxy instanceof Proxy)
                return ((ExcludeHandler)Proxy.getInvocationHandler(proxy)).target;
            return proxy;
        }
    }
}
