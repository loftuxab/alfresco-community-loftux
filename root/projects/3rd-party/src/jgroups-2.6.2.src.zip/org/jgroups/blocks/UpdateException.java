// $Id: UpdateException.java,v 1.2 2006/11/13 17:42:10 bstansberry Exp $


package org.jgroups.blocks;



public class UpdateException extends Exception {

    private static final long serialVersionUID = -4196360091623991749L;

	public UpdateException(String msg) {
	super(msg);
    }

}
