// $Id: ExitEvent.java,v 1.2 2005/07/17 11:38:05 chrislott Exp $

package org.jgroups;
/**
 * Trivial object that represents an exit event.
 */
public class ExitEvent {
    public String toString() {return "ExitEvent";}
}
