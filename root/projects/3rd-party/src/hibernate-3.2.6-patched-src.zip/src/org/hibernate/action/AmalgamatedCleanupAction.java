package org.hibernate.action;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.hibernate.HibernateException;
import org.hibernate.engine.SessionImplementor;

public class AmalgamatedCleanupAction implements Executable, Serializable
{
    private final SessionImplementor session;

    private final Set affectedEntityNames = new HashSet();

    private final Set affectedCollectionRoles = new HashSet();

    private final Set spaces = new HashSet();

    public AmalgamatedCleanupAction(SessionImplementor session)
    {
        super();
        this.session = session;
    }

    public void addExecutable(Executable executable)
    {
        if (executable instanceof EntityAction)
        {
            EntityAction entityAction = (EntityAction) executable;
            String entityName = entityAction.getEntityName();
            if (!affectedEntityNames.contains(entityName))
            {
                affectedEntityNames.add(entityName);
                Serializable[] toAdd = entityAction.getPropertySpaces();
                for(int i = 0; i < toAdd.length; i++)
                {
                    spaces.add(toAdd[i]);
                }
            }
        }
        else if (executable instanceof CollectionAction)
        {
            CollectionAction collectionAction = (CollectionAction) executable;
            String collectionRole = collectionAction.getCollectionRole();
            if(!affectedCollectionRoles.contains(collectionRole))
            {
                affectedCollectionRoles.add(collectionRole);
                Serializable[] toAdd = collectionAction.getPropertySpaces();
                for(int i = 0; i < toAdd.length; i++)
                {
                    spaces.add(toAdd[i]);
                }
            }
        }
        else
        {
            // Invalid or ignore ??
        }
    }

    public void afterTransactionCompletion(boolean success) throws HibernateException
    {
        evictEntityRegions();
        evictCollectionRegions();
    }

    public void beforeExecutions() throws HibernateException
    {
        // nothing to do
    }

    public void execute() throws HibernateException
    {
        // nothing to do
    }

    public Serializable[] getPropertySpaces()
    {
        Serializable[] answer = new Serializable[spaces.size()];
        int position = 0;
        for(Iterator it = spaces.iterator(); it.hasNext(); /**/)
        {
            Serializable s = (Serializable) it.next();
            answer[position++] = s;
        }
        return answer;
        
    }

    public boolean hasAfterTransactionCompletion()
    {
        return true;
    }

    public boolean hasCache()
    {
        return true;
    }

    public boolean hasPostCommitEventListeners()
    {
        return false;
    }

    public boolean isBulkAction()
    {
        return true;
    }

    private void evictEntityRegions()
    {
        if (affectedEntityNames != null)
        {
            Iterator itr = affectedEntityNames.iterator();
            while (itr.hasNext())
            {
                final String entityName = (String) itr.next();
                session.getFactory().evictEntity(entityName);
            }
        }
    }

    private void evictCollectionRegions()
    {
        if (affectedCollectionRoles != null)
        {
            Iterator itr = affectedCollectionRoles.iterator();
            while (itr.hasNext())
            {
                final String roleName = (String) itr.next();
                session.getFactory().evictCollection(roleName);
            }
        }
    }
}
