package org.hibernate.engine.query.sql;

/**
 * Describes a return in a native SQL query.
 *
 * @author Steve Ebersole
 */
public interface NativeSQLQueryReturn {
}
