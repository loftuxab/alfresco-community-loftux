/*
* Licensed to the Apache Software Foundation (ASF) under one or more
* contributor license agreements.  The ASF licenses this file to You
* under the Apache License, Version 2.0 (the "License"); you may not
* use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.  For additional information regarding
* copyright in this work, please see the NOTICE file in the top level
* directory of this distribution.
*/
package org.apache.abdera.protocol.client.cache.lru;

import org.apache.abdera.Abdera;
import org.apache.abdera.protocol.client.cache.Cache;
import org.apache.abdera.protocol.client.cache.CacheKey;
import org.apache.abdera.protocol.client.cache.CachedResponse;
import org.apache.abdera.protocol.client.cache.InMemoryCache;
import org.apache.abdera.protocol.client.cache.LRUMap;

@SuppressWarnings("serial")
public class LRUCache
  extends InMemoryCache
  implements Cache {

  private final static int DEFAULT_SIZE = 10;
  
  public LRUCache(Abdera abdera) {
    this(abdera,DEFAULT_SIZE);
  }
  
  public LRUCache(Abdera abdera, final int size) {
    super(abdera);
    setMap(new LRUMap<CacheKey,CachedResponse>(size,0.75f,true));    
  }
  
}
