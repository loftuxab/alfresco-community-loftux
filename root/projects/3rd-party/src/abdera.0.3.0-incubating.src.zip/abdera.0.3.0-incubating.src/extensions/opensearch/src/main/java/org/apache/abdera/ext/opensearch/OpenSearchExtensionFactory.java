/*
* Licensed to the Apache Software Foundation (ASF) under one or more
* contributor license agreements.  The ASF licenses this file to You
* under the Apache License, Version 2.0 (the "License"); you may not
* use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.  For additional information regarding
* copyright in this work, please see the NOTICE file in the top level
* directory of this distribution.
*/
package org.apache.abdera.ext.opensearch;

import org.apache.abdera.util.AbstractExtensionFactory;

public final class OpenSearchExtensionFactory 
  extends AbstractExtensionFactory
  implements OpenSearchConstants {

  public OpenSearchExtensionFactory() {
    super(
      OpenSearchConstants.OPENSEARCH_NS, 
      OpenSearchConstants.OPENSEARCH_V10_NS);
    addImpl(QUERY,Query.class);
    addImpl(QUERY_V10,Query.class);
    addImpl(ITEMS_PER_PAGE, IntegerElement.class);
    addImpl(START_INDEX, IntegerElement.class);
    addImpl(TOTAL_RESULTS, IntegerElement.class);
    addImpl(ITEMS_PER_PAGE_V10, IntegerElement.class);
    addImpl(START_INDEX_V10, IntegerElement.class);
    addImpl(TOTAL_RESULTS_V10, IntegerElement.class);
  }
  
}
