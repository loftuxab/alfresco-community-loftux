/*
* Licensed to the Apache Software Foundation (ASF) under one or more
* contributor license agreements.  The ASF licenses this file to You
* under the Apache License, Version 2.0 (the "License"); you may not
* use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.  For additional information regarding
* copyright in this work, please see the NOTICE file in the top level
* directory of this distribution.
*/
package org.apache.abdera.security.util;

import javax.xml.namespace.QName;

public final class Constants {

  public static final String CONTENT_ENCRYPTED = "Content-Encrypted";
  public static final String ACCEPT_ENCRYPTION = "Accept-Encryption";
  Constants() {}
  
  public static final String DSIG_NS = "http://www.w3.org/2000/09/xmldsig#";
  public static final String XENC_NS = "http://www.w3.org/2001/04/xmlenc#";
  public static final String LN_SIGNATURE = "Signature";
  public static final String LN_ENCRYPTEDDATA = "EncryptedData";
  public static final String DSIG_PREFIX = "dsig";
  public static final String XENC_PREFIX = "xenc";
  
  public static final QName SIGNATURE = new QName(DSIG_NS, LN_SIGNATURE, DSIG_PREFIX);
  public static final QName ENCRYPTEDDATA = new QName(XENC_NS, LN_ENCRYPTEDDATA, XENC_PREFIX);

}
