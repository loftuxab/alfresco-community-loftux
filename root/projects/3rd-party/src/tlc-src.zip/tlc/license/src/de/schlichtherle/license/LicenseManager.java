/*
 * LicenseManager.java
 *
 * Created on 22. Februar 2005, 13:27
 */
/*
 * Copyright 2005 Schlichtherle IT Services
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package de.schlichtherle.license;

import de.schlichtherle.xml.*;

import java.beans.*;
import java.io.*;
import java.security.*;
import java.security.cert.*;
import java.security.spec.*;
import java.util.*;
import java.util.prefs.*;

import javax.crypto.*;
import javax.crypto.spec.*;
import javax.security.auth.x500.X500Principal;
import javax.swing.filechooser.FileFilter;

/**
 * This is the top level class which manages all licensing aspects like for
 * instance the creation, installation and verification of license keys.
 * The license manager knows how to install, verify and uninstall full and
 * trial licenses for a given subject and ensures the privacy of the license
 * content in its persistent form (i.e. the <i>license key</i>).
 * For signing, verifying and validating licenses, this class cooperates with
 * a {@link LicenseNotary}.
 * <p>
 * This class is designed to be thread safe.
 *
 * @author Christian Schlichtherle
 */
public class LicenseManager implements LicenseCreator, LicenseVerifier {

    /** The timeout for the license content cache. */
    private static final long TIMEOUT = 30 * 60 * 1000; // half an hour

    /** The key in the preferences used to store the license key. */
    private static final String PREFERENCES_KEY = "license"; // NOI18N

    /**
     * The suffix for files which hold license certificates.
     */
    public static final String LICENSE_SUFFIX = ".lic"; // NOI18N - must be lowercase!
    static {
        assert LICENSE_SUFFIX.equals(LICENSE_SUFFIX.toLowerCase()); // paranoid
    }

    /**
     * Returns midnight local time today.
     */
    protected static final Date midnight() {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        
        return cal.getTime();
    }

    private LicenseParam param; // initialized by setLicenseParam() - should be accessed via getLicenseParam() only!

    //
    // Data computed and cached from the license configuration parameters.
    //

    private LicenseNotary notary; // lazy initialized

    private PrivacyGuard guard; // lazy initialized

    /** The cached certificate of the current license key. */
    private GenericCertificate certificate; // lazy initialized

    /** The time when the certificate was last set. */
    private long certificateTime; // lazy initialized

    /** A suitable file filter for the subject of this license manager. */
    private FileFilter fileFilter; // lazy initialized

    /** The preferences node used to store the license key. */
    private Preferences preferences; // lazy initialized

    /**
     * Creates a new License Manager.
     * <p>
     * <b>Warning:</b> The manager created by this constructor is <em>not</em>
     * valid and cannot be used unless {@link #setLicenseParam(LicenseParam)}
     * is called!
     */
    protected LicenseManager() {
    }

    /**
     * Creates a new License Manager.
     *
     * @param param The license configuration parameters
     *        - may <em>not</em> be <tt>null</tt>.
     *
     * @throws NullPointerException If the given parameter object does not
     *         obey the contract of its interface due to a <tt>null</tt>
     *         pointer.
     * @throws IllegalPasswordException If any password in the parameter object
     *         does not comply to the current policy.
     */
    public LicenseManager(LicenseParam param)
    throws  NullPointerException,
            IllegalPasswordException {
        setLicenseParam(param);
    }

    /**
     * Returns the license configuration parameters.
     */
    public LicenseParam getLicenseParam() {
        return param;
    }

    /**
     * Sets the license configuration parameters.
     * Calling this method resets the manager as if it had been
     * newly created.
     * Some plausibility checks are applied to the given parameter object
     * to ensure that it adheres to the contract of the parameter interfaces.
     *
     * @param param The license configuration parameters
     *        - may <em>not</em> be <tt>null</tt>.
     *
     * @throws NullPointerException If the given parameter object does not
     *         obey the contract of its interface due to a <tt>null</tt>
     *         pointer.
     * @throws IllegalPasswordException If any password in the parameter object
     *         does not comply to the current policy.
     */
    public synchronized void setLicenseParam(LicenseParam param)
    throws  NullPointerException,
            IllegalPasswordException {
        // Check parameters to implement fail-fast behaviour.
        if (param == null)
            throw new NullPointerException("param");
        if (param.getSubject() == null)
            throw new NullPointerException("subject");
        //if (param.getPreferences() == null)
        //    throw new NullPointerException("preferences");
        if (param.getKeyStoreParam() == null)
            throw new NullPointerException("keyStoreParam");
        final CipherParam cipherParam = param.getCipherParam();
        if (cipherParam == null)
            throw new NullPointerException("cipherParam");
        Policy.getCurrent().checkPwd(cipherParam.getKeyPwd());
        
        this.param = param;
        notary = null;
        certificate = null;
        certificateTime = 0;
        fileFilter = null;
        preferences = null;
    }

    //
    // Methods for license contents.
    //

    /**
     * Initializes and validates the license content, creates a new signed
     * license certificate for it and compresses, encrypts and stores it to
     * the given file as a license key.
     * <p>
     * As a side effect, the given license <tt>content</tt> is initialized
     * with some reasonable defaults unless the respective properties have
     * already been set.
     *
     * @param content The license content
     *        - may <em>not</em> be <tt>null</tt>.
     * @param keyFile The file to save the license key to
     *        - may <em>not</em> be <tt>null</tt>.
     *        This should have a <tt>LICENSE_SUFFIX</tt>.
     *
     * @throws Exception An instance of a subclass of this class for various
     *         reasons. Note that you should always use
     *         {@link Throwable#getLocalizedMessage()} to get a (possibly
     *         localized) meaningful detail message.
     *
     * @see #store(LicenseContent, LicenseNotary, File)
     * @see #initialize(LicenseContent)
     * @see #validate(LicenseContent)
     */
    public final synchronized void store(
            LicenseContent content,
            File keyFile)
    throws Exception {
        store(content, getLicenseNotary(), keyFile);
    }

    /**
     * Initializes and validates the license content, creates a new signed
     * license certificate for it and compresses, encrypts and stores it to
     * the given file as a license key.
     * <p>
     * As a side effect, the given license <tt>content</tt> is initialized
     * with some reasonable defaults unless the respective properties have
     * already been set.
     *
     * @param content The license content
     *        - may <em>not</em> be <tt>null</tt>.
     * @param notary The license notary used to sign the license key
     *        - may <em>not</em> be <tt>null</tt>.
     * @param keyFile The file to save the license key to
     *        - may <em>not</em> be <tt>null</tt>.
     *        This should have a <tt>LICENSE_SUFFIX</tt>.
     *
     * @throws Exception An instance of a subclass of this class for various
     *         reasons.
     *         Note that you should always use
     *         {@link Throwable#getLocalizedMessage()} to get a (possibly
     *         localized) meaningful detail message.
     *
     * @see #initialize(LicenseContent)
     * @see #validate(LicenseContent)
     *
     * @deprecated <b>Experimental:</b> Methods marked with this note have
     *             been tested to be functional but may change or disappear
     *             at will in one of the next releases because they are still
     *             a topic for research on extended functionality.
     *             Most likely the methods will prevail however and this note
     *             will just vanish, so you may use them with a certain risk.
     */
    protected synchronized void store(
            final LicenseContent content,
            final LicenseNotary notary,
            final File keyFile)
    throws Exception {
        storeLicenseKey(create(content, notary), keyFile);
    }

    /**
     * Initializes and validates the license content, creates a new signed
     * license certificate for it and compresses, encrypts and returns it
     * as a license key.
     * <p>
     * As a side effect, the given license <tt>content</tt> is initialized
     * with some reasonable defaults unless the respective properties have
     * already been set.
     *
     * @param content The license content
     *        - may <em>not</em> be <tt>null</tt>.
     *
     * @return The license key
     *         - <tt>null</tt> is never returned.
     *
     * @throws Exception An instance of a subclass of this class for various
     *         reasons.
     *         Note that you should always use
     *         {@link Throwable#getLocalizedMessage()} to get a (possibly
     *         localized) meaningful detail message.
     *
     * @see #create(LicenseContent, LicenseNotary)
     * @see #initialize(LicenseContent)
     * @see #validate(LicenseContent)
     */
    public final synchronized byte[] create(
            final LicenseContent content)
    throws Exception {
        return create(content, getLicenseNotary());
    }

    /**
     * Initializes and validates the license content, creates a new signed
     * license certificate for it and compresses, encrypts and returns it
     * as a license key.
     * <p>
     * As a side effect, the given license <tt>content</tt> is initialized
     * with some reasonable defaults unless the respective properties have
     * already been set.
     *
     * @param content The license content
     *        - may <em>not</em> be <tt>null</tt>.
     * @param notary The license notary used to sign the license key
     *        - may <em>not</em> be <tt>null</tt>.
     *
     * @return The license key
     *         - <tt>null</tt> is never returned.
     *
     * @throws Exception An instance of a subclass of this class for various
     *         reasons.
     *         Note that you should always use
     *         {@link Throwable#getLocalizedMessage()} to get a (possibly
     *         localized) meaningful detail message.
     *
     * @see #initialize(LicenseContent)
     * @see #validate(LicenseContent)
     *
     * @deprecated <b>Experimental:</b> Methods marked with this note have
     *             been tested to be functional but may change or disappear
     *             at will in one of the next releases because they are still
     *             a topic for research on extended functionality.
     *             Most likely the methods will prevail however and this note
     *             will just vanish, so you may use them with a certain risk.
     */
    protected synchronized byte[] create(
            final LicenseContent content,
            final LicenseNotary notary)
    throws Exception {
        initialize(content);
        validate(content);
        final GenericCertificate certificate = notary.sign(content);
        final byte[] key = getPrivacyGuard().cert2key(certificate);

        return key;
    }

    /**
     * Loads, decrypts, decompresses, decodes and verifies the license key in
     * <tt>keyFile</tt>, validates its license content and installs it
     * as the current license key.
     *
     * @param keyFile The file to load the license key from
     *        - may <em>not</em> be <tt>null</tt>.
     *
     * @return A clone of the verified and validated content of the license key
     *         - <tt>null</tt> is never returned.
     *
     * @throws Exception An instance of a subclass of this class for various
     *         reasons.
     *         Note that you should always use
     *         {@link Throwable#getLocalizedMessage()} to get a (possibly
     *         localized) meaningful detail message.
     *
     * @see #install(File, LicenseNotary)
     * @see #validate(LicenseContent)
     */
    public final synchronized LicenseContent install(File keyFile)
    throws Exception {
        return install(keyFile, getLicenseNotary());
    }

    /**
     * Loads, decrypts, decompresses, decodes and verifies the license key in
     * <tt>keyFile</tt>, validates its license content and installs it
     * as the current license key.
     *
     * @param keyFile The file to load the license key from
     *        - may <em>not</em> be <tt>null</tt>.
     * @param notary The license notary used to verify the license key
     *        - may <em>not</em> be <tt>null</tt>.
     *
     * @return A clone of the verified and validated content of the license key
     *         - <tt>null</tt> is never returned.
     *
     * @throws Exception An instance of a subclass of this class for various
     *         reasons.
     *         Note that you should always use
     *         {@link Throwable#getLocalizedMessage()} to get a (possibly
     *         localized) meaningful detail message.
     *
     * @see #validate(LicenseContent)
     *
     * @deprecated <b>Experimental:</b> Methods marked with this note have
     *             been tested to be functional but may change or disappear
     *             at will in one of the next releases because they are still
     *             a topic for research on extended functionality.
     *             Most likely the methods will prevail however and this note
     *             will just vanish, so you may use them with a certain risk.
     */
    protected synchronized LicenseContent install(
            final File keyFile,
            final LicenseNotary notary)
    throws Exception {
        return install(loadLicenseKey(keyFile), notary);
    }

    /**
     * Decrypts, decompresses, decodes and verifies the license key in
     * <tt>key</tt>, validates its license content and installs it
     * as the current license key.
     *
     * @param key The license key
     *        - may <em>not</em> be <tt>null</tt>.
     * @param notary The license notary used to verify the license key
     *        - may <em>not</em> be <tt>null</tt>.
     *
     * @return A clone of the verified and validated content of the license key
     *         - <tt>null</tt> is never returned.
     *
     * @throws Exception An instance of a subclass of this class for various
     *         reasons.
     *         Note that you should always use
     *         {@link Throwable#getLocalizedMessage()} to get a (possibly
     *         localized) meaningful detail message.
     *
     * @see #validate(LicenseContent)
     *
     * @deprecated <b>Experimental:</b> Methods marked with this note have
     *             been tested to be functional but may change or disappear
     *             at will in one of the next releases because they are still
     *             a topic for research on extended functionality.
     *             Most likely the methods will prevail however and this note
     *             will just vanish, so you may use them with a certain risk.
     */
    protected synchronized LicenseContent install(
            final byte[] key,
            final LicenseNotary notary)
    throws Exception {
        final GenericCertificate certificate = getPrivacyGuard().key2cert(key);
        notary.verify(certificate);
        final LicenseContent content = (LicenseContent) certificate.getContent();
        validate(content);
        setLicenseKey(key);
        setCertificate(certificate);

        return content;
    }

    /**
     * Decrypts, decompresses, decodes and verifies the current license key,
     * validates its license content and returns it.
     *
     * @return A clone of the verified and validated content of the license key
     *         - <tt>null</tt> is never returned.
     *
     * @throws NoLicenseInstalledException If no license key is installed.
     * @throws Exception An instance of a subclass of this class for various
     *         other reasons.
     *         Note that you should always use
     *         {@link Throwable#getLocalizedMessage()} to get a (possibly
     *         localized) meaningful detail message.
     *
     * @see #validate(LicenseContent)
     */
    public final synchronized LicenseContent verify()
    throws Exception {
        return verify(getLicenseNotary());
    }

    /**
     * Decrypts, decompresses, decodes and verifies the current license key,
     * validates its license content and returns it.
     *
     * @param notary The license notary used to verify the current license key
     *        - may <em>not</em> be <tt>null</tt>.
     *
     * @return A clone of the verified and validated content of the license key
     *         - <tt>null</tt> is never returned.
     *
     * @throws NoLicenseInstalledException If no license key is installed.
     * @throws Exception An instance of a subclass of this class for various
     *         other reasons.
     *         Note that you should always use
     *         {@link Throwable#getLocalizedMessage()} to get a (possibly
     *         localized) meaningful detail message.
     *
     * @see #validate(LicenseContent)
     *
     * @deprecated <b>Experimental:</b> Methods marked with this note have
     *             been tested to be functional but may change or disappear
     *             at will in one of the next releases because they are still
     *             a topic for research on extended functionality.
     *             Most likely the methods will prevail however and this note
     *             will just vanish, so you may use them with a certain risk.
     */
    protected synchronized LicenseContent verify(final LicenseNotary notary)
    throws Exception {
        GenericCertificate certificate = getCertificate();
        if (certificate != null)
            return (LicenseContent) certificate.getContent();

        // Load license key from preferences, 
        final byte[] key = getLicenseKey();
        if (key == null)
            throw new NoLicenseInstalledException(getLicenseParam().getSubject());
        certificate = getPrivacyGuard().key2cert(key);
        notary.verify(certificate);
        final LicenseContent content = (LicenseContent) certificate.getContent();
        validate(content);
        setCertificate(certificate);

        return content;
    }
    
    /**
     * Decrypts, decompresses, decodes and verifies the given license key,
     * validates its license content and returns it.
     *
     * @param key The license key
     *        - may <em>not</em> be <tt>null</tt>.
     *
     * @return A clone of the verified and validated content of the license key
     *         - <tt>null</tt> is never returned.
     *
     * @throws Exception An instance of a subclass of this class for various
     *         reasons.
     *         Note that you should always use
     *         {@link Throwable#getLocalizedMessage()} to get a (possibly
     *         localized) meaningful detail message.
     *
     * @see #validate(LicenseContent)
     */
    public final synchronized LicenseContent verify(final byte[] key)
    throws Exception {
        return verify(key, getLicenseNotary());
    }
    
    /**
     * Decrypts, decompresses, decodes and verifies the given license key,
     * validates its license content and returns it.
     *
     * @param key The license key
     *        - may <em>not</em> be <tt>null</tt>.
     * @param notary The license notary used to verify the license key
     *        - may <em>not</em> be <tt>null</tt>.
     *
     * @return A clone of the verified and validated content of the license key
     *         - <tt>null</tt> is never returned.
     *
     * @throws Exception An instance of a subclass of this class for various
     *         reasons.
     *         Note that you should always use
     *         {@link Throwable#getLocalizedMessage()} to get a (possibly
     *         localized) meaningful detail message.
     *
     * @see #validate(LicenseContent)
     *
     * @deprecated <b>Experimental:</b> Methods marked with this note have
     *             been tested to be functional but may change or disappear
     *             at will in one of the next releases because they are still
     *             a topic for research on extended functionality.
     *             Most likely the methods will prevail however and this note
     *             will just vanish, so you may use them with a certain risk.
     */
    protected synchronized LicenseContent verify(
            final byte[] key,
            final LicenseNotary notary)
    throws Exception {
        final GenericCertificate certificate = getPrivacyGuard().key2cert(key);
        notary.verify(certificate);
        final LicenseContent content = (LicenseContent) certificate.getContent();
        validate(content);

        return content;
    }

    /**
     * Uninstalls the current license key.
     *
     * @throws Exception An instance of a subclass of this class for various
     *         reasons.
     */
    public synchronized void uninstall()
    throws Exception {
        setLicenseKey(null);
        setCertificate(null);
    }

    /**
     * Initializes the given license <tt>content</tt> with some reasonable
     * defaults unless the respective properties have already been set.
     *
     * @see #validate(LicenseContent)
     */
    protected synchronized void initialize(final LicenseContent content) {
        if (content.getHolder() == null)
            content.setHolder(new X500Principal("CN=Anonymous User")); // NOI18N
        if (content.getSubject() == null)
            content.setSubject(getLicenseParam().getSubject());
        if (content.getConsumerType() == null) {
            final Preferences prefs = getLicenseParam().getPreferences();
            if (prefs != null) {
                if (prefs.isUserNode())
                    content.setConsumerType("User"); // NOI18N
                else
                    content.setConsumerType("System"); // NOI18N
                content.setConsumerAmount(1);
            }
        }
        if (content.getIssuer() == null)
            content.setIssuer(new X500Principal(
                    "CN=" + getLicenseParam().getSubject())); // NOI18N
        if (content.getIssued() == null)
            content.setIssued(new Date());
        if (content.getNotBefore() == null)
            content.setNotBefore(midnight());
    }

    /**
     * Validates the license content.
     * This method is called whenever a license certificate is created,
     * installed or verified.
     * <p>
     * Validation consists of the following plausability checks for the
     * properties of this class:
     * <p>
     * <ul>
     * <li>'subject' must match the subject required by the application
     *     via the {@link LicenseParam} interface.
     * <li>'holder', 'issuer' and 'issued' must be provided (i.e. not
     *     <tt>null</tt>).
     * <li>If 'notBefore' or 'notAfter' are provided, the current date and
     *     time must match their restrictions.
     * <li>'consumerType' must be provided and 'consumerAmount' must be
     *     positive. If a user preference node is provided in the license
     *     parameters, 'consumerType' must also match �User� (whereby case
     *     is ignored) and 'consumerAmount' must equal 1.
     * </ul>
     * <p>
     * If you need more or less rigid restrictions, you should override this
     * method in a subclass.
     * 
     * @param content The license content
     *        - may <em>not</em> be <tt>null</tt>.
     *
     * @throws NullPointerException If <tt>content</tt> is <tt>null</tt>.
     * @throws LicenseContentException If any validation test fails.
     *         Note that you should always use
     *         {@link Throwable#getLocalizedMessage()} to get a (possibly
     *         localized) meaningful detail message.
     *
     * @see #initialize(LicenseContent)
     */
    protected synchronized void validate(final LicenseContent content)
    throws LicenseContentException {
        final LicenseParam param = getLicenseParam();
        if (!param.getSubject().equals(content.getSubject()))
            throw new LicenseContentException("exc.invalidSubject"); // NOI18N
        if (content.getHolder() == null)
            throw new LicenseContentException("exc.holderIsNull"); // NOI18N
        if (content.getIssuer() == null)
            throw new LicenseContentException("exc.issuerIsNull"); // NOI18N
        if (content.getIssued() == null)
            throw new LicenseContentException("exc.issuedIsNull"); // NOI18N
        final Date now = new Date();
        final Date notBefore = content.getNotBefore();
        if (notBefore != null && now.before(notBefore))
            throw new LicenseContentException("exc.licenseIsNotYetValid"); // NOI18N
        final Date notAfter = content.getNotAfter();
        if (notAfter != null && now.after(notAfter))
            throw new LicenseContentException("exc.licenseHasExpired"); // NOI18N
        final String consumerType = content.getConsumerType();
        if (consumerType == null)
            throw new LicenseContentException("exc.consumerTypeIsNull"); // NOI18N
        final Preferences prefs = param.getPreferences();
        if (prefs != null && prefs.isUserNode()) {
            if (!"User".equalsIgnoreCase(consumerType)) // NOI18N
                throw new LicenseContentException("exc.consumerTypeIsNotUser"); // NOI18N
            if (content.getConsumerAmount() != 1)
                throw new LicenseContentException("exc.consumerAmountIsNotOne"); // NOI18N
        } else {
            if (content.getConsumerAmount() <= 0)
                throw new LicenseContentException("exc.consumerAmountIsNotPositive"); // NOI18N
        }
    }

    //
    // Methods for license certificates.
    //

    /**
     * Returns the license certificate cached from the
     * last installation/verification of a license key
     * or <tt>null</tt> if there wasn't an installation/verification
     * or a timeout has occured.
     *
     * @deprecated <b>Experimental:</b> Methods marked with this note have
     *             been tested to be functional but may change or disappear
     *             at will in one of the next releases because they are still
     *             a topic for research on extended functionality.
     *             Most likely the methods will prevail however and this note
     *             will just vanish, so you may use them with a certain risk.
     */
    protected /*synchronized*/ GenericCertificate getCertificate() {
        if (certificate != null
                && System.currentTimeMillis() < certificateTime + TIMEOUT)
            return certificate; // use cached certificate until timeout
        else
            return null;
    }

    /**
     * Sets the given license certificate as installed or verified.
     *
     * @param certificate The license certificate
     *        - may be <tt>null</tt> to clear.
     *
     * @deprecated <b>Experimental:</b> Methods marked with this note have
     *             been tested to be functional but may change or disappear
     *             at will in one of the next releases because they are still
     *             a topic for research on extended functionality.
     *             Most likely the methods will prevail however and this note
     *             will just vanish, so you may use them with a certain risk.
     */
    protected synchronized void setCertificate(GenericCertificate certificate) {
        this.certificate = certificate;
        certificateTime = System.currentTimeMillis(); // set cache timeout
    }

    //
    // Methods for license keys.
    // Note that in contrast to the methods of the privacy guard,
    // the following methods may have side effects (preferences, file system).
    //

    /**
     * Returns the current license key.
     *
     * @deprecated <b>Experimental:</b> Methods marked with this note have
     *             been tested to be functional but may change or disappear
     *             at will in one of the next releases because they are still
     *             a topic for research on extended functionality.
     *             Most likely the methods will prevail however and this note
     *             will just vanish, so you may use them with a certain risk.
     */
    protected /*synchronized*/ byte[] getLicenseKey() {
        return getLicenseParam().getPreferences().getByteArray(PREFERENCES_KEY, null);
    }

    /**
     * Installs the given license key as the current license key.
     * If <tt>key</tt> is <tt>null</tt>, the current license key gets
     * uninstalled (but the cached license certificate is not cleared).
     *
     * @deprecated <b>Experimental:</b> Methods marked with this note have
     *             been tested to be functional but may change or disappear
     *             at will in one of the next releases because they are still
     *             a topic for research on extended functionality.
     *             Most likely the methods will prevail however and this note
     *             will just vanish, so you may use them with a certain risk.
     */
    protected synchronized void setLicenseKey(final byte[] key) {
        final Preferences prefs = getLicenseParam().getPreferences();
        if (key != null)
            prefs.putByteArray(PREFERENCES_KEY, key);
        else
            prefs.remove(PREFERENCES_KEY);
    }

    /**
     * Stores the given license key to the given file.
     * 
     * @param key The license key
     *        - may <em>not</em> be <tt>null</tt>.
     * @param keyFile The file to save the license key to
     *        - may <em>not</em> be <tt>null</tt>.
     *        This should have a <tt>LICENSE_SUFFIX</tt>.
     * 
     * @throws Exception An instance of a subclass of this class for various
     *         reasons.
     */
    protected static void storeLicenseKey(
            final byte[] key,
            final File keyFile)
    throws IOException {
        final OutputStream out = new FileOutputStream(keyFile);
        try {
            out.write(key);
        }
        finally {
            try { out.close(); }
            catch (IOException weDontCare) { }
        }
    }

    /**
     * Loads and returns the first megabyte of content from <tt>keyFile</tt>
     * as license key in a newly created byte array.
     * 
     * @param keyFile The file holding the license key
     *        - may <em>not</em> be <tt>null</tt>.
     * 
     * @throws Exception An instance of a subclass of this class for various
     *         reasons.
     */
    protected static byte[] loadLicenseKey(final File keyFile)
    throws IOException {
        // Allow max 1MB size files and let the decrypter detect a partial read
        final int size = Math.min((int) keyFile.length(), 1024 * 1024);
        final InputStream in = new FileInputStream(keyFile);
        final byte[] b = new byte[size];
        try {
            // Let the verifier detect a partial read as an error
            in.read(b);
        }
        finally {
            try { in.close(); }
            catch (IOException weDontCare) { }
        }
        
        return b;
    }

    //
    // Various stuff.
    //

    /**
     * Returns a license notary configured to use the keystore parameters
     * contained in the current license parameters
     * - <tt>null</tt> is never returned.
     */
    protected synchronized LicenseNotary getLicenseNotary() {
        if (notary == null)
            notary = new LicenseNotary(getLicenseParam().getKeyStoreParam());
        
        return notary;
    }

    /**
     * Returns a privacy guard configured to use the cipher parameters
     * contained in the current license parameters
     * - <tt>null</tt> is never returned.
     */
    protected synchronized PrivacyGuard getPrivacyGuard() {
        if (guard == null)
            guard = new PrivacyGuard(getLicenseParam().getCipherParam());
        
        return guard;
    }

    /**
     * Returns a suitable file filter for the subject of this license manager.
     * On Windows systems, the case of the suffix is ignored when browsing
     * directories.
     *
     * @return A valid <tt>FileFilter</tt>.
     */
    public synchronized FileFilter getFileFilter() {
        if (fileFilter != null)
            return fileFilter;
        
        final String description
                = Resources.getString("fileFilter.description",
                    getLicenseParam().getSubject());
        if (File.separatorChar == '\\') {
            fileFilter = new FileFilter() {
                public boolean accept(File f) {
                    return f.isDirectory()
                        || f.getPath().toLowerCase().endsWith(LICENSE_SUFFIX);
                }

                public String getDescription() {
                    return description + " (*" + LICENSE_SUFFIX + ")"; // NOI18N
                }
            };
        } else {
            fileFilter = new FileFilter() {
                public boolean accept(File f) {
                    return f.isDirectory()
                        || f.getPath().endsWith(LICENSE_SUFFIX);
                }

                public String getDescription() {
                    return description + " (*" + LICENSE_SUFFIX + ")"; // NOI18N
                }
            };
        }
        
        return fileFilter;
    }
}
