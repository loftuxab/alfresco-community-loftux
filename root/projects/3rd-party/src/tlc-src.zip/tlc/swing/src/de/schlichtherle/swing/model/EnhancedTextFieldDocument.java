/*
 * EnhancedTextFieldDocument.java
 *
 * Created on 15. Dezember 2004, 19:36
 */

package de.schlichtherle.swing.model;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;

import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DocumentFilter;
import javax.swing.text.PlainDocument;

/**
 * Adds bound property <tt>editable</tt> to its base class and simple text
 * replacement methods.
 * <p>
 * This class is designed to be thread safe.
 *
 * @author  Christian Schlichtherle
 */
public class EnhancedTextFieldDocument extends PlainDocument {

    /** The effective document filter used for disabled text field documents. */
    protected static final DocumentFilter disabledFilter = new DocumentFilter() {
        public void replace(
                DocumentFilter.FilterBypass fb,
                int offset,
                int length,
                String text,
                AttributeSet attrs) {
        }

        public void insertString(
                DocumentFilter.FilterBypass fb,
                int offset,
                String string,
                AttributeSet attr) {
        }

        public void remove(
                DocumentFilter.FilterBypass fb,
                int offset,
                int length) {
        }
    };

    /** The name of the property <tt>editable</tt>. */
    public static final String PROPERTY_EDITABLE = "editable";
    
    private boolean editable = true;

    private DocumentFilter documentFilter;

    private PropertyChangeSupport changeSupport;
    
    public EnhancedTextFieldDocument() {
        documentFilter = getDocumentFilter();
    }
    
    public EnhancedTextFieldDocument(Content c) {
        super(c);
        documentFilter = getDocumentFilter();
    }
        
    public EnhancedTextFieldDocument(String str) {
        setText(str);
        documentFilter = getDocumentFilter();
    }
    
    public synchronized void setEditable(boolean newEditable) {
        boolean oldEditable = this.editable;
        if (oldEditable == newEditable)
            return;
        super.setDocumentFilter(newEditable ? documentFilter : disabledFilter);
        this.editable = newEditable;
        firePropertyChange(PROPERTY_EDITABLE, oldEditable, newEditable);
    }
    
    public boolean isEditable() {
        return editable;
    }

    /**
     * Replaces the entire text of this document model with the given string.
     */
    public synchronized void setText(String str) {
        try {
            replace(0, getLength(), str,  null);
        }
        catch (BadLocationException cannotHappen) { 
            throw new AssertionError(cannotHappen);
        }
    }

    /**
     * @return The entire text of this document model - never <tt>null</tt>.
     */
    public synchronized String getText() {
        try {
            return getText(0, getLength());
        }
        catch (BadLocationException cannotHappen) {
            throw new AssertionError(cannotHappen);
        }
    }

    /**
     * Identical to <tt>getText()</tt>.
     */
    public String toString() {
        return getText();
    }

    //
    // DocumentFilter support.
    //

    /**
     * Sets the <code>DocumentFilter</code>. The <code>DocumentFilter</code>
     * is passed <code>insert</code> and <code>remove</code> to conditionally
     * allow inserting/deleting of the text. A <code>null</code> value
     * indicates that no filtering will occur.
     *
     * @param filter The <code>DocumentFilter</code> used to constrain text.
     *
     * @see #getDocumentFilter
     */
    public void setDocumentFilter(DocumentFilter filter) {
        documentFilter = filter;
    }

    /**
     * Returns the <code>DocumentFilter</code> that is responsible for
     * filtering of insertion/removal. A <code>null</code> return value 
     * implies no filtering is to occur.
     *
     * @return The DocumentFilter.
     *
     * @see #setDocumentFilter
     */
    public DocumentFilter getDocumentFilter() {
        return documentFilter;
    }

    //
    // Property change support.
    // This is derived from javax.swing.JComponent, but does use
    // PropertyChangeSupport instead of SwingPropertyChangeSupport.
    //

    /**
     * Reports a bound property change.
     *
     * @param propertyName The programmatic name of the property
     *		that was changed.
     * @param oldValue The old value of the property (as a boolean).
     * @param newValue The new value of the property (as a boolean).
     *
     * @see #firePropertyChange(java.lang.String, boolean, boolean)
     */
    public void firePropertyChange(
            String propertyName,
            boolean oldValue,
            boolean newValue) {
        if ((changeSupport != null) && (oldValue != newValue))
            changeSupport.firePropertyChange(
                    propertyName,
                    Boolean.valueOf(oldValue),
                    Boolean.valueOf(newValue));
    }

    /**
     * Adds a <code>PropertyChangeListener</code> to the listener list.
     * The listener is registered for all properties.
     * <p>
     * A <code>PropertyChangeEvent</code> will get fired in response
     * to setting a bound property, such as <code>setFont</code>,
     * <code>setBackground</code>, or <code>setForeground</code>.
     * <p>
     * Note that if the current component is inheriting its foreground,
     * background, or font from its container, then no event will be
     * fired in response to a change in the inherited property.
     *
     * @param listener The <code>PropertyChangeListener</code> to be added.
     */
    public synchronized void addPropertyChangeListener(
            PropertyChangeListener listener) {
        if (changeSupport == null)
            changeSupport = new PropertyChangeSupport(this);
        changeSupport.addPropertyChangeListener(listener);
    }

    /**
     * Adds a <code>PropertyChangeListener</code> for a specific property.
     * The listener will be invoked only when a call on
     * <code>firePropertyChange</code> names that specific property.
     * <p>
     * If listener is <code>null</code>, no exception is thrown and no
     * action is performed.
     *
     * @param propertyName The name of the property to listen on.
     * @param listener The <code>PropertyChangeListener</code> to be added.
     */
    public synchronized void addPropertyChangeListener(
            String propertyName,
            PropertyChangeListener listener) {
	if (listener == null)
	    return;
	if (changeSupport == null)
	    changeSupport = new PropertyChangeSupport(this);
	changeSupport.addPropertyChangeListener(propertyName, listener);
    }

    /**
     * Removes a <code>PropertyChangeListener</code> from the listener list.
     * This removes a <code>PropertyChangeListener</code> that was registered
     * for all properties.
     *
     * @param listener The <code>PropertyChangeListener</code> to be removed.
     */
    public synchronized void removePropertyChangeListener(
            PropertyChangeListener listener) {
        if (changeSupport != null)
            changeSupport.removePropertyChangeListener(listener);
    }

    /**
     * Removes a <code>PropertyChangeListener</code> for a specific property.
     * If listener is <code>null</code>, no exception is thrown and no
     * action is performed.
     *
     * @param propertyName  the name of the property that was listened on
     * @param listener  the <code>PropertyChangeListener</code> to be removed
     */
    public synchronized void removePropertyChangeListener(
            String propertyName,
            PropertyChangeListener listener) {
	if (listener == null)
	    return;
	if (changeSupport == null)
	    return;
	changeSupport.removePropertyChangeListener(propertyName, listener);
    }
}