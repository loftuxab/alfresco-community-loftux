/*
 * EnhancedTextField.java
 *
 * Created on 7. Dezember 2005, 12:32
 */

package de.schlichtherle.swing;

import de.schlichtherle.swing.model.EnhancedTextFieldDocument;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import javax.swing.JTextField;
import javax.swing.text.Document;

/**
 * Like its super class, but pays attention to the property <tt>editable</tt>
 * of the class {@link de.schlichtherle.swing.model.EnhancedTextFieldDocument}
 * when used as its document model.
 *
 * @author Christian Schlichtherle
 */
public class EnhancedTextField extends JTextField {

    private final PropertyChangeListener listener = new PropertyChangeListener() {
        public void propertyChange(PropertyChangeEvent evt) {
            setEditable(!Boolean.FALSE.equals(evt.getNewValue()));
        }
    };

    public EnhancedTextField() {
    }

    public EnhancedTextField(String text) {
        super(text);
    }

    public EnhancedTextField(int columns) {
        super(columns);
    }

    public EnhancedTextField(String text, int columns) {
        super(text, columns);
    }

    public EnhancedTextField(Document doc, String text, int columns) {
        super(doc, text, columns);
    }

    public void setDocument(Document doc) {
        final Document old = super.getDocument();
        if (old instanceof EnhancedTextFieldDocument) {
            ((EnhancedTextFieldDocument) old).removePropertyChangeListener(
                    EnhancedTextFieldDocument.PROPERTY_EDITABLE, listener);
        }
        super.setDocument(doc);
        if (doc instanceof EnhancedTextFieldDocument) {
            final EnhancedTextFieldDocument edoc
                    = (EnhancedTextFieldDocument) doc;
            edoc.addPropertyChangeListener(
                    EnhancedTextFieldDocument.PROPERTY_EDITABLE, listener);
            setEditable(edoc.isEditable());
        }
    }
}
