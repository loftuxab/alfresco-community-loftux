package org.apache.myfaces.webapp.webxml;

/**
 * Created by IntelliJ IDEA.
 * User: Developer
 * Date: 06.09.2005
 * Time: 11:22:03
 * To change this template use File | Settings | File Templates.
 */
public interface DelegatedFacesServlet
{
}
