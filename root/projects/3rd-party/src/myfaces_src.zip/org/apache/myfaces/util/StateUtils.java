package org.apache.myfaces.util;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import javax.faces.FacesException;
import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.io.ObjectOutputStream;
import java.io.IOException;
import java.util.zip.GZIPOutputStream;

/**
 * Created by IntelliJ IDEA.
 * User: ich
 * Date: 11.08.2005
 * Time: 18:50:28
 * To change this template use File | Settings | File Templates.
 */
public class StateUtils {

    private static final Log log = LogFactory.getLog(StateUtils.class);

    public static final String ZIP_CHARSET = "ISO-8859-1";

    public static String encode64(Object obj)
    {
           try
           {
               ByteArrayOutputStream baos = new ByteArrayOutputStream();
               OutputStream zos = new GZIPOutputStream(baos);
               ObjectOutputStream oos = new ObjectOutputStream(zos);
               oos.writeObject(obj);
               oos.close();
               zos.close();
               baos.close();
               Base64 base64Codec = new Base64();
               return new String(base64Codec.encode( baos.toByteArray() ), ZIP_CHARSET);
           }
           catch (IOException e)
           {
               log.fatal("Cannot encode Object with Base64", e);
               throw new FacesException(e);
           }
       }
}
