package org.chiba.xml.xforms.test.performance;

import etm.core.configuration.BasicEtmConfigurator;
import etm.core.configuration.EtmManager;
import etm.core.monitor.EtmMonitor;
import etm.core.monitor.MeasurementPoint;
import etm.core.renderer.SimpleTextRenderer;
import etm.contrib.console.HttpConsoleServer;
import etm.contrib.renderer.SimpleHtmlRenderer;
import junit.framework.TestCase;
import org.chiba.xml.xforms.ChibaBean;
import org.chiba.xml.xforms.core.Model;
import org.chiba.xml.events.DOMEventNames;

import java.io.FileWriter;
import java.io.File;

/**
 * @author Ulrich Nicolas Liss&eacute;
 * @version $Id: PerformanceTest1.java,v 1.1 2006/11/10 14:46:27 joernt Exp $
 */
public class PerformanceTest1 extends TestCase {
//    static {
//        org.apache.log4j.BasicConfigurator.configure();
//    }

    private static EtmMonitor monitor;


    protected void setUp() throws Exception {
        BasicEtmConfigurator.configure(true);
        monitor = EtmManager.getEtmMonitor();
        monitor.start();

//        HttpConsoleServer server = new HttpConsoleServer(monitor);
//        server.start();
    }


    protected void tearDown() throws Exception {
        monitor.stop();
    }

    /**
     * Tests performance.
     *
     * @throws Exception if an error occurred during te test.
     */

    public void testInitPerformance() throws Exception {

        ChibaBean chibaBean;
        for (int i=0;i<10;i++){
            String path = getClass().getResource("performancetest1.xhtml").getPath();
            String baseURI = "file://" + path.substring(0, path.lastIndexOf("performancetest1.xhtml"));

            chibaBean = new ChibaBean();
            chibaBean.setBaseURI(baseURI);
            chibaBean.setXMLContainer(getClass().getResourceAsStream("performancetest1.xhtml"));
            chibaBean.init();
            chibaBean.dispatch("OKhider", DOMEventNames.ACTIVATE);
            chibaBean.shutdown();
        }
//        monitor.render(new SimpleHtmlRenderer(new FileWriter(new File("results.html"))));
        monitor.render(new SimpleTextRenderer());
    }

}
