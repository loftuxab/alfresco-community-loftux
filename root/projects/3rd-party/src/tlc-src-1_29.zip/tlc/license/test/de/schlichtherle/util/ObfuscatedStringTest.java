/*
 * ObfuscatedStringTest.java
 * JUnit based test
 *
 * Created on 16. Juni 2006, 13:48
 */
/*
 * Copyright 2006 Schlichtherle IT Services
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package de.schlichtherle.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import junit.framework.*;
import java.io.UnsupportedEncodingException;
import java.util.Random;

/**
 *
 * @author Christian Schlichtherle
 */
public class ObfuscatedStringTest extends TestCase {
    
    public ObfuscatedStringTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }

    /**
     * Test of obfuscate method, of class de.schlichtherle.util.ObfuscatedString.
     */
    public void testRoundTripConversion() {
        System.out.println("roundTripConversion");
        
        final String text = "Hello world!";
        final String result = ObfuscatedString.obfuscate(text);
        Pattern pattern = Pattern.compile(
                "^\\Qnew ObfuscatedString(new long[] {\\E(.*)\\Q}).toString() /* => \"" + text + "\" */\\E$",
                Pattern.DOTALL);
        Matcher matcher = pattern.matcher(result);
        assertTrue(matcher.matches());

        final String[] es = matcher.group(1).split("\\s*,\\s*");
        final long[] el = new long[es.length];
        for (int i = 0; i < el.length; i++) {
            String s = es[i].toUpperCase();
            assertTrue(s.startsWith("0X"));
            assertTrue(s.endsWith("L"));
            String n = s.substring(2, s.length() - 1);
            el[i] = parseLong(n);
        }
        
        assertEquals(text, new ObfuscatedString(el).toString());
    }

    /**
     * {@link Long#parseLong} doesn't work if the highest bit is set in the
     * string to parse. Hence we provide a simplified version here.
     */
    private static long parseLong(String s) throws NumberFormatException {
        final int l = s.length();
        if (l > 16) {
            throw new NumberFormatException(s);
        }

        long result = 0;
        for (int i = 0; i < l; i++) {
            final int digit = Character.digit(s.charAt(i), 16);
            if (digit < 0 || digit >= 16)
                throw new NumberFormatException("For input string: \"" + s + "\"");
            result *= 16;
            result += digit;
        }

        return result;
    }

    /**
     * Test of toString method, of class de.schlichtherle.util.ObfuscatedString.
     */
    public void testToString() {
        System.out.println("toString");
        
        // This string has been obfuscated with Sun's JDK 1.4.2_12 on the
        // Windows platform.
        // It must produce the same string across all Java implementations
        // and platforms.
        ObfuscatedString instance = new ObfuscatedString(new long[] {
            0x3D197100B60F42DEL, 0x22CF1D8622717853L, 0x478E5D578EE504B7L
        }); /* => "Hello world!" */
        
        String expResult = "Hello world!";
        String result = instance.toString();
        assertEquals(expResult, result);
    }
    
}
