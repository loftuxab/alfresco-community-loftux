/*
 * GenericCertificateTest.java
 * JUnit based test
 *
 * Created on 15. Juni 2005, 21:19
 */

package de.schlichtherle.xml;

import de.schlichtherle.license.*;
import java.awt.geom.GeneralPath;

import java.beans.*;
import java.io.*;
import java.lang.reflect.*;
import java.security.*;
import java.security.cert.*;
import java.util.*;

import junit.framework.*;

import org.apache.commons.codec.binary.Base64;

/**
 * @author Christian Schlichtherle
 */
public class GenericCertificateTest extends TestCase {
    
    protected static final KeyStoreParam keyStoreParam = new KeyStoreParam() {

        public InputStream getStream() throws IOException {
            final String resourceName = "/de/schlichtherle/xml/keystore";
            final InputStream in
                    = getClass().getResourceAsStream(resourceName);
            if (in == null)
                throw new FileNotFoundException(resourceName);
            return in;
        }

        public String getAlias() {
            return "mykey";
        }

        public String getStorePwd() {
            return "test1234";
        }

        public String getKeyPwd() {
            return "test1234";
        }
    };
    
    protected final LicenseNotary notary;
    protected GenericCertificate unsignedCert;
    protected GenericCertificate signedCert;
    protected final String content = "<signed content>";
    protected Listener listener;

    public GenericCertificateTest(String testName) throws Exception {
        super(testName);
        notary = new LicenseNotary(keyStoreParam);
    }

    protected void setUp() throws Exception {
        listener = new Listener();
        unsignedCert = new GenericCertificate();
        unsignedCert.addPropertyChangeListener(listener);
        signedCert = notary.sign(content);
        signedCert.addPropertyChangeListener(listener);
    }

    protected void tearDown() throws Exception {
        signedCert.removePropertyChangeListener(listener);
        unsignedCert.removePropertyChangeListener(listener);
        listener = null;
        signedCert = unsignedCert = null;
    }

    public static Test suite() {
        TestSuite suite = new TestSuite(GenericCertificateTest.class);
        
        return suite;
    }

    public void testCopyConstructor() throws Exception {
        System.out.println("testCopyConstructor");
        testCopy(unsignedCert, new GenericCertificate(unsignedCert));
        testCopy(signedCert, new GenericCertificate(signedCert));
    }
    
    /**
     * Test of sign method, of class de.schlichtherle.xml.GenericCertificate.
     */
    public void testSign() throws Exception {
        System.out.println("testSign");
        GenericCertificate cert = new GenericCertificate();
        cert.addPropertyChangeListener(listener);
        final VetoListener vetoer = new VetoListener();
        cert.addVetoableChangeListener(vetoer);
        try {
            notary.sign(cert, content);
            fail("Signing of certificate should have been vetoed!");
            return;
        }
        catch (PropertyVetoException ok) { }
        cert.removeVetoableChangeListener(vetoer);
        assertEquals(0, listener.getCount());
        notary.sign(cert, null);
        assertNotNull(cert.getEncoded());
        assertNotNull(cert.getSignature());
        assertNotNull(cert.getSignatureAlgorithm());
        assertNotNull(cert.getSignatureEncoding());
        assertTrue(cert.isLocked());
        assertEquals(5, listener.getCount()); // all properties have changed!
        String actual = (String) cert.getContent();
        assertNull(actual);
        try {
            notary.sign(cert, content);
            fail("Certificate has been signed twice!");
            return;
        }
        catch (Exception ok) { }
        try {
            notary.verify(cert);
            fail("A signed certificate has been redundantly verified!");
            return;
        }
        catch (Exception ok) { }
        try {
            cert.setEncoded("<illegal encoding>");
            fail("Failed to detect attempt to compromise certificate integrity!");
            return;
        }
        catch (Exception ok) { }
        try {
            cert.setSignature("<illegal signature>");
            fail("Failed to detect attempt to compromise certificate integrity!");
            return;
        }
        catch (Exception ok) { }
        try {
            cert.setSignatureAlgorithm("<illegal algorithm>");
            fail("Failed to detect attempt to compromise certificate integrity!");
            return;
        }
        catch (Exception ok) { }
        try {
            cert.setSignatureEncoding("<illegal encoding>");
            fail("Failed to detect attempt to compromise certificate integrity!");
            return;
        }
        catch (Exception ok) { }
    }

    /**
     * Test of verify method, of class de.schlichtherle.xml.GenericCertificate.
     */
    public void testVerify() throws Exception {
        System.out.println("testVerify");
        GenericCertificate cert = new GenericCertificate(signedCert);
        cert.addPropertyChangeListener(listener);
        final VetoListener vetoer = new VetoListener();
        cert.addVetoableChangeListener(vetoer);
        try {
            notary.verify(cert);
            fail("Verifying of certificate should have been vetoed!");
            return;
        }
        catch (PropertyVetoException ok) { }
        cert.removeVetoableChangeListener(vetoer);
        assertEquals(0, listener.getCount());
        notary.verify(cert);
        assertNotNull(cert.getEncoded());
        assertNotNull(cert.getSignature());
        assertNotNull(cert.getSignatureAlgorithm());
        assertNotNull(cert.getSignatureEncoding());
        assertTrue(cert.isLocked());
        assertEquals(1, listener.getCount()); // only the property locked has changed!
        String actual = (String) cert.getContent();
        assertNotNull(actual);
        assertNotSame(content, actual);
        assertEquals(content, actual);
        try {
            notary.sign(cert, null);
            fail("A verified certificate has been signed again!");
            return;
        }
        catch (Exception ok) { }
        try {
            notary.verify(cert);
            fail("Certificate has been verified twice!");
            return;
        }
        catch (Exception ok) { }
        try {
            cert.setEncoded("<illegal encoding>");
            fail("Failed to detect attempt to compromise certificate integrity!");
            return;
        }
        catch (Exception ok) { }
        try {
            cert.setSignature("<illegal signature>");
            fail("Failed to detect attempt to compromise certificate integrity!");
            return;
        }
        catch (Exception ok) { }
        try {
            cert.setSignatureAlgorithm("<illegal algorithm>");
            fail("Failed to detect attempt to compromise certificate integrity!");
            return;
        }
        catch (Exception ok) { }
        try {
            cert.setSignatureEncoding("<illegal encoding>");
            fail("Failed to detect attempt to compromise certificate integrity!");
            return;
        }
        catch (Exception ok) { }
    }

    /**
     * Test of isLocked method, of class de.schlichtherle.xml.GenericCertificate.
     */
    public void testIsLocked() {
        System.out.println("testIsLocked");
        assertFalse(unsignedCert.isLocked());
        assertTrue(signedCert.isLocked());
    }

    /**
     * Test of getObjectClone method, of class de.schlichtherle.xml.GenericCertificate.
     */
    public void testGetContentClone() throws Exception {
        System.out.println("testGetContentClone");
        String clone1 = (String) signedCert.getContent();
        assertNotNull(clone1);
        assertNotSame(content, clone1);
        assertEquals(content, clone1);
        String clone2 = (String) signedCert.getContent();
        assertNotNull(clone2);
        assertNotSame(content, clone2);
        assertEquals(content, clone2);
        assertNotSame(clone1, clone2);
        assertEquals(clone1, clone2);
        try {
            unsignedCert.getContent();
            fail("An unsigned generic certificate returned a content clone!");
            return;
        }
        catch (Exception ok) { }
    }

    /**
     * Test of getEncoded method, of class de.schlichtherle.xml.GenericCertificate.
     */
    public void testGetEncoded() {
        System.out.println("testGetEncoded");
        assertNull(unsignedCert.getEncoded());
        assertNotNull(signedCert.getEncoded());
    }

    /**
     * Test of setEncoded method, of class de.schlichtherle.xml.GenericCertificate.
     */
    public void testSetEncoded() throws Exception {
        System.out.println("testSetEncoded");
        unsignedCert.setEncoded(content);
        try {
            signedCert.setEncoded(content);
            fail("Property change should have been vetoed!");
            return;
        }
        catch (PropertyVetoException ok) { }
    }

    /**
     * Test of getSignature method, of class de.schlichtherle.xml.GenericCertificate.
     */
    public void testGetSignature() {
        System.out.println("testGetSignature");
        assertNull(unsignedCert.getSignature());
        assertNotNull(signedCert.getSignature());
    }

    /**
     * Test of setSignature method, of class de.schlichtherle.xml.GenericCertificate.
     */
    public void testSetSignature() throws Exception {
        System.out.println("testSetSignature");
        unsignedCert.setSignature(content);
        try {
            signedCert.setSignature(content);
            fail("Property change should have been vetoed!");
            return;
        }
        catch (PropertyVetoException ok) { }
    }

    /**
     * Test of getSignatureAlgorithm method, of class de.schlichtherle.xml.GenericCertificate.
     */
    public void testGetSignatureAlgorithm() {
        System.out.println("testGetSignatureAlgorithm");
        assertNull(unsignedCert.getSignatureAlgorithm());
        assertNotNull(signedCert.getSignatureAlgorithm());
    }

    /**
     * Test of setSignatureAlgorithm method, of class de.schlichtherle.xml.GenericCertificate.
     */
    public void testSetSignatureAlgorithm() throws Exception {
        System.out.println("testSetSignatureAlgorithm");
        unsignedCert.setSignatureAlgorithm(content);
        try {
            signedCert.setSignatureAlgorithm(content);
            fail("Property change should have been vetoed!");
            return;
        }
        catch (PropertyVetoException ok) { }
    }

    /**
     * Test of getSignatureEncoding method, of class de.schlichtherle.xml.GenericCertificate.
     */
    public void testGetSignatureEncoding() {
        System.out.println("testGetSignatureEncoding");
        assertNull(unsignedCert.getSignatureEncoding());
        assertNotNull(signedCert.getSignatureEncoding());
    }

    /**
     * Test of setSignatureEncoding method, of class de.schlichtherle.xml.GenericCertificate.
     */
    public void testSetSignatureEncoding() throws Exception {
        System.out.println("testSetSignatureEncoding");
        unsignedCert.setSignatureEncoding(content);
        try {
            signedCert.setSignatureEncoding(content);
            fail("Property change should have been vetoed!");
            return;
        }
        catch (PropertyVetoException ok) { }
    }

    /**
     * Test of removePropertyChangeListener method, of class de.schlichtherle.xml.GenericCertificate.
     */
    public void testPropertyChangeListener() throws Exception {
        System.out.println("testRemovePropertyChangeListener");
        unsignedCert.removePropertyChangeListener(listener);
        unsignedCert.setEncoded("<another illegal encoding>");
        assertEquals(0, listener.getCount());
    }
    
    /**
     * Tests if the (de)serialization with ObjectInput/OutputStream works.
     */
    public synchronized void testObjectStreamPersistence() throws Exception {
        System.out.println("testObjectStreamPersistence");
        testObjectStreamPersistence(unsignedCert);
        testObjectStreamPersistence(signedCert);
    }
    
    /**
     * Tests if the (de)serialization with ObjectInput/OutputStream works.
     */
    public synchronized void testObjectStreamPersistence(
            final GenericCertificate cert)
    throws Exception {
        final GenericCertificate cert2;
        final ByteArrayOutputStream bos = new ByteArrayOutputStream();
        final ObjectOutputStream oos = new ObjectOutputStream(bos);
        oos.writeObject(cert);
        oos.close();
        final ObjectInputStream ois = new ObjectInputStream(
                new ByteArrayInputStream(bos.toByteArray()));
        cert2 = (GenericCertificate) ois.readObject();
        ois.close();
        testCopy(cert, cert2);
    }
    
    /**
     * Tests if the (de)serialization with ObjectInput/OutputStream works.
     */
    public synchronized void testXMLPersistence() throws Exception {
        System.out.println("testXMLPersistence");
        testXMLPersistence(unsignedCert);
        testXMLPersistence(signedCert);
    }
    
    /**
     * Tests if the (de)serialization with ObjectInput/OutputStream works.
     */
    public synchronized void testXMLPersistence(
            final GenericCertificate cert)
    throws Exception {
        final byte[] buf = PersistenceService.store2ByteArray(cert);
        final GenericCertificate cert2 = (GenericCertificate) PersistenceService.load(buf);
        testCopy(cert, cert2);
    }

    protected synchronized void testCopy(
            final GenericCertificate original,
            final GenericCertificate copy)
    throws Exception {
        assertFalse(copy.isLocked());
        original.addVetoableChangeListener(new VetoListener());
        listener.resetStaticCount();
        if (original.isLocked()) {
            notary.verify(copy);
            assertEqualsButNotSame(original, copy);
            assertEquals(0, listener.getStaticCount()); // copy does not have listeners!
        } else {
            assertEqualsButNotSame(original, copy);
            original.setEncoded("x" + original.getEncoded());
            copy.setEncoded("x" + copy.getEncoded());
            assertEquals(1, listener.getStaticCount()); // only original has listeners!
        }
        try {
            notary.sign(original, content);
            fail("Signed an either locked or vetoed certificate!");
            return;
        }
        catch (PropertyVetoException ok) { }
    }

    protected void assertEqualsButNotSame(
            final GenericCertificate expected,
            final GenericCertificate actual)
    throws Exception {
        assertNotNull(expected);
        assertNotNull(actual);
        assertNotSame(expected, actual);
        //super.assertEquals(expected, actual); // no useful equals implemented for GenericCertificate!
        assertNullOrEquals(expected.getEncoded(), actual.getEncoded());
        assertNullOrEquals(expected.getSignature(), actual.getSignature());
        assertNullOrEquals(expected.getSignatureAlgorithm(), actual.getSignatureAlgorithm());
        assertNullOrEquals(expected.getSignatureEncoding(), actual.getSignatureEncoding());
        assertEquals(expected.isLocked(), actual.isLocked());
        if (expected.isLocked()) {
            assertEquals(expected.getContent(), actual.getContent());
        }
    }
    
    protected final void assertNullOrEquals(Object expected, Object actual) {
        if (expected != null || actual != null)
            assertEquals(expected, actual);
    }

    private static int staticCount;
    
    protected class Listener implements PropertyChangeListener {
        private int count;
        
        public int getCount() {
            return count;
        }

        public int getStaticCount() {
            return staticCount;
        }
        
        public void resetStaticCount() {
            staticCount = 0;
        }
        
        public synchronized void propertyChange(PropertyChangeEvent evt) {
            assertNotNull(evt);
            assertTrue(evt.getSource() instanceof GenericCertificate);
            count++;
            staticCount++;
        }
    }
    
    protected class VetoListener implements VetoableChangeListener {

        public synchronized void vetoableChange(PropertyChangeEvent evt)
        throws PropertyVetoException {
            throw new PropertyVetoException("Why? Just for testing!", evt);
        }
    }
}
