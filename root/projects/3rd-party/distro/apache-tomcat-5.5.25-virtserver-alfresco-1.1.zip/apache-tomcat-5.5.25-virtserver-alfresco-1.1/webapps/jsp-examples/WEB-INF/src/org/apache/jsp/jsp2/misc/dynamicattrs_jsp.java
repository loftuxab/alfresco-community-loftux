package org.apache.jsp.jsp2.misc;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;

public final class dynamicattrs_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static java.util.List _jspx_dependants;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("<!--\r\n Licensed to the Apache Software Foundation (ASF) under one or more\r\n  contributor license agreements.  See the NOTICE file distributed with\r\n  this work for additional information regarding copyright ownership.\r\n  The ASF licenses this file to You under the Apache License, Version 2.0\r\n  (the \"License\"); you may not use this file except in compliance with\r\n  the License.  You may obtain a copy of the License at\r\n\r\n      http://www.apache.org/licenses/LICENSE-2.0\r\n\r\n  Unless required by applicable law or agreed to in writing, software\r\n  distributed under the License is distributed on an \"AS IS\" BASIS,\r\n  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.\r\n  See the License for the specific language governing permissions and\r\n  limitations under the License.\r\n-->\r\n\r\n<html>\r\n  <head>\r\n    <title>JSP 2.0 Examples - Dynamic Attributes</title>\r\n  </head>\r\n  <body>\r\n    <h1>JSP 2.0 Examples - Dynamic Attributes</h1>\r\n    <hr>\r\n    <p>This JSP page invokes a custom tag that accepts a dynamic set \r\n");
      out.write("    of attributes.  The tag echoes the name and value of all attributes\r\n    passed to it.</p>\r\n    <hr>\r\n    <h2>Invocation 1 (six attributes)</h2>\r\n    <ul>\r\n      ");
      if (_jspx_meth_my_005fechoAttributes_005f0(_jspx_page_context))
        return;
      out.write("\r\n    </ul>\r\n    <h2>Invocation 2 (zero attributes)</h2>\r\n    <ul>\r\n      ");
      if (_jspx_meth_my_005fechoAttributes_005f1(_jspx_page_context))
        return;
      out.write("\r\n    </ul>\r\n    <h2>Invocation 3 (three attributes)</h2>\r\n    <ul>\r\n      ");
      if (_jspx_meth_my_005fechoAttributes_005f2(_jspx_page_context))
        return;
      out.write("\r\n    </ul>\r\n  </body>\r\n</html>\r\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          out.clearBuffer();
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }

  private boolean _jspx_meth_my_005fechoAttributes_005f0(PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  my:echoAttributes
    jsp2.examples.simpletag.EchoAttributesTag _jspx_th_my_005fechoAttributes_005f0 = new jsp2.examples.simpletag.EchoAttributesTag();
    _jspx_th_my_005fechoAttributes_005f0.setJspContext(_jspx_page_context);
    _jspx_th_my_005fechoAttributes_005f0.setDynamicAttribute(null, "x", new String("1"));
    _jspx_th_my_005fechoAttributes_005f0.setDynamicAttribute(null, "y", new String("2"));
    _jspx_th_my_005fechoAttributes_005f0.setDynamicAttribute(null, "z", new String("3"));
    _jspx_th_my_005fechoAttributes_005f0.setDynamicAttribute(null, "r", new String("red"));
    _jspx_th_my_005fechoAttributes_005f0.setDynamicAttribute(null, "g", new String("green"));
    _jspx_th_my_005fechoAttributes_005f0.setDynamicAttribute(null, "b", new String("blue"));
    _jspx_th_my_005fechoAttributes_005f0.doTag();
    return false;
  }

  private boolean _jspx_meth_my_005fechoAttributes_005f1(PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  my:echoAttributes
    jsp2.examples.simpletag.EchoAttributesTag _jspx_th_my_005fechoAttributes_005f1 = new jsp2.examples.simpletag.EchoAttributesTag();
    _jspx_th_my_005fechoAttributes_005f1.setJspContext(_jspx_page_context);
    _jspx_th_my_005fechoAttributes_005f1.doTag();
    return false;
  }

  private boolean _jspx_meth_my_005fechoAttributes_005f2(PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  my:echoAttributes
    jsp2.examples.simpletag.EchoAttributesTag _jspx_th_my_005fechoAttributes_005f2 = new jsp2.examples.simpletag.EchoAttributesTag();
    _jspx_th_my_005fechoAttributes_005f2.setJspContext(_jspx_page_context);
    _jspx_th_my_005fechoAttributes_005f2.setDynamicAttribute(null, "dogName", new String("Scruffy"));
    _jspx_th_my_005fechoAttributes_005f2.setDynamicAttribute(null, "catName", new String("Fluffy"));
    _jspx_th_my_005fechoAttributes_005f2.setDynamicAttribute(null, "blowfishName", new String("Puffy"));
    _jspx_th_my_005fechoAttributes_005f2.doTag();
    return false;
  }
}
