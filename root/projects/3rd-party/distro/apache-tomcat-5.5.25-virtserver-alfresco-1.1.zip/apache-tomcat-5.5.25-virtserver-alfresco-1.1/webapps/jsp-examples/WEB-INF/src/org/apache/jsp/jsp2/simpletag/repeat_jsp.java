package org.apache.jsp.jsp2.simpletag;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;

public final class repeat_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static java.util.List _jspx_dependants;

  static {
    _jspx_dependants = new java.util.ArrayList(1);
    _jspx_dependants.add("/WEB-INF/jsp2/jsp2-example-taglib.tld");
  }

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("<!--\r\n Licensed to the Apache Software Foundation (ASF) under one or more\r\n  contributor license agreements.  See the NOTICE file distributed with\r\n  this work for additional information regarding copyright ownership.\r\n  The ASF licenses this file to You under the Apache License, Version 2.0\r\n  (the \"License\"); you may not use this file except in compliance with\r\n  the License.  You may obtain a copy of the License at\r\n\r\n      http://www.apache.org/licenses/LICENSE-2.0\r\n\r\n  Unless required by applicable law or agreed to in writing, software\r\n  distributed under the License is distributed on an \"AS IS\" BASIS,\r\n  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.\r\n  See the License for the specific language governing permissions and\r\n  limitations under the License.\r\n-->\r\n\r\n<html>\r\n  <head>\r\n    <title>JSP 2.0 Examples - Repeat SimpleTag Handler</title>\r\n  </head>\r\n  <body>\r\n    <h1>JSP 2.0 Examples - Repeat SimpleTag Handler</h1>\r\n    <hr>\r\n    <p>This tag handler accepts a \"num\" parameter and repeats the body of the\r\n");
      out.write("    tag \"num\" times.  It's a simple example, but the implementation of \r\n    such a tag in JSP 2.0 is substantially simpler than the equivalent \r\n    JSP 1.2-style classic tag handler.</p>\r\n    <p>The body of the tag is encapsulated in a \"JSP Fragment\" and passed\r\n    to the tag handler, which then executes it five times, inside a \r\n    for loop.  The tag handler passes in the current invocation in a\r\n    scoped variable called count, which can be accessed using the EL.</p>\r\n    <br>\r\n    <b><u>Result:</u></b><br>\r\n    ");
      //  mytag:repeat
      jsp2.examples.simpletag.RepeatSimpleTag _jspx_th_mytag_005frepeat_005f0 = new jsp2.examples.simpletag.RepeatSimpleTag();
      _jspx_th_mytag_005frepeat_005f0.setJspContext(_jspx_page_context);
      _jspx_th_mytag_005frepeat_005f0.setNum(5);
      _jspx_th_mytag_005frepeat_005f0.setJspBody(new repeat_jspHelper( 0, _jspx_page_context, _jspx_th_mytag_005frepeat_005f0, null));
      _jspx_th_mytag_005frepeat_005f0.doTag();
      out.write("\r\n  </body>\r\n</html>\r\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          out.clearBuffer();
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }

  private class repeat_jspHelper
      extends org.apache.jasper.runtime.JspFragmentHelper
  {
    private javax.servlet.jsp.tagext.JspTag _jspx_parent;
    private int[] _jspx_push_body_count;

    public repeat_jspHelper( int discriminator, JspContext jspContext, javax.servlet.jsp.tagext.JspTag _jspx_parent, int[] _jspx_push_body_count ) {
      super( discriminator, jspContext, _jspx_parent );
      this._jspx_parent = _jspx_parent;
      this._jspx_push_body_count = _jspx_push_body_count;
    }
    public void invoke0( JspWriter out ) 
      throws Throwable
    {
      out.write("\r\n      Invocation ");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${count}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write(" of 5<br>\r\n    ");
      return;
    }
    public void invoke( java.io.Writer writer )
      throws JspException
    {
      JspWriter out = null;
      if( writer != null ) {
        out = this.jspContext.pushBody(writer);
      } else {
        out = this.jspContext.getOut();
      }
      try {
        switch( this.discriminator ) {
          case 0:
            invoke0( out );
            break;
        }
      }
      catch( Throwable e ) {
        if (e instanceof SkipPageException)
            throw (SkipPageException) e;
        throw new JspException( e );
      }
      finally {
        if( writer != null ) {
          this.jspContext.popBody();
        }
      }
    }
  }
}
