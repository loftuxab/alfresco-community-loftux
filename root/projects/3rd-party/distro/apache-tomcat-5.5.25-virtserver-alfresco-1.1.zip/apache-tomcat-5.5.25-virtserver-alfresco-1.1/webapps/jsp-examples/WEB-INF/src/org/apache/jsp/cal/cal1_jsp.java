package org.apache.jsp.cal;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import cal.*;

public final class cal1_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static java.util.List _jspx_dependants;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("<HTML>\r\n<!--\r\n Licensed to the Apache Software Foundation (ASF) under one or more\r\n  contributor license agreements.  See the NOTICE file distributed with\r\n  this work for additional information regarding copyright ownership.\r\n  The ASF licenses this file to You under the Apache License, Version 2.0\r\n  (the \"License\"); you may not use this file except in compliance with\r\n  the License.  You may obtain a copy of the License at\r\n\r\n      http://www.apache.org/licenses/LICENSE-2.0\r\n\r\n  Unless required by applicable law or agreed to in writing, software\r\n  distributed under the License is distributed on an \"AS IS\" BASIS,\r\n  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.\r\n  See the License for the specific language governing permissions and\r\n  limitations under the License.\r\n-->\r\n<HEAD><TITLE> \r\n\tCalendar: A JSP APPLICATION\r\n</TITLE></HEAD>\r\n\r\n\r\n<BODY BGCOLOR=\"white\">\r\n\r\n\r\n");
      cal.TableBean table = null;
      synchronized (session) {
        table = (cal.TableBean) _jspx_page_context.getAttribute("table", PageContext.SESSION_SCOPE);
        if (table == null){
          table = new cal.TableBean();
          _jspx_page_context.setAttribute("table", table, PageContext.SESSION_SCOPE);
        }
      }
      out.write("\r\n\r\n");

	table.processRequest(request);
	if (table.getProcessError() == false) {

      out.write("\r\n\r\n<!-- html table goes here -->\r\n<CENTER>\r\n<TABLE WIDTH=60% BGCOLOR=yellow CELLPADDING=15>\r\n<TR>\r\n<TD ALIGN=CENTER> <A HREF=cal1.jsp?date=prev> prev </A>\r\n<TD ALIGN=CENTER> Calendar:");
      out.print( table.getDate() );
      out.write("</TD>\r\n<TD ALIGN=CENTER> <A HREF=cal1.jsp?date=next> next </A>\r\n</TR>\r\n</TABLE>\r\n\r\n<!-- the main table -->\r\n<TABLE WIDTH=60% BGCOLOR=lightblue BORDER=1 CELLPADDING=10>\r\n<TR>\r\n<TH> Time </TH>\r\n<TH> Appointment </TH>\r\n</TR>\r\n<FORM METHOD=POST ACTION=cal1.jsp>\r\n");

	for(int i=0; i<table.getEntries().getRows(); i++) {
	   cal.Entry entr = table.getEntries().getEntry(i);	

      out.write("\r\n\t<TR>\r\n\t<TD> \r\n\t<A HREF=cal2.jsp?time=");
      out.print( entr.getHour() );
      out.write(">\r\n\t\t");
      out.print( entr.getHour() );
      out.write(" </A>\r\n\t</TD>\r\n\t<TD BGCOLOR=");
      out.print( entr.getColor() );
      out.write(">\r\n\t");
 out.print(util.HTMLFilter.filter(entr.getDescription())); 
      out.write("\r\n\t</TD> \r\n\t</TR>\r\n");

	}

      out.write("\r\n</FORM>\r\n</TABLE>\r\n<BR>\r\n\r\n<!-- footer -->\r\n<TABLE WIDTH=60% BGCOLOR=yellow CELLPADDING=15>\r\n<TR>\r\n<TD ALIGN=CENTER>  ");
 out.print(util.HTMLFilter.filter(table.getName())); 
      out.write(" : \r\n\t\t     ");
 out.print(util.HTMLFilter.filter(table.getEmail())); 
      out.write(" </TD>\r\n</TR>\r\n</TABLE>\r\n</CENTER>\r\n\r\n");

	} else {

      out.write("\r\n<font size=5>\r\n\tYou must enter your name and email address correctly.\r\n</font>\r\n");

	}

      out.write("\r\n\r\n\r\n</BODY>\r\n</HTML>\r\n\r\n\r\n\r\n\r\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          out.clearBuffer();
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
