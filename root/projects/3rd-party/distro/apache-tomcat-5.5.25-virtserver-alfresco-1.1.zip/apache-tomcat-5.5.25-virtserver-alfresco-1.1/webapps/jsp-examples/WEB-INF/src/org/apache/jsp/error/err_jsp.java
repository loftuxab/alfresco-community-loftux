package org.apache.jsp.error;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;

public final class err_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static java.util.List _jspx_dependants;

  static {
    _jspx_dependants = new java.util.ArrayList(1);
    _jspx_dependants.add("/error/error.html");
  }

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			"errorpge.jsp", true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("<html>\r\n<!--\r\n Licensed to the Apache Software Foundation (ASF) under one or more\r\n  contributor license agreements.  See the NOTICE file distributed with\r\n  this work for additional information regarding copyright ownership.\r\n  The ASF licenses this file to You under the Apache License, Version 2.0\r\n  (the \"License\"); you may not use this file except in compliance with\r\n  the License.  You may obtain a copy of the License at\r\n\r\n      http://www.apache.org/licenses/LICENSE-2.0\r\n\r\n  Unless required by applicable law or agreed to in writing, software\r\n  distributed under the License is distributed on an \"AS IS\" BASIS,\r\n  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.\r\n  See the License for the specific language governing permissions and\r\n  limitations under the License.\r\n-->\r\n<body bgcolor=\"lightblue\">\r\n\r\n\t\r\n\t");
      error.Smart foo = null;
      synchronized (request) {
        foo = (error.Smart) _jspx_page_context.getAttribute("foo", PageContext.REQUEST_SCOPE);
        if (foo == null){
          foo = new error.Smart();
          _jspx_page_context.setAttribute("foo", foo, PageContext.REQUEST_SCOPE);
        }
      }
      out.write('\r');
      out.write('\n');
      out.write('	');
 
		String name = null;

		if (request.getParameter("name") == null) {
	
      out.write('\r');
      out.write('\n');
      out.write('	');
      out.write("<html>\r\n<!--\r\n Licensed to the Apache Software Foundation (ASF) under one or more\r\n  contributor license agreements.  See the NOTICE file distributed with\r\n  this work for additional information regarding copyright ownership.\r\n  The ASF licenses this file to You under the Apache License, Version 2.0\r\n  (the \"License\"); you may not use this file except in compliance with\r\n  the License.  You may obtain a copy of the License at\r\n\r\n      http://www.apache.org/licenses/LICENSE-2.0\r\n\r\n  Unless required by applicable law or agreed to in writing, software\r\n  distributed under the License is distributed on an \"AS IS\" BASIS,\r\n  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.\r\n  See the License for the specific language governing permissions and\r\n  limitations under the License.\r\n-->\r\n\r\n<body bgcolor=\"white\">\r\n\r\n<h1> This example uses <b>errorpage</b> directive </h1>\r\n<br>\r\n<h3> Select my favourite car.</h3>\r\n<form method=get action=err.jsp>\r\n<!-- <br> Make a guess: -->\r\n<SELECT NAME=\"name\" SIZE=5>\r\n");
      out.write("<OPTION VALUE=\"integra\"> Acura Integra <BR>\r\n<OPTION VALUE=\"bmw328i\"> BMW 328I <BR>\r\n<OPTION VALUE=\"z3\"> BMW Z3 <BR>\r\n<OPTION VALUE=\"infiniti\"> InfinitiQ3 <BR>\r\n<OPTION VALUE=\"audi\"> Audi A8 <BR>\r\n</SELECT>\r\n<br> <INPUT TYPE=submit name=submit Value=\"Submit\">\r\n</form>\r\n\r\n</body>\r\n</html>\r\n");
      out.write('\r');
      out.write('\n');
      out.write('	');

		} else {
		  foo.setName(request.getParameter("name"));
		  if (foo.getName().equalsIgnoreCase("integra"))
		  	name = "acura";
		  if (name.equalsIgnoreCase("acura")) {
	
      out.write("\r\n\r\n\t<H1> Yes!!! <a href=\"http://www.acura.com\">Acura</a> is my favorite car.\r\n\r\n\t");
 
		  }
		}	
	
      out.write("\t\r\n</body>\r\n</html>\r\n\r\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          out.clearBuffer();
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
