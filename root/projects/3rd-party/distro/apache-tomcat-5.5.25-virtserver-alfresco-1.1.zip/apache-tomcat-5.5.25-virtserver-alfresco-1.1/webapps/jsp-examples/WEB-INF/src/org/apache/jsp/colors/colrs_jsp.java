package org.apache.jsp.colors;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;

public final class colrs_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static java.util.List _jspx_dependants;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("<html>\r\n<!--\r\n Licensed to the Apache Software Foundation (ASF) under one or more\r\n  contributor license agreements.  See the NOTICE file distributed with\r\n  this work for additional information regarding copyright ownership.\r\n  The ASF licenses this file to You under the Apache License, Version 2.0\r\n  (the \"License\"); you may not use this file except in compliance with\r\n  the License.  You may obtain a copy of the License at\r\n\r\n      http://www.apache.org/licenses/LICENSE-2.0\r\n\r\n  Unless required by applicable law or agreed to in writing, software\r\n  distributed under the License is distributed on an \"AS IS\" BASIS,\r\n  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.\r\n  See the License for the specific language governing permissions and\r\n  limitations under the License.\r\n-->\r\n\r\n");
      colors.ColorGameBean cb = null;
      synchronized (session) {
        cb = (colors.ColorGameBean) _jspx_page_context.getAttribute("cb", PageContext.SESSION_SCOPE);
        if (cb == null){
          cb = new colors.ColorGameBean();
          _jspx_page_context.setAttribute("cb", cb, PageContext.SESSION_SCOPE);
        }
      }
      out.write('\r');
      out.write('\n');
      org.apache.jasper.runtime.JspRuntimeLibrary.introspect(_jspx_page_context.findAttribute("cb"), request);
      out.write("\r\n\r\n");

	cb.processRequest(request);

      out.write("\r\n\r\n<body bgcolor=");
      out.print( cb.getColor1() );
      out.write(">\r\n<font size=6 color=");
      out.print( cb.getColor2() );
      out.write(">\r\n<p>\r\n\r\n");
 if (cb.getHint()==true) { 
      out.write("\r\n\t\r\n\t<p> Hint #1: Vampires prey at night!\r\n\t<p>  <p> Hint #2: Nancy without the n.\r\n\r\n");
 } 
      out.write("\r\n\r\n");
 if  (cb.getSuccess()==true) { 
      out.write("\r\n\r\n    <p> CONGRATULATIONS!!\r\n\t");
 if  (cb.getHintTaken()==true) { 
      out.write("\r\n    \r\n        <p> ( although I know you cheated and peeked into the hints)\r\n\r\n\t");
 } 
      out.write("\r\n\r\n");
 } 
      out.write("\r\n\r\n<p> Total attempts so far: ");
      out.print( cb.getAttempts() );
      out.write("\r\n<p>\r\n\r\n<p>\r\n\r\n<form method=POST action=colrs.jsp>\r\n\r\nColor #1: <input type=text name= color1 size=16>\r\n\r\n<br>\r\n\r\nColor #2: <input type=text name= color2 size=16>\r\n\r\n<p>\r\n\r\n<input type=submit name=action value=\"Submit\">\r\n<input type=submit name=action value=\"Hint\">\r\n\r\n</form>\r\n\r\n</font>\r\n</body>\r\n</html>\r\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          out.clearBuffer();
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
