package org.apache.jsp.sessions;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;

public final class carts_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static java.util.List _jspx_dependants;

  static {
    _jspx_dependants = new java.util.ArrayList(1);
    _jspx_dependants.add("/sessions/carts.html");
  }

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("<html>\r\n<!--\r\n Licensed to the Apache Software Foundation (ASF) under one or more\r\n  contributor license agreements.  See the NOTICE file distributed with\r\n  this work for additional information regarding copyright ownership.\r\n  The ASF licenses this file to You under the Apache License, Version 2.0\r\n  (the \"License\"); you may not use this file except in compliance with\r\n  the License.  You may obtain a copy of the License at\r\n\r\n      http://www.apache.org/licenses/LICENSE-2.0\r\n\r\n  Unless required by applicable law or agreed to in writing, software\r\n  distributed under the License is distributed on an \"AS IS\" BASIS,\r\n  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.\r\n  See the License for the specific language governing permissions and\r\n  limitations under the License.\r\n-->\r\n\r\n");
      sessions.DummyCart cart = null;
      synchronized (session) {
        cart = (sessions.DummyCart) _jspx_page_context.getAttribute("cart", PageContext.SESSION_SCOPE);
        if (cart == null){
          cart = new sessions.DummyCart();
          _jspx_page_context.setAttribute("cart", cart, PageContext.SESSION_SCOPE);
        }
      }
      out.write("\r\n\r\n");
      org.apache.jasper.runtime.JspRuntimeLibrary.introspect(_jspx_page_context.findAttribute("cart"), request);
      out.write('\r');
      out.write('\n');

	cart.processRequest();

      out.write("\r\n\r\n\r\n<FONT size = 5 COLOR=\"#CC0000\">\r\n<br> You have the following items in your cart:\r\n<ol>\r\n");
 
	String[] items = cart.getItems();
	for (int i=0; i<items.length; i++) {

      out.write("\r\n<li> ");
 out.print(util.HTMLFilter.filter(items[i])); 
      out.write(' ');
      out.write('\r');
      out.write('\n');

	}

      out.write("\r\n</ol>\r\n\r\n</FONT>\r\n\r\n<hr>\r\n");
      out.write("<html>\r\n<!--\r\n Licensed to the Apache Software Foundation (ASF) under one or more\r\n  contributor license agreements.  See the NOTICE file distributed with\r\n  this work for additional information regarding copyright ownership.\r\n  The ASF licenses this file to You under the Apache License, Version 2.0\r\n  (the \"License\"); you may not use this file except in compliance with\r\n  the License.  You may obtain a copy of the License at\r\n\r\n      http://www.apache.org/licenses/LICENSE-2.0\r\n\r\n  Unless required by applicable law or agreed to in writing, software\r\n  distributed under the License is distributed on an \"AS IS\" BASIS,\r\n  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.\r\n  See the License for the specific language governing permissions and\r\n  limitations under the License.\r\n-->\r\n\r\n<head>\r\n    <title>carts</title>\r\n</head>\r\n\r\n <body bgcolor=\"white\">\r\n<font size = 5 color=\"#CC0000\">\r\n\r\n<form type=POST action=carts.jsp>\r\n<BR>\r\nPlease enter item to add or remove:\r\n<br>\r\nAdd Item:\r\n\r\n<SELECT NAME=\"item\">\r\n");
      out.write("<OPTION>Beavis & Butt-head Video collection\r\n<OPTION>X-files movie\r\n<OPTION>Twin peaks tapes\r\n<OPTION>NIN CD\r\n<OPTION>JSP Book\r\n<OPTION>Concert tickets\r\n<OPTION>Love life\r\n<OPTION>Switch blade\r\n<OPTION>Rex, Rugs & Rock n' Roll\r\n</SELECT>\r\n\r\n\r\n<br> <br>\r\n<INPUT TYPE=submit name=\"submit\" value=\"add\">\r\n<INPUT TYPE=submit name=\"submit\" value=\"remove\">\r\n\r\n</form>\r\n       \r\n</FONT>\r\n</body>\r\n</html>\r\n");
      out.write("\r\n</html>\r\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          out.clearBuffer();
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
