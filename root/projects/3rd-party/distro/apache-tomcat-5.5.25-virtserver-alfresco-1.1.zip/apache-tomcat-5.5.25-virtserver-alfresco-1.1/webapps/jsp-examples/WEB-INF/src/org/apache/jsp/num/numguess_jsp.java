package org.apache.jsp.num;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import num.NumberGuessBean;

public final class numguess_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static java.util.List _jspx_dependants;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("<!--\r\n Licensed to the Apache Software Foundation (ASF) under one or more\r\n  contributor license agreements.  See the NOTICE file distributed with\r\n  this work for additional information regarding copyright ownership.\r\n  The ASF licenses this file to You under the Apache License, Version 2.0\r\n  (the \"License\"); you may not use this file except in compliance with\r\n  the License.  You may obtain a copy of the License at\r\n\r\n      http://www.apache.org/licenses/LICENSE-2.0\r\n\r\n  Unless required by applicable law or agreed to in writing, software\r\n  distributed under the License is distributed on an \"AS IS\" BASIS,\r\n  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.\r\n  See the License for the specific language governing permissions and\r\n  limitations under the License.\r\n\r\n  Number Guess Game\r\n  Written by Jason Hunter, CTO, K&A Software\r\n  http://www.servlets.com\r\n-->\r\n\r\n\r\n\r\n");
      num.NumberGuessBean numguess = null;
      synchronized (session) {
        numguess = (num.NumberGuessBean) _jspx_page_context.getAttribute("numguess", PageContext.SESSION_SCOPE);
        if (numguess == null){
          numguess = new num.NumberGuessBean();
          _jspx_page_context.setAttribute("numguess", numguess, PageContext.SESSION_SCOPE);
        }
      }
      out.write('\r');
      out.write('\n');
      org.apache.jasper.runtime.JspRuntimeLibrary.introspect(_jspx_page_context.findAttribute("numguess"), request);
      out.write("\r\n\r\n<html>\r\n<head><title>Number Guess</title></head>\r\n<body bgcolor=\"white\">\r\n<font size=4>\r\n\r\n");
 if (numguess.getSuccess()) { 
      out.write("\r\n\r\n  Congratulations!  You got it.\r\n  And after just ");
      out.print( numguess.getNumGuesses() );
      out.write(" tries.<p>\r\n\r\n  ");
 numguess.reset(); 
      out.write("\r\n\r\n  Care to <a href=\"numguess.jsp\">try again</a>?\r\n\r\n");
 } else if (numguess.getNumGuesses() == 0) { 
      out.write("\r\n\r\n  Welcome to the Number Guess game.<p>\r\n\r\n  I'm thinking of a number between 1 and 100.<p>\r\n\r\n  <form method=get>\r\n  What's your guess? <input type=text name=guess>\r\n  <input type=submit value=\"Submit\">\r\n  </form>\r\n\r\n");
 } else { 
      out.write("\r\n\r\n  Good guess, but nope.  Try <b>");
      out.print( numguess.getHint() );
      out.write("</b>.\r\n\r\n  You have made ");
      out.print( numguess.getNumGuesses() );
      out.write(" guesses.<p>\r\n\r\n  I'm thinking of a number between 1 and 100.<p>\r\n\r\n  <form method=get>\r\n  What's your guess? <input type=text name=guess>\r\n  <input type=submit value=\"Submit\">\r\n  </form>\r\n\r\n");
 } 
      out.write("\r\n\r\n</font>\r\n</body>\r\n</html>\r\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          out.clearBuffer();
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
