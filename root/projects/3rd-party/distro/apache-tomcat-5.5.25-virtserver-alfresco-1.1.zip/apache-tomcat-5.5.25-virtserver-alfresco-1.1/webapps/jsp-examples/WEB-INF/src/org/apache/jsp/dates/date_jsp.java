package org.apache.jsp.dates;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;

public final class date_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static java.util.List _jspx_dependants;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    PageContext pageContext = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, false, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("<html>\r\n<!--\r\n Licensed to the Apache Software Foundation (ASF) under one or more\r\n  contributor license agreements.  See the NOTICE file distributed with\r\n  this work for additional information regarding copyright ownership.\r\n  The ASF licenses this file to You under the Apache License, Version 2.0\r\n  (the \"License\"); you may not use this file except in compliance with\r\n  the License.  You may obtain a copy of the License at\r\n\r\n      http://www.apache.org/licenses/LICENSE-2.0\r\n\r\n  Unless required by applicable law or agreed to in writing, software\r\n  distributed under the License is distributed on an \"AS IS\" BASIS,\r\n  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.\r\n  See the License for the specific language governing permissions and\r\n  limitations under the License.\r\n-->\r\n\r\n\r\n\r\n<body bgcolor=\"white\">\r\n");
      dates.JspCalendar clock = null;
      synchronized (_jspx_page_context) {
        clock = (dates.JspCalendar) _jspx_page_context.getAttribute("clock", PageContext.PAGE_SCOPE);
        if (clock == null){
          clock = new dates.JspCalendar();
          _jspx_page_context.setAttribute("clock", clock, PageContext.PAGE_SCOPE);
        }
      }
      out.write("\r\n\r\n<font size=4>\r\n<ul>\r\n<li>\tDay of month: is  ");
      out.write(org.apache.jasper.runtime.JspRuntimeLibrary.toString((((dates.JspCalendar)_jspx_page_context.findAttribute("clock")).getDayOfMonth())));
      out.write("\r\n<li>\tYear: is  ");
      out.write(org.apache.jasper.runtime.JspRuntimeLibrary.toString((((dates.JspCalendar)_jspx_page_context.findAttribute("clock")).getYear())));
      out.write("\r\n<li>\tMonth: is  ");
      out.write(org.apache.jasper.runtime.JspRuntimeLibrary.toString((((dates.JspCalendar)_jspx_page_context.findAttribute("clock")).getMonth())));
      out.write("\r\n<li>\tTime: is  ");
      out.write(org.apache.jasper.runtime.JspRuntimeLibrary.toString((((dates.JspCalendar)_jspx_page_context.findAttribute("clock")).getTime())));
      out.write("\r\n<li>\tDate: is  ");
      out.write(org.apache.jasper.runtime.JspRuntimeLibrary.toString((((dates.JspCalendar)_jspx_page_context.findAttribute("clock")).getDate())));
      out.write("\r\n<li>\tDay: is  ");
      out.write(org.apache.jasper.runtime.JspRuntimeLibrary.toString((((dates.JspCalendar)_jspx_page_context.findAttribute("clock")).getDay())));
      out.write("\r\n<li>\tDay Of Year: is  ");
      out.write(org.apache.jasper.runtime.JspRuntimeLibrary.toString((((dates.JspCalendar)_jspx_page_context.findAttribute("clock")).getDayOfYear())));
      out.write("\r\n<li>\tWeek Of Year: is  ");
      out.write(org.apache.jasper.runtime.JspRuntimeLibrary.toString((((dates.JspCalendar)_jspx_page_context.findAttribute("clock")).getWeekOfYear())));
      out.write("\r\n<li>\tera: is  ");
      out.write(org.apache.jasper.runtime.JspRuntimeLibrary.toString((((dates.JspCalendar)_jspx_page_context.findAttribute("clock")).getEra())));
      out.write("\r\n<li>\tDST Offset: is  ");
      out.write(org.apache.jasper.runtime.JspRuntimeLibrary.toString((((dates.JspCalendar)_jspx_page_context.findAttribute("clock")).getDSTOffset())));
      out.write("\r\n<li>\tZone Offset: is  ");
      out.write(org.apache.jasper.runtime.JspRuntimeLibrary.toString((((dates.JspCalendar)_jspx_page_context.findAttribute("clock")).getZoneOffset())));
      out.write("\r\n</ul>\r\n</font>\r\n\r\n</body>\r\n</html>\r\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          out.clearBuffer();
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
