package org.apache.jsp.jsp2.tagfiles;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;

public final class panel_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static java.util.List _jspx_dependants;

  static {
    _jspx_dependants = new java.util.ArrayList(1);
    _jspx_dependants.add("/WEB-INF/tags/panel.tag");
  }

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("<!--\r\n Licensed to the Apache Software Foundation (ASF) under one or more\r\n  contributor license agreements.  See the NOTICE file distributed with\r\n  this work for additional information regarding copyright ownership.\r\n  The ASF licenses this file to You under the Apache License, Version 2.0\r\n  (the \"License\"); you may not use this file except in compliance with\r\n  the License.  You may obtain a copy of the License at\r\n\r\n      http://www.apache.org/licenses/LICENSE-2.0\r\n\r\n  Unless required by applicable law or agreed to in writing, software\r\n  distributed under the License is distributed on an \"AS IS\" BASIS,\r\n  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.\r\n  See the License for the specific language governing permissions and\r\n  limitations under the License.\r\n-->\r\n\r\n<html>\r\n  <head>\r\n    <title>JSP 2.0 Examples - Panels using Tag Files</title>\r\n  </head>\r\n  <body>\r\n    <h1>JSP 2.0 Examples - Panels using Tag Files</h1>\r\n    <hr>\r\n    <p>This JSP page invokes a custom tag that draws a \r\n");
      out.write("    panel around the contents of the tag body.  Normally, such a tag \r\n    implementation would require a Java class with many println() statements,\r\n    outputting HTML.  Instead, we can use a .tag file as a template,\r\n    and we don't need to write a single line of Java or even a TLD!</p>\r\n    <hr>\r\n    <table border=\"0\">\r\n      <tr valign=\"top\">\r\n        <td>\r\n          ");
      if (_jspx_meth_tags_005fpanel_005f0(_jspx_page_context))
        return;
      out.write("\r\n        </td>\r\n        <td>\r\n          ");
      if (_jspx_meth_tags_005fpanel_005f1(_jspx_page_context))
        return;
      out.write("\r\n        </td>\r\n        <td>\r\n          ");
      if (_jspx_meth_tags_005fpanel_005f2(_jspx_page_context))
        return;
      out.write("\r\n        </td>\r\n      </tr>\r\n    </table>\r\n  </body>\r\n</html>\r\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          out.clearBuffer();
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }

  private boolean _jspx_meth_tags_005fpanel_005f0(PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  tags:panel
    org.apache.jsp.tag.web.panel_tag _jspx_th_tags_005fpanel_005f0 = new org.apache.jsp.tag.web.panel_tag();
    _jspx_th_tags_005fpanel_005f0.setJspContext(_jspx_page_context);
    _jspx_th_tags_005fpanel_005f0.setColor("#ff8080");
    _jspx_th_tags_005fpanel_005f0.setBgcolor("#ffc0c0");
    _jspx_th_tags_005fpanel_005f0.setTitle("Panel 1");
    _jspx_th_tags_005fpanel_005f0.setJspBody(new panel_jspHelper( 0, _jspx_page_context, _jspx_th_tags_005fpanel_005f0, null));
    _jspx_th_tags_005fpanel_005f0.doTag();
    return false;
  }

  private boolean _jspx_meth_tags_005fpanel_005f1(PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  tags:panel
    org.apache.jsp.tag.web.panel_tag _jspx_th_tags_005fpanel_005f1 = new org.apache.jsp.tag.web.panel_tag();
    _jspx_th_tags_005fpanel_005f1.setJspContext(_jspx_page_context);
    _jspx_th_tags_005fpanel_005f1.setColor("#80ff80");
    _jspx_th_tags_005fpanel_005f1.setBgcolor("#c0ffc0");
    _jspx_th_tags_005fpanel_005f1.setTitle("Panel 2");
    _jspx_th_tags_005fpanel_005f1.setJspBody(new panel_jspHelper( 1, _jspx_page_context, _jspx_th_tags_005fpanel_005f1, null));
    _jspx_th_tags_005fpanel_005f1.doTag();
    return false;
  }

  private boolean _jspx_meth_tags_005fpanel_005f2(PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  tags:panel
    org.apache.jsp.tag.web.panel_tag _jspx_th_tags_005fpanel_005f2 = new org.apache.jsp.tag.web.panel_tag();
    _jspx_th_tags_005fpanel_005f2.setJspContext(_jspx_page_context);
    _jspx_th_tags_005fpanel_005f2.setColor("#8080ff");
    _jspx_th_tags_005fpanel_005f2.setBgcolor("#c0c0ff");
    _jspx_th_tags_005fpanel_005f2.setTitle("Panel 3");
    _jspx_th_tags_005fpanel_005f2.setJspBody(new panel_jspHelper( 2, _jspx_page_context, _jspx_th_tags_005fpanel_005f2, null));
    _jspx_th_tags_005fpanel_005f2.doTag();
    return false;
  }

  private boolean _jspx_meth_tags_005fpanel_005f3(javax.servlet.jsp.tagext.JspTag _jspx_parent, PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  tags:panel
    org.apache.jsp.tag.web.panel_tag _jspx_th_tags_005fpanel_005f3 = new org.apache.jsp.tag.web.panel_tag();
    _jspx_th_tags_005fpanel_005f3.setJspContext(_jspx_page_context);
    _jspx_th_tags_005fpanel_005f3.setParent(_jspx_parent);
    _jspx_th_tags_005fpanel_005f3.setColor("#ff80ff");
    _jspx_th_tags_005fpanel_005f3.setBgcolor("#ffc0ff");
    _jspx_th_tags_005fpanel_005f3.setTitle("Inner");
    _jspx_th_tags_005fpanel_005f3.setJspBody(new panel_jspHelper( 3, _jspx_page_context, _jspx_th_tags_005fpanel_005f3, null));
    _jspx_th_tags_005fpanel_005f3.doTag();
    return false;
  }

  private class panel_jspHelper
      extends org.apache.jasper.runtime.JspFragmentHelper
  {
    private javax.servlet.jsp.tagext.JspTag _jspx_parent;
    private int[] _jspx_push_body_count;

    public panel_jspHelper( int discriminator, JspContext jspContext, javax.servlet.jsp.tagext.JspTag _jspx_parent, int[] _jspx_push_body_count ) {
      super( discriminator, jspContext, _jspx_parent );
      this._jspx_parent = _jspx_parent;
      this._jspx_push_body_count = _jspx_push_body_count;
    }
    public boolean invoke0( JspWriter out ) 
      throws Throwable
    {
      out.write("\r\n\t    First panel.<br/>\r\n\t  ");
      return false;
    }
    public boolean invoke1( JspWriter out ) 
      throws Throwable
    {
      out.write("\r\n\t    Second panel.<br/>\r\n\t    Second panel.<br/>\r\n\t    Second panel.<br/>\r\n\t    Second panel.<br/>\r\n\t  ");
      return false;
    }
    public boolean invoke2( JspWriter out ) 
      throws Throwable
    {
      out.write("\r\n\t    Third panel.<br/>\r\n            ");
      if (_jspx_meth_tags_005fpanel_005f3(_jspx_parent, _jspx_page_context))
        return true;
      out.write("\r\n\t    Third panel.<br/>\r\n\t  ");
      return false;
    }
    public boolean invoke3( JspWriter out ) 
      throws Throwable
    {
      out.write("\r\n\t      A panel in a panel.\r\n\t    ");
      return false;
    }
    public void invoke( java.io.Writer writer )
      throws JspException
    {
      JspWriter out = null;
      if( writer != null ) {
        out = this.jspContext.pushBody(writer);
      } else {
        out = this.jspContext.getOut();
      }
      try {
        switch( this.discriminator ) {
          case 0:
            invoke0( out );
            break;
          case 1:
            invoke1( out );
            break;
          case 2:
            invoke2( out );
            break;
          case 3:
            invoke3( out );
            break;
        }
      }
      catch( Throwable e ) {
        if (e instanceof SkipPageException)
            throw (SkipPageException) e;
        throw new JspException( e );
      }
      finally {
        if( writer != null ) {
          this.jspContext.popBody();
        }
      }
    }
  }
}
