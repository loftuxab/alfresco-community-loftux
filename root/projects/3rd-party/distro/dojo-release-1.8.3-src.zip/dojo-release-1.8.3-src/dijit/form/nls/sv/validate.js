define(
({
	invalidMessage: "Angivet värde är inte giltigt.",
	missingMessage: "Värdet krävs.",
	rangeMessage: "Värdet ligger utanför intervallet."
})
);
