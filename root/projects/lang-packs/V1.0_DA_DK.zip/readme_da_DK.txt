6. November 2005 / Henning Kristensen, H�jbjerg:

1.0.0 oversat.

25. Oktober 2005 / Henning Kristensen, H�jbjerg:

1.0.0rc2 oversat.

23. Oktober 2005 / Henning Kristensen, H�jbjerg:

Dette er min f�rste overs�ttelse af noget IT-system og jeg er p� ingen
m�de nogen professionel sprogn�rd, s� jeg har utvivlsomt gjort nogen
begynderfejl.

Jeg vil rigtigt gerne have kommentarer eller forslag til forbedringer
af overs�ttelsen, og svarer selvf�lgeligt ogs� gerne p� sp�rgsm�l
omkring den.

Post kommentarer, forslag og sp�rgsm�l p� alfresco.org's Language Pack
forum i da_DK-tr�den og send dem (meget gerne!) ogs� til mig som kopi:
henning.kristensen@gmail.com.

God forn�jelse med Alfresco!

========================================================================

Overs�ttelse af n�glebegreber:
------------------------------

check in - tjek ind
check out - tjek ud
action - handling
view - visning
space - omr�de (pr�vede f�rst med rum, men synes ikke at det blev godt)
items - emner
view - visning
locate - find
location - placering
upload - overf�r
repository - arkiv
finish - f�rdigg�r
summary - sammenfatning
action - h�ndelse
Wizard - Guide
notify - besked til
manage - h�ndter
feature - funktion
workflow - arbejdsproces
template - skabelon
node - lagerknude
inline editing - integreret redigering

