==========================
Paquete de idioma Alfresco
==========================

Para la versión: 1.0

Para idioma: es_ES (Español (España))


===================================
Contenido de este paquete de idioma
===================================

action-config.properties
action-service.properties
application-model.properties
bootstrap-spaces.properties
bootstrap-templates.properties
bootstrap-tutorial.properties
content-model.properties
content-service.properties
dictionary-model.properties
permissions-service.properties
rule-config.properties
system-model.properties
version-service.properties
webclient.properties

============
Instalación
============

- Copie todos los ficheros en la carpeta <config root>/messages.
- Edite el fichero 'web-client-config.xml' en la carpeta <raíz de configuración>
  para configurar los idiomas que desea que estén disponibles:

  - Encuentre la sección '<languages>'
  - Añada o quite idiomas de la forma:

       '<language locale="es_ES">Español (España)</language>'
       
   - El orden de las entradas de idioma determina el orden en el que se presentan
     en el cuadro de diálogo de conexión.
   
- Guarde el fichero

- Reinicie el servidor Alfresco


==============================================
Quienes contribuyeron a este paquete de idioma
==============================================

Consulte el Foro de Alfresco para información acerca de los paquetes de idioma:
http://www.alfresco.org/forums/viewforum.php?f=16

Autores originales: Equipo Alfresco
Contribuyeron:
