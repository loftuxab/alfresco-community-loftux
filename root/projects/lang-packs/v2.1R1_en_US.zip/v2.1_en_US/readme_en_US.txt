======================
Alfresco Language Pack
======================

For release: 2.1.0

For locale: EN-US (default)


==============================
Contents of this Language Pack
==============================

action-config_en_US.properties (Updated)
action-service_en_US.properties
application-model_en_US.properties
avm-messages_en_US.properties (NEW)
bootstrap-spaces_en_US.properties
bootstrap-templates_en_US.properties
bootstrap-tutorial_en_US.properties
bpm-messages_en_US.properties (Updated)
coci-service_en_US.properties
content-filter-languages_en_US.properties (NEW)
content-model_en_US.properties (Updated)
content-service_en_US.properties
copy-service_en_US.properties
dictionary-messages_en_US.properties
dictionary-model_en_US.properties
forum-model_en_US.properties
jbpm_en_US.properties (Removed)
lock-service_en_US.properties
module-messages_en_US.properties (Updated)
patch-service_en_US.properties (Updated)
permissions-service_en_US.properties
rule-config_en_US.properties
schema-update_en_US.properties (Updated)
system-messages_en_US.properties
system-model_en_US.properties (Updated)
template-service_en_US.properties
version-service_en_US.properties (Updated)
webclient_en_US.properties (Updated)
webdav-messages_en_US.properties
webscripts-test-help.txt (NEW)
webscripts_en_US.properties (NEW)
workflow-interpreter-help.txt (Updated)
workflow-interpreter-help_en_US.properties
diff/* (diff files for changed properties)
xliff/*.xlz

Note: These are the names of the default language pack.  All other packs should name the
files with the appropriate locale as part of the name following the pattern:
  default-name_LC_RC.properties
where LC is the standard 2 character language code and RC is the standard 2 character region
code.  For example, 'action-config_en_GB.properties'.

We have found the Open Source tool Attesoro (http://attesoro.org/) to be ideal for editing the
language pack files.

The XLIFF folder contains the messages in XLIFF format to aid translation using tools that support
this format.


============
Installation
============

- Copy all files into <extension-config>/messages folder.

- Edit the 'web-client-config-custom.xml' file in the <extension-config> folder to set what languages
  you wish to be available:

  - Find the '<languages>' section
  - Add or remove languages of the form:

       '<language locale="XX_YY">LangName</language>'

- The order of the language entries determines the order they are presented on the login prompt.
- Save the file.

- Restart the Alfresco server.


==================================
Contributors to this Language Pack
==================================

See the Alfresco Forum for status on Language Packs:
http://forums.alfresco.com/viewforum.php?f=16

Original Author(s): Alfresco Team
Contributors: