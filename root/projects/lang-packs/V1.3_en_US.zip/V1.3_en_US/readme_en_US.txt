======================
Alfresco Language Pack
======================

For release: 1.3.0dev

For locale: EN-US (default)


==============================
Contents of this Language Pack
==============================

action-config.properties (Changed)
action-service.properties
application-model.properties
bootstrap-spaces.properties (Changed)
bootstrap-templates.properties
bootstrap-tutorial.properties
coci-service.properties
content-model.properties (Changed)
content-service.properties
dictionary-messages.properties (NEW)
dictionary-model.properties
forum-model.properties
lock-service.properties
patch-service.properties (Changed)
permissions-service.properties
rule-config.properties
system-messages.properties (NEW)
system-model.properties (Changed)
template-service.properties
version-service.properties
diff/* (diff files for changed properties)
xliff/*.xlz

Note: These are the names of the default language pack.  All other packs should name the
files with the appropriate locale as part of the name following the pattern:
  default-name_LC_RC.properties
where LC is the standard 2 character language code and RC is the standard 2 character region
code.  For example, 'action-config_en_GB.properties'.

We have found the Open Source tool Attesoro (http://attesoro.org/) to be ideal for editing the
language pack files.

The XLIFF folder contains the messages in XLIFF format to aid translation using tools that support
this format.


============
Installation
============

- Copy all files into <extension-config>/messages folder.

- Edit the 'web-client-config-custom.xml' file in the <extension-config> folder to set what languages
  you wish to be available:

  - Find the '<languages>' section
  - Add or remove languages of the form:

       '<language locale="XX_YY">LangName</language>'

- The order of the language entries determines the order they are presented on the login prompt.
- Save the file.

- Restart the Alfresco server.


==================================
Contributors to this Language Pack
==================================

See the Alfresco Forum for status on Language Packs:
http://forums.alfresco.com/viewforum.php?f=16

Original Author(s): Alfresco Team
Contributors: